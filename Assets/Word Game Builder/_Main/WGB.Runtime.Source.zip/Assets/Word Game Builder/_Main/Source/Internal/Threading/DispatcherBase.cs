//
// DispatcherBase.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//

using System.Collections.Generic;
using System.Threading;

namespace Thinksquirrel.WordGameBuilderInternal.Threading
{
    /// <summary>
    /// Base class for a dispatcher.
    /// </summary>
    abstract class DispatcherBase : System.IDisposable
    {
        protected Queue<TaskBase> m_TaskQueue = new Queue<TaskBase>();
        protected ManualResetEvent m_DataEvent = new ManualResetEvent(false);

        /// <summary>
        /// Returns the currently existing task count. Early aborted tasks will count too.
        /// </summary>
        public int taskCount
        {
            get
            {
                lock (m_TaskQueue)
                    return m_TaskQueue.Count;
            }
        }

        /// <summary>
        /// Creates a new Task based upon the given action.
        /// </summary>
        /// <typeparam name="T">The return value of the task.</typeparam>
        /// <param name="function">The function to process at the dispatchers thread.</param>
        /// <returns>The new task.</returns>
        public Task<T> Dispatch<T>(System.Func<TaskBase, T> function)
        {
            CheckAccessLimitation();

            var task = Task<T>.Create(t =>
            {
                try
                {
                    return function(t);
                }
                catch
                {
                    t.Abort();
                    return default(T);
                }
            });
            AddTask(task);
            return task;
        }

        /// <summary>
        /// Creates a new Task based upon the given action.
        /// </summary>
        /// <param name="action">The action to process at the dispatchers thread.</param>
        /// <returns>The new task.</returns>
        public Task Dispatch(System.Action<TaskBase> action)
        {
            CheckAccessLimitation();

            var task = Task.Create(t =>
            {
                try
                {
                    action(t);
                }
                catch
                {
                    t.Abort();
                }
            });
            AddTask(task);
            return task;
        }

        public Task Dispatch(Task task)
        {
            CheckAccessLimitation();

            AddTask(task);
            return task;
        }

        public Task<T> Dispatch<T>(Task<T> task)
        {
            CheckAccessLimitation();

            AddTask(task);
            return task;
        }

        internal void AddTask(TaskBase task)
        {
            lock (m_TaskQueue)
                m_TaskQueue.Enqueue(task);
            m_DataEvent.Set();
        }

        internal void AddTasks(IEnumerable<TaskBase> tasks)
        {
            lock (m_TaskQueue)
            {
                var enumerator = tasks.GetEnumerator();
                while(enumerator.MoveNext())
                {
                    var task = enumerator.Current;
                    m_TaskQueue.Enqueue(task);
                }
            }
            m_DataEvent.Set();
        }

        internal IEnumerable<TaskBase> SplitTasks(int divisor)
        {
            if (divisor == 0)
                divisor = 2;
            var count = taskCount / divisor;
            return IsolateTasks(count);
        }

        internal IEnumerable<TaskBase> IsolateTasks(int count)
        {
            var newTasks = new List<TaskBase>();

            if (count == 0)
                count = m_TaskQueue.Count;

            lock (m_TaskQueue)
            {
                for (int i = 0; i < count && m_TaskQueue.Count != 0; ++i)
                    newTasks.Add(m_TaskQueue.Dequeue());
            }

            if (taskCount == 0)
                m_DataEvent.Reset();

            return newTasks;
        }

        protected abstract void CheckAccessLimitation();

        #region IDisposable Members

        public virtual void Dispose()
        {
            while (true)
            {
                TaskBase currentTask;
                lock (m_TaskQueue)
                {
                    if (m_TaskQueue.Count != 0)
                        currentTask = m_TaskQueue.Dequeue();
                    else
                        break;
                }
                currentTask.Dispose();
            }

            m_DataEvent.Close();
            m_DataEvent = null;
        }

        #endregion
    }
}
