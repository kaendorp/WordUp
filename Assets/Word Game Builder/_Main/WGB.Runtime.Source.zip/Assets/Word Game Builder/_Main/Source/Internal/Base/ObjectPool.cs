﻿//
// ObjectPool.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using System.Collections.Generic;
using System.Threading;
using System.Linq;

namespace Thinksquirrel.WordGameBuilderInternal
{
    sealed class ObjectPool<T> : System.IDisposable where T : class
    {
        readonly Queue<AsyncResult<T>> asyncQueue = new Queue<AsyncResult<T>>();
        readonly System.Func<T> createFunction;
        readonly HashSet<T> pool;
        readonly System.Action<T> resetFunction;

        int m_Capacity;
        bool m_IsDisposed;

        public ObjectPool(System.Func<T> createFunction) : this(createFunction, null, 0) { }
        public ObjectPool(System.Func<T> create, System.Action<T> resetFunction) : this(create, resetFunction, 0) { }
        public ObjectPool(System.Func<T> create, int initialCapacity) : this(create, null, initialCapacity) { }
        public ObjectPool(System.Func<T> createFunction, System.Action<T> resetFunction, int initialCapacity)
        {
            this.createFunction = createFunction;
            this.resetFunction = resetFunction;
            pool = new HashSet<T>();
            AddItems(initialCapacity);
        }

        // Analysis disable InconsistentNaming
        public int Count
        {
            get
            {
                return pool.Count;
            }
        }

        public int Capacity
        {
            get
            {
                return m_Capacity;
            }
            set
            {
                lock(pool)
                {
                    m_Capacity = System.Math.Min(pool.Count, value);
                }
            }
        }

        public bool IsDisposed
        {
            get { return m_IsDisposed; }
        }
        // Analysis restore InconsistentNaming

        void Grow()
        {
            if (m_Capacity < 4)
            {
                AddItems(4 - m_Capacity);
            }
            else
            {
                AddItems(m_Capacity);
            }
        }

        void AddItems(int numItems)
        {
            for (var i = 0; i < numItems; i++)
            {
                var item = createFunction();
                pool.Add(item);
                m_Capacity++;
            }
        }
        
        public void Push(T item)
        {
            if (item == null)
            {
                throw new System.ArgumentNullException("item");
            }
            if (resetFunction != null)
            {
                resetFunction(item);
            }
            lock (asyncQueue)
            {
                if (asyncQueue.Count > 0)
                {
                    var result = asyncQueue.Dequeue();
                    result.SetAsCompleted(item, false);
                    return;
                }
            }
            lock (pool)
            {
                pool.Add(item);
            }
        }
        
        public T Pop()
        {
            T item;
            lock (pool)
            {
                if (pool.Count == 0)
                {
                    Grow();
                }
                item = pool.First();
                pool.Remove(item);
            }
            return item;
        }
        
        public System.IAsyncResult BeginPop(System.AsyncCallback callback)
        {
            var result = new AsyncResult<T>(callback, null);
            lock (pool)
            {
                if (pool.Count == 0)
                {
                    lock (asyncQueue)
                    {
                        asyncQueue.Enqueue(result);
                        return result;
                    }
                }
                var poppedItem = pool.First();
                pool.Remove(poppedItem);
                result.SetAsCompleted(poppedItem, true);
                return result;
            }
        }
        
        public T EndPop(System.IAsyncResult asyncResult)
        {
            var result = (AsyncResult<T>)asyncResult;
            return result.EndInvoke();
        }

        #region IDisposable implementation
        public void Dispose()
        {
            if (m_IsDisposed)
                return;

            m_IsDisposed = true;
            if (typeof(System.IDisposable).IsAssignableFrom(typeof(T)))
            {
                var enumerator = pool.GetEnumerator();

                while(enumerator.MoveNext())
                {
                    var item = enumerator.Current;

                    var disposable = (System.IDisposable)item;
                    disposable.Dispose();
                }
            }
        }
        #endregion
    }

    class AsyncResult : System.IAsyncResult
    {
        readonly System.AsyncCallback m_AsyncCallback;
        readonly object m_AsyncState;
        const int c_StatePending = 0;
        const int c_StateCompletedSynchronously = 1;
        const int c_StateCompletedAsynchronously = 2;
        int m_CompletedState = c_StatePending;
        ManualResetEvent m_AsyncWaitHandle;
        System.Exception m_Exception;

        public AsyncResult(System.AsyncCallback asyncCallback, object state)
        {
            m_AsyncCallback = asyncCallback;
            m_AsyncState = state;
        }
        public void SetAsCompleted(System.Exception exception, bool completedSynchronously)
        {
            m_Exception = exception;
         
            int prevState = Interlocked.Exchange(ref m_CompletedState, completedSynchronously ? c_StateCompletedSynchronously : c_StateCompletedAsynchronously);
            if (prevState != c_StatePending)
                throw new System.InvalidOperationException("You can set a result only once");

            if (m_AsyncWaitHandle != null)
                m_AsyncWaitHandle.Set();

            if (m_AsyncCallback != null)
                m_AsyncCallback(this);
        }
        public void EndInvoke()
        {
            if (!IsCompleted)
            {
                AsyncWaitHandle.WaitOne();
                AsyncWaitHandle.Close();
                m_AsyncWaitHandle = null;
            }

            if (m_Exception != null)
                throw m_Exception;
        }

        #region Implementation of System.IAsyncResult
        // Analysis disable InconsistentNaming
        public object AsyncState { get { return m_AsyncState; } }
        public bool CompletedSynchronously { get { return Thread.VolatileRead(ref m_CompletedState) == c_StateCompletedSynchronously; } }
        public WaitHandle AsyncWaitHandle
        {
            get
            {
                if (m_AsyncWaitHandle == null)
                {
                    bool done = IsCompleted;
                    var mre = new ManualResetEvent(done);
                    if (Interlocked.CompareExchange(ref m_AsyncWaitHandle, mre, null) != null)
                    {
                        mre.Close();
                    }
                    else
                    {
                        if (!done && IsCompleted)
                        {
                            m_AsyncWaitHandle.Set();
                        }
                    }
                }
                return m_AsyncWaitHandle;
            }
        }
        public bool IsCompleted { get { return Thread.VolatileRead(ref m_CompletedState) != c_StatePending; } }
        // Analysis restore InconsistentNaming
        #endregion
    }

    sealed class AsyncResult<TResult> : AsyncResult
    {
        TResult m_Result;

        public AsyncResult(System.AsyncCallback asyncCallback, object state) : base(asyncCallback, state) { }
        public void SetAsCompleted(TResult result, bool completedSynchronously)
        {
            m_Result = result;
            base.SetAsCompleted(null, completedSynchronously);
        }
        new public TResult EndInvoke()
        {
            base.EndInvoke();
            return m_Result;
        }
    }
}
