//
// TilePool.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using Thinksquirrel.WordGameBuilderInternal;

#if !UNITY_3_5
namespace Thinksquirrel.WordGameBuilder.Gameplay
{
#else
using Thinksquirrel.WordGameBuilder;
using Thinksquirrel.WordGameBuilder.Gameplay;
#endif
    /// <summary>
    /// A class that manages an instance pool of letter tiles.
    /// </summary>
    /// <remarks>
    /// This class creates an instance pool based on a specific letter distribution. It implements IList<ILetterTile>.
    /// </remarks>
    [AddComponentMenu("Word Game Builder/Gameplay/Tile Pool")]
    [WGBDocumentationName("Thinksquirrel.WordGameBuilder.Gameplay.TilePool")]
    public sealed class TilePool : WGBBase, ITilePool
    {
        // For Unity serialization
        [SerializeField] [HideInInspector] List<string> m_Keys = new List<string>();
        [SerializeField] [HideInInspector] List<int> m_Values = new List<int>();
        [SerializeField] [HideInInspector] int m_Count;
        [SerializeField] [HideInInspector] GameObject m_Parent;
        [SerializeField] [HideInInspector] List<MonoBehaviour> m_SerializedTiles = new List<MonoBehaviour>();

        [SerializeField] string m_LanguageIdentifier;
        [SerializeField] GameObject m_TilePrefab;
        [SerializeField] int m_BlankLetterCount;
        [SerializeField] int m_PoolMultiplier = 1;
        [SerializeField] WGBEvent m_OnTileDistribution;

        bool m_Initialized;
        WordGameLanguage m_CachedLanguage;

        /// <summary>
        /// The language identifier associated with the tile pool.
        /// </summary>
        public string languageIdentifier { get { return m_LanguageIdentifier; } set { if (m_LanguageIdentifier != value) { m_CachedLanguage = null; m_LanguageIdentifier = value; } } }

        /// <summary>
        /// The tile prefab. This must contain a MonoBehaviour that implements ILetterTile.
        /// </summary>
        public GameObject tilePrefab { get { return m_TilePrefab; } set { m_TilePrefab = value; } }
        /// <summary>
        /// The amount of blank letters in the tile distribution.
        /// </summary>
        public int blankLetterCount { get { return m_BlankLetterCount; } set { m_BlankLetterCount = value; } }
        /// <summary>
        /// A multiplier for the tile distribution. Used to easily increase the amount of tiles created.
        /// </summary>
        public int poolMultiplier { get { return m_PoolMultiplier; } set { m_PoolMultiplier = value; } }

        Dictionary<Letter, int> m_TileDistribution;
        HashSet<ILetterTile> m_AllTiles = new HashSet<ILetterTile>();
        List<ILetterTile> m_InternalTilePool = new List<ILetterTile>();

        /// <summary>
        /// Add the specified letter and count to the tile distribution dictionary.
        /// </summary>
        /// <param name="letter">The letter to add.</param>
        /// <param name="count">The amount of tiles to add.</param>
        /// <returns><c>true</c> if the operation was successful; otherwise <c>false</c>.</returns>
        public bool AddLetter(Letter letter, int count)
        {
            if (m_TileDistribution == null)
            {
                GenerateDictionary();
            }

            if (m_TileDistribution.ContainsKey(letter))
                return false;

            m_TileDistribution.Add(letter, count);

            if (Application.isEditor)
            {
                m_Keys.Add(letter.text);
                m_Values.Add(count);
            }

            return true;
        }

        /// <summary>
        /// Remove the specified letter from the tile distribution dictionary.
        /// </summary>
        /// <param name="letter">The letter to remove.</param>
        /// <returns><c>true</c> if the operation was successful; otherwise <c>false</c>.</returns>
        public bool RemoveLetter(Letter letter)
        {
            if (m_TileDistribution == null)
            {
                GenerateDictionary();
            }

            if (!m_TileDistribution.ContainsKey(letter))
                return false;

            if (Application.isEditor)
            {
                int index = m_Keys.IndexOf(letter.text);
                if (index >= 0)
                {
                    m_Keys.RemoveAt(index);
                    m_Values.RemoveAt(index);
                }
            }

            return true;
        }

        /// <summary>
        /// Saves the tile distribution dictionary.
        /// </summary>
        /// <remarks>
        /// When modifying the tile distribution dictionary, this method must be called to serialize the tile pool.
        /// This is usually only needed in the editor.
        /// </remarks>
        public void SaveTileDistribution()
        {
            m_Keys.Clear();
            m_Values.Clear();

            if (m_TileDistribution == null)
                return;

            var enumerator = m_TileDistribution.GetEnumerator();

            while(enumerator.MoveNext())
            {
                var kvp = enumerator.Current;

                m_Keys.Add(kvp.Key.text);
                m_Values.Add(kvp.Value);
            }
        }

        IList<ILetterTile> m_TilePool
        {
            get
            {
                if (!m_Initialized)
                {
                    if (m_SerializedTiles.Count > 0)
                    {
                        if (!m_CachedLanguage || Application.isEditor)
                        {
                            m_CachedLanguage = WordGameLanguage.FindByIdentifier(languageIdentifier);
                        }

                        for (int i = 0; i < m_SerializedTiles.Count; i++)
                        {
                            m_InternalTilePool.Add(m_SerializedTiles [i] as ILetterTile);
                            m_AllTiles.Add(m_SerializedTiles [i] as ILetterTile);
                        }
                        m_InternalTilePool.Shuffle(m_CachedLanguage ? m_CachedLanguage.GetRandomNumberGenerator() : new System.Random());
                    }
                    m_Initialized = true;
                }
                return m_InternalTilePool;
            }
        }

        /// <summary>
        /// Sets the tile pool.
        /// </summary>
        /// <remarks>
        /// This destroys any tiles currently created by the pool, and replaces the entire pool. Used for advanced serialization.
        /// </remarks>
        /// <param name="tiles">A list of tiles to add to the newly created pool.</param>
        public void SetTiles(IList<ILetterTile> tiles)
        {
            DestroyAllTiles();
            for (int i = 0; i < tiles.Count; i++)
            {
                var tile = tiles[i];
                m_AllTiles.Add(tile);
                m_InternalTilePool.Add(tile);
                m_SerializedTiles.Add(tile as MonoBehaviour);
            }
        }

        /// <summary>
        /// Gets or sets the amount of elements in the tile distribution.
        /// </summary>
        /// <remarks>
        /// Used in the editor for serailization.
        /// </remarks>
        public int tileDistributionCount
        {
            get
            {
                return m_Count;
            }
            set
            {
                if (value < 0)
                    return;

                int c = m_Keys.Count;

                if (c > value)
                {
                    for (int i = c - 1; i >= value; i--)
                    {
                        m_Keys.RemoveAt(i);
                        m_Values.RemoveAt(i);
                    }
                }
                else
                if (c < value)
                {
                    for (int i = c; i < value; i++)
                    {
                        m_Keys.Add(System.Convert.ToString(char.MinValue));
                        m_Values.Add(0);
                    }
                }

                m_Count = value;
            }
        }

        void GenerateDictionary()
        {
            m_TileDistribution = new Dictionary<Letter, int>(new LetterComparer());
            if (m_Keys.Count > 0)
            {
                m_TileDistribution.Clear();
                m_CachedLanguage = WordGameLanguage.FindByIdentifier(languageIdentifier);

                for (int i = 0; i < m_Keys.Count; i++)
                {
                    m_TileDistribution.Add(m_CachedLanguage != null ? m_CachedLanguage.GetLetter(m_Keys[i]) : new Letter(m_Keys[i], System.Convert.ToChar(m_Keys[i]), 0), m_Values [i]);
                }
            }
        }

        //! \cond PRIVATE
        [System.Obsolete("The ITilePool interface now implements IList<ILetterTile>")]
        public IList<ILetterTile> tilePool { get { return this; } }

        [System.Obsolete("Use ITilePool.Count instead")]
        public int tilePoolCount { get { return Count; } }

        [System.Obsolete("Use ITilePool.Insert instead")]
        public void AddTileToPool(ILetterTile tile)
        {
            Insert(tile);
        }
        [System.Obsolete("Use ITilePool.Insert instead")]
        public void InsertTile(ILetterTile tile)
        {
            Insert(tile);
        }
        [System.Obsolete("Use ITilePool.Remove instead")]
        public void RemoveTile(ILetterTile tile)
        {
            Remove(tile);
        }
        [System.Obsolete("Use ILetterTile.SpawnTile instead")]
        public void SpawnTile(ILetterTile tile, Vector3 position, Quaternion rotation)
        {
            if (tile != null)
            {
                tile.transform.position = position;
                tile.transform.rotation = rotation;
                tile.SpawnTile();
            }
        }
        [System.Obsolete("Use ILetterTile.DespawnTile instead")]
        public void DespawnTile(ILetterTile tile)
        {
            if (tile != null)
            {
                tile.DespawnTile();
            }
        }
        //! \endcond

        /// <summary>
        /// Creates the tile pool.
        /// </summary>
        /// <param name='parent'>
        /// The parent transform for the tile pool.
        /// </param>
        /// <remarks>
        /// This destroys any tiles currently created by the pool (whether it is in the pool or not), and instantiates tile pool objects based on the letter distribution.
        /// </remarks>
        public void CreateTilePool(Transform parent)
        {
            DestroyAllTiles();

            if (!tilePrefab)
                return;

            var tilePrefabScript = tilePrefab.GetComponentFromInterface<ILetterTile>();

            if (tilePrefabScript == null)
            {
                WGBBase.LogError(string.Format("No ILetterTile found in prefab {0}", tilePrefab.name), "Word Game Builder", "TilePool");
                return;
            }

            if (!m_CachedLanguage || Application.isEditor)
            {
                m_CachedLanguage = WordGameLanguage.FindByIdentifier(languageIdentifier);
            }

            if (m_CachedLanguage == null)
                return;

            if (!m_Parent)
                m_Parent = GameObject.Find(string.Format("WGB Tile Pool: {0}", m_CachedLanguage.languageName));

            if (!m_Parent)
                m_Parent = new GameObject(string.Format("WGB Tile Pool: {0}", m_CachedLanguage.languageName));

            if (parent)
                m_Parent.transform.parent = parent;

            m_Parent.hideFlags = HideFlags.NotEditable;

            for (int c = 0; c < poolMultiplier; c++)
            {
                var enumerator = tileDistribution.GetEnumerator();
                while(enumerator.MoveNext())
                {
                    var kvp = enumerator.Current;

                    for (int i = 0; i < kvp.Value; i++)
                    {
                        CreateTileInternal(kvp.Key, tilePrefabScript);
                    }
                }
                if (m_CachedLanguage.allowBlanks)
                {
                    for (int i = 0; i < blankLetterCount; i++)
                    {
                        CreateTileInternal(Letter.empty, tilePrefabScript);
                    }
                }
            }
            if (parent)
            {
                m_Parent.transform.localPosition = Vector3.zero;
                m_Parent.transform.localRotation = Quaternion.identity;
                m_Parent.transform.localScale = Vector3.one;
            }
            m_InternalTilePool.Shuffle(m_CachedLanguage.GetRandomNumberGenerator());
        }

        /// <summary>
        /// Removes a list of tiles from the pool, if the tiles are associated with the pool.
        /// </summary>
        /// <param name="tiles">The list of tiles to remove.</param>
        public void RemoveTiles(IList<ILetterTile> tiles)
        {
            for (int i = tiles.Count - 1; i >= 0; i--)
            {
                Remove(tiles [i]);
            }
        }
        void CreateTileInternal(Letter letter, ILetterTile tilePrefabScript)
        {
            var tile = InstantiateFromInterface<ILetterTile>(tilePrefabScript);
            tile.name = tilePrefab.name;
            tile.transform.parent = m_Parent.transform;

            m_AllTiles.Add(tile);
            m_InternalTilePool.Add(tile);
            if (!Application.isPlaying) m_SerializedTiles.Add(tile as MonoBehaviour); // TODO: Cleaner initialization?
            tile.ChangeDefaultLetter(letter);
            tile.DespawnTile();
        }
        void DestroyTileInternal(ILetterTile tile, IWordGamePlayer[] players)
        {
            if (m_AllTiles.Contains(tile))
            {
                for(int i = 0; i < players.Length; ++i)
                {
                    var player = players[i];

                    player.heldTiles.Remove(tile);
                    player.selectedTiles.Remove(tile);
                }

                m_InternalTilePool.Remove(tile);
                m_AllTiles.Remove(tile);
                DestroyImmediate(tile.gameObject);
            }

            if (m_AllTiles.Count == 0)
            {
                m_AllTiles.Clear();
                m_InternalTilePool.Clear();
                m_SerializedTiles.Clear();
                DestroyImmediate(m_Parent);
            }
        }

        /// <summary>
        /// Destroys a list of tiles from the scene, if the tiles are associated with the pool.
        /// </summary>
        /// <param name="tiles">The list of tiles to destroy.</param>
        public void DestroyTiles(IList<ILetterTile> tiles)
        {
            var players = WordGamePlayer.GetAllPlayers();

            for (int i = tiles.Count - 1; i >= 0; --i)
            {
                DestroyTileInternal(tiles[i], players);
            }
        }

        void TileDistributionEvent(IWordGamePlayer player, int count)
        {
            lastDistributionCount = count;
            WGBEvent.Invoke(m_OnTileDistribution, m_CachedLanguage, null, this, null, player, null);
        }

        #region ILetterTile implementation
        /// <summary>
        /// The language associated with the tile pool.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ITilePool.language">ITilePool</see>.
        /// </remarks>
        public WordGameLanguage language
        {
            get
            {
                if (m_CachedLanguage == null) m_CachedLanguage = WordGameLanguage.FindByIdentifier(languageIdentifier);
                return m_CachedLanguage;
            }
            set
            {
                m_CachedLanguage = value;
                m_LanguageIdentifier = value != null ? value.identifier : string.Empty;
            }
        }
        /// <summary>
        /// Gets the tile distribution dictionary.
        /// </summary>
        /// <remarks>
        /// This dictionary is only used at runtime. To add or remove from the dictionary in the editor, call the Add and Remove methods on the TilePool class.
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ITilePool.tileDistribution">ITilePool</see>.
        /// </remarks>
        public Dictionary<Letter, int> tileDistribution
        {
            get
            {
                if (m_TileDistribution == null)
                {
                    GenerateDictionary();
                }
                return m_TileDistribution;
            }
        }
        /// <summary>
        /// This event fires when a tile is distributed from the tile pool.
        /// </summary>
        /// <remarks>
        /// Variables set:
        /// * WGBEvent.currentLanguage
        /// * WGBEvent.currentTilePool
        /// * WGBEvent.currentPlayer
        ///
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ITilePool.onTileDistribution">ITilePool</see>.
        /// </remarks>
        public WGBEvent onTileDistribution { get { return m_OnTileDistribution; } set { m_OnTileDistribution = value; } }
        /// <summary>
        /// Gets the last tile distribution count. This value is set before event callbacks.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ITilePool.lastDistributionCount">ITilePool</see>.
        /// </remarks>
        public int lastDistributionCount { get; private set; }
        public void DistributeTiles(IWordGamePlayer player)
        {
            DistributeTiles(player, player.maxTiles);
        }
        // TODO: Throw error for missing prefab
        public void DistributeTiles(IWordGamePlayer player, int count)
        {
            if (!tilePrefab || count <= 0)
                return;

            int c = 0;

            while (player.heldTiles.Count < player.maxTiles)
            {
                if (c >= count)
                    break;
                if (m_InternalTilePool.Count < 1)
                    break;

                player.heldTiles.Add(m_InternalTilePool [0]);
                m_InternalTilePool.RemoveAt(0);
                c++;
            }

            TileDistributionEvent(player, c);
        }
        // TODO: Throw error for missing prefab
        public void DistributeTiles(IWordGamePlayer player, Letter letter, int count)
        {
            if (!tilePrefab || count <= 0)
                return;

            int c = 0;

            while (player.heldTiles.Count < player.maxTiles)
            {
                if (c >= count)
                    break;
                if (m_InternalTilePool.Count < 1)
                    break;

                for (int i = m_InternalTilePool.Count - 1; i >= 0; --i)
                {
                    if (c >= count)
                        break;
                    if (m_InternalTilePool.Count < 1)
                        break;

                    if (m_InternalTilePool [i].defaultLetter == letter)
                    {
                        player.heldTiles.Add(m_InternalTilePool [i]);
                        m_InternalTilePool.RemoveAt(i);
                        c++;
                    }
                }
            }

            TileDistributionEvent(player, c);
        }
        // TODO: Throw error for missing prefab
        public void DistributeTiles(IWordGamePlayer player, IList<Letter> letters)
        {
            if (letters == null)
                return;

            int count = letters.Count;

            if (!tilePrefab || count <= 0)
                return;

            int c = 0;

            while (player.heldTiles.Count < player.maxTiles)
            {
                if (c >= count)
                    break;
                if (m_InternalTilePool.Count < 1)
                    break;

                for (int i = 0; i < count; ++i)
                {
                    if (c >= count)
                        break;
                    if (m_InternalTilePool.Count < 1)
                        break;

                    for (int j = m_InternalTilePool.Count - 1; j >= 0; --j)
                    {
                        if (c >= count)
                            break;
                        if (m_InternalTilePool.Count < 1)
                            break;

                        if (m_InternalTilePool [j].defaultLetter == letters[i])
                        {
                            player.heldTiles.Add(m_InternalTilePool [j]);
                            m_InternalTilePool.RemoveAt(j);
                            c++;
                            break;
                        }
                    }
                }
            }

            TileDistributionEvent(player, c);
        }
        public void CreateTilePool()
        {
            CreateTilePool(transform);
        }
        public void ResetTilePool()
        {
            if (!m_CachedLanguage || Application.isEditor)
            {
                m_CachedLanguage = WordGameLanguage.FindByIdentifier(languageIdentifier);
            }

            var enumerator = m_AllTiles.GetEnumerator();

            while (enumerator.MoveNext())
            {
                var tile = enumerator.Current;

                if (tile != null)
                {
                    tile.DespawnTile();
                }
            }
            m_InternalTilePool.Clear();
            m_InternalTilePool.AddRange(m_AllTiles);
            m_InternalTilePool.Shuffle(m_CachedLanguage ? m_CachedLanguage.GetRandomNumberGenerator() : new System.Random());
        }
        public void DestroyAllTiles()
        {
            if (m_Parent)
                DestroyImmediate(m_Parent);

            m_AllTiles.Clear();
            m_InternalTilePool.Clear();
            m_SerializedTiles.Clear();
        }
        public void Insert(ILetterTile item)
        {
            if (!m_TilePool.Contains(item))
            {
                m_TilePool.Insert(Random.Range(0, m_TilePool.Count - 1), item);
            }
        }
        public void CreateTile(Letter letter)
        {
            if (!m_CachedLanguage || Application.isEditor)
            {
                m_CachedLanguage = WordGameLanguage.FindByIdentifier(languageIdentifier);
            }

            if (m_CachedLanguage == null)
            {
                WGBBase.LogError("No language found for the tile pool", "Word Game Builder", "Tile Pool");
                return;
            }

            if (!tilePrefab)
            {
                WGBBase.LogError("A tile prefab has not been assigned in the inspector", "Word Game Builder", "Tile Pool");
                return;
            }

            var tilePrefabScript = tilePrefab.GetComponentFromInterface<ILetterTile>();

            if (tilePrefabScript == null)
            {
                WGBBase.LogError(string.Format("No ILetterTile found in prefab {0}", tilePrefab.name), "Word Game Builder", "TilePool");
                return;
            }

            if (!letter.hasValue && !m_CachedLanguage.allowBlanks)
            {
                WGBBase.LogError("Attempting to create a blank tile with a language that does not support this", "Word Game Builder", "TilePool");
                return;
            }

            CreateTileInternal(letter, tilePrefabScript);
        }
        public void DestroyTile(ILetterTile tile)
        {
            DestroyTileInternal(tile, WordGamePlayer.GetAllPlayers());
        }
        public bool Contains(Letter letter)
        {
            return IndexOf(letter) >= 0;
        }
        public int GetOccurances(Letter letter)
        {
            var occurances = 0;

            for (int i = 0; i < m_TilePool.Count; ++i)
            {
                if (m_TilePool [i].defaultLetter == letter)
                    ++occurances;
            }

            return occurances;
        }
        public int IndexOf(Letter letter)
        {
            for (int i = 0; i < m_TilePool.Count; ++i)
            {
                if (m_TilePool [i].defaultLetter == letter)
                    return i;
            }

            return -1;
        }
        public int LastIndexOf(Letter letter)
        {
            for (int i = m_TilePool.Count - 1; i >= 0; --i)
            {
                if (m_TilePool [i].defaultLetter == letter)
                    return i;
            }

            return -1;
        }
        #endregion

        #region IList<ILetterTile> implementation
        public int IndexOf(ILetterTile item)
        {
            return m_TilePool.IndexOf(item);
        }
        public void Insert(int index, ILetterTile item)
        {
            if (!m_TilePool.Contains(item))
            {
                m_TilePool.Insert(index, item);
            }
        }
        public void RemoveAt(int index)
        {
            m_TilePool.RemoveAt(index);
        }
        public ILetterTile this[int index]
        {
            get
            {
                return m_TilePool [index];
            }
            set
            {
                if (!m_TilePool.Contains(value))
                {
                    m_TilePool [index] = value;
                }
            }
        }
        #endregion

        #region ICollection<ILetterTile> implementation
        public void Add(ILetterTile item)
        {
            if (!m_TilePool.Contains(item))
                m_TilePool.Add(item);
        }
        public void Clear()
        {
            m_TilePool.Clear();
        }
        public bool Contains(ILetterTile item)
        {
            return m_TilePool.Contains(item);
        }
        public void CopyTo(ILetterTile[] array, int arrayIndex)
        {
            m_TilePool.CopyTo(array, arrayIndex);
        }
        public bool Remove(ILetterTile item)
        {
            return m_TilePool.Remove(item);
        }
        public int Count
        {
            get
            {
                return m_TilePool.Count;
            }
        }
        public bool IsReadOnly
        {
            get
            {
                return false;
            }
        }
        #endregion

        #region IEnumerable<ILetterTile> implementation
        public IEnumerator<ILetterTile> GetEnumerator()
        {
            return m_TilePool.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return ((IEnumerable)m_TilePool).GetEnumerator();
        }
        #endregion
    }
#if !UNITY_3_5
}
#endif
