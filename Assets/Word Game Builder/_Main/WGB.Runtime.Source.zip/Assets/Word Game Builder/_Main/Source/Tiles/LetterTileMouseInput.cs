﻿//
// LetterTileMouseInput.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using UnityEngine;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using Thinksquirrel.WordGameBuilderInternal;

#if !UNITY_3_5
namespace Thinksquirrel.WordGameBuilder.Tiles
{
#else
using Thinksquirrel.WordGameBuilder;
#endif
    /// <summary>
    /// Adds input control to a letter tile, using Unity's OnMouse[...] methods.
    /// </summary>
    /// <remarks>
    /// This component must be on the same object as a letter tile.
    /// </remarks>
    [RequireComponent(typeof(ILetterTileInput))]
    [AddComponentMenu("Word Game Builder/Tiles/Letter Tile Mouse Input")]
    [WGBDocumentationName("Thinksquirrel.WordGameBuilder.Tiles.LetterTileMouseInput")]
    public sealed class LetterTileMouseInput : WGBBase
    {
        ILetterTileInput m_LetterTile;

        void OnEnable()
        {
            m_LetterTile = GetComponentFromInterface<ILetterTileInput>();
        }

        void OnMouseDown()
        {
            if (m_LetterTile != null && m_LetterTile.isActive && m_LetterTile.enabled)
            {
                m_LetterTile.SimulatePressInput(true);
            }
        }

        void OnMouseEnter()
        {
            if (m_LetterTile != null && m_LetterTile.isActive && m_LetterTile.enabled)
            {
                m_LetterTile.SimulateHoverInput(true);
            }
        }

        void OnMouseExit()
        {
            if (m_LetterTile != null && m_LetterTile.isActive && m_LetterTile.enabled)
            {
                m_LetterTile.SimulateHoverInput(false);
            }
        }

        void OnMouseUp()
        {
            if (m_LetterTile != null && m_LetterTile.isActive && m_LetterTile.enabled)
            {
                m_LetterTile.SimulatePressInput(false);
            }
        }

        void OnMouseUpAsButton()
        {
            if (m_LetterTile != null && m_LetterTile.isActive && m_LetterTile.enabled)
            {
                m_LetterTile.SimulateClickInput();
            }
        }
    }
#if !UNITY_3_5
}
#endif
