﻿//
// TaskManager.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using Thinksquirrel.WordGameBuilderInternal.Threading;
using InternalTask = Thinksquirrel.WordGameBuilderInternal.Threading.TaskBase;

namespace Thinksquirrel.WordGameBuilder
{
    /// <summary>
    /// Provides methods for dealing with asynchronous tasks.
    /// </summary>
    public static class TaskManager
    {
        /// <summary>
        /// Abort all currently running asynchronous tasks.
        /// </summary>
        public static void AbortAllTasks()
        {
            if (ThreadUtility.taskDistributor != null)
                ThreadUtility.taskDistributor.AbortAll();
        }

        /// <summary>
        /// Abort all currently running asynchronous tasks, waiting up to <c>secondsPerTask</c> seconds for each task.
        /// </summary>
        /// <param name='seconds'>The maximum amount of seconds to wait.</param>
        public static void AbortAllTasksWaitForSeconds(float seconds)
        {
            if (ThreadUtility.taskDistributor != null)
                ThreadUtility.taskDistributor.AbortAllWaitForSeconds(seconds);
        }
    }
}
