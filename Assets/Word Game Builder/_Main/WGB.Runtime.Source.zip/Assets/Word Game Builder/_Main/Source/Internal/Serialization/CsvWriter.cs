//
// CsvWriter.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using System.IO;
using System.Text;

namespace Thinksquirrel.WordGameBuilderInternal
{
    /// <summary>
    /// A tool class for writing CSV and other char-separated field files.
    /// </summary>
    /// <remarks>
    /// Original CsvReader code (c) Jouni Heikniemi. (http://www.heikniemi.fi/jhlib/)
    /// "JHLib is free. It is not released under any formal license such as GPL; it's just plainly and simply free.
    /// You can do whatever you wish with the code; I don't offer support or carry responsibility for anything related to the source or the binaries."
    /// </remarks>
    sealed class CsvWriter : StreamWriter
    {
        #region Private variables

        char m_Separator;

        #endregion

        #region Constructors

        /// <summary>
        /// Creates a new Csv writer for the given filename (overwriting existing contents).
        /// </summary>
        /// <param name="filename">The name of the file being written to.</param>
        public CsvWriter(string filename) : this(filename, ',', false) { }

        /// <summary>
        /// Creates a new Csv writer for the given filename.
        /// </summary>
        /// <param name="filename">The name of the file being written to.</param>
        /// <param name="append">True if the contents shall be appended to the
        /// end of the possibly existing file.</param>
        public CsvWriter(string filename, bool append) : this(filename, ',', append) { }

        /// <summary>
        /// Creates a new Csv writer for the given filename and encoding.
        /// </summary>
        /// <param name="filename">The name of the file being written to.</param>
        /// <param name="enc">The encoding used.</param>
        /// <param name="append">True if the contents shall be appended to the
        /// end of the possibly existing file.</param>
        public CsvWriter(string filename, Encoding enc, bool append) : this(filename, enc, ',', append) { }

        /// <summary>
        /// Creates a new writer for the given filename and separator.
        /// </summary>
        /// <param name="filename">The name of the file being written to.</param>
        /// <param name="separator">The field separator character used.</param>
        /// <param name="append">True if the contents shall be appended to the
        /// end of the possibly existing file.</param>
        public CsvWriter(string filename, char separator, bool append) : base(filename, append)
        {
            m_Separator = separator;
        }

        /// <summary>
        /// Creates a new writer for the given filename, separator and encoding.
        /// </summary>
        /// <param name="filename">The name of the file being written to.</param>
        /// <param name="enc">The encoding used.</param>
        /// <param name="separator">The field separator character used.</param>
        /// <param name="append">True if the contents shall be appended to the
        /// end of the possibly existing file.</param>
        public CsvWriter(string filename, Encoding enc, char separator, bool append) : base(filename, append, enc)
        {
            m_Separator = separator;
        }

        /// <summary>
        /// Creates a new Csv writer for the given stream.
        /// </summary>
        /// <param name="s">The stream to write the CSV to.</param>
        public CsvWriter(Stream s) : this(s, ',')
        {
        }

        /// <summary>
        /// Creates a new writer for the given stream and separator character.
        /// </summary>
        /// <param name="s">The stream to write the CSV to.</param>
        /// <param name="separator">The field separator character used.</param>
        public CsvWriter(Stream s, char separator) : base(s)
        {
            m_Separator = separator;
        }

        /// <summary>
        /// Creates a new writer for the given stream, separator and encoding.
        /// </summary>
        /// <param name="s">The stream to write the CSV to.</param>
        /// <param name="enc">The encoding used.</param>
        /// <param name="separator">The field separator character used.</param>
        public CsvWriter(Stream s, Encoding enc, char separator) : base(s, enc)
        {
            m_Separator = separator;
        }

        #endregion

        #region Properties

        /// <summary>
        /// The separator character for the fields. Comma for normal CSV.
        /// </summary>
        public char separator
        {
            get { return m_Separator; }
            set { m_Separator = value; }
        }

        #endregion

        public void WriteFields(params object[] content)
        {
            string s;

            for (int i = 0; i < content.Length; ++i)
            {
                s = (content [i] != null ? content [i].ToString() : "");
                
                if (s.IndexOfAny(new [] { separator, '"' }) >= 0)
      				// We have to quote the string
                    s = string.Format("\"{0}\"", s.Replace("\"", "\"\""));
                
                Write(s);

                // Write the separator unless we're at the last position
                if (i < content.Length - 1)
                    Write(m_Separator);
            }
            Write(NewLine);
        }
    }
}
