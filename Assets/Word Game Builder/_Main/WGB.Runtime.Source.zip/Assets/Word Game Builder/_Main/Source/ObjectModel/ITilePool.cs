//
// ITilePool.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using System.Collections.Generic;

namespace Thinksquirrel.WordGameBuilder.ObjectModel
{
    /// <summary>
    /// An interface defining a pool of letter tiles. Implementations must derive from MonoBehaviour in some form.
    /// </summary>
    /// <remarks>
    /// Any implementation of this interface will work with other Word Game Builder classes. However, it is recommended to use the TilePool class instead.
    /// </remarks>
    public interface ITilePool : IMonoBehaviour, IList<ILetterTile>
    {
        /// <summary>
        /// The language associated with the tile pool.
        /// </summary>
        WordGameLanguage language { get; set; }
        /// <summary>
        /// Gets the tile distribution dictionary.
        /// </summary>
        /// <remarks>
        /// This dictionary is only used at runtime. To add or remove from the dictionary in the editor, call the Add and Remove methods on the TilePool class.
        /// </remarks>
        Dictionary<Letter, int> tileDistribution { get; }
        /// <summary>
        /// This event should fire when a tile is distributed from the tile pool.
        /// </summary>
        WGBEvent onTileDistribution { get; set; }
        /// <summary>
        /// Gets the last tile distribution count. This value is set before event callbacks.
        /// </summary>
        int lastDistributionCount { get; }
        /// <summary>
        /// Distributes the specified amount of tiles to the specified IWordGamePlayer, up to the player's maximum tile count.
        /// </summary>
        /// <remarks>
        /// This automatically removes the tile from the tile pool, and gives them to the player. The tile must still be spawned.
        /// </remarks>
        /// <param name="player">The player to distribute tiles to.</param>
        void DistributeTiles(IWordGamePlayer player);
        /// <summary>
        /// Distributes the specified amount of tiles to the specified IWordGamePlayer, up to count or the player's maximum tile count (whichever comes first).
        /// </summary>
        /// <remarks>
        /// This method automatically removes the tile from the tile pool, and gives them to the player. The tile must still be spawned.
        /// </remarks>
        /// <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer"/>
        /// <param name="player">The player to distribute tiles to.</param>
        /// <param name="count">The amount of tiles to attempt to distribute.</param>
        void DistributeTiles(IWordGamePlayer player, int count);
        /// <summary>
        /// Distributes the specified amount of tiles, with the specified letter, to the specified IWordGamePlayer, up to count or the player's maximum tile count (whichever comes first).
        /// </summary>
        /// <remarks>
        /// This method automatically removes the tile from the tile pool, and gives them to the player. The tile must still be spawned.
        /// </remarks>
        /// <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer"/>
        /// <param name="player">The player to distribute tiles to.</param>
        /// <param name="letter">The letter to distribute.</param>
        /// <param name="count">The amount of tiles to attempt to distribute.</param>
        void DistributeTiles(IWordGamePlayer player, Letter letter, int count);
        /// <summary>
        /// Distributes the specified list of letters to the specified IWordGamePlayer, up to the length of the specified letter list or the player's maximum tile count (whichever comes first).
        /// </summary>
        /// <remarks>
        /// Letters not currently available will NOT be distributed. This method automatically removes the tile from the tile pool, and gives them to the player. The tile must still be spawned.
        /// </remarks>
        /// <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer"/>
        /// <param name="player">The player to distribute tiles to.</param>
        /// <param name="letters">The letters to attempt to distribute.</param>
        void DistributeTiles(IWordGamePlayer player, IList<Letter> letters);
        /// <summary>
        /// Creates the tile pool.
        /// </summary>
        /// <remarks>
        /// This destroys any tiles currently created by the pool (whether it is in the pool or not), and instantiates tile pool objects based on the letter distribution.
        /// </remarks>
        void CreateTilePool();
        /// <summary>
        /// Resets the tile pool.
        /// </summary>
        /// <remarks>
        /// This will despawn all tiles, reshuffle all tiles, and put all tiles that belong to this object back into the pool.
        /// </remarks>
        void ResetTilePool();
        /// <summary>
        /// Destroys all tiles that were created by this tile pool (whether it is currently in the pool or not).
        /// </summary>
        /// <remarks>
        /// If a tile's parent object is changed, it will not be destroyed with this method and will become unmanaged by the pool.
        /// </remarks>
        void DestroyAllTiles();
        /// <summary>
        /// Inserts a tile into the pool at a random position, if it does not already contain it.
        /// </summary>
        /// <param name="item">The tile to insert.</param>
        void Insert(ILetterTile item);
        /// <summary>
        /// Spawns a brand new tile into the pool, based on the specified letter.
        /// </summary>
        /// <param name="letter">The letter to spawn.</param>
        void CreateTile(Letter letter);
        /// <summary>
        /// Destroys the tile from the scene, if the tile is associated with the pool.
        /// </summary>
        /// <remarks>
        /// This will fully destroy the tile and remove it from any player's possession. Beware - this is a destructive operation in edit mode!
        /// </remarks>
        /// <param name="tile">The tile to destroy.</param>
        void DestroyTile(ILetterTile tile);
        /// <summary>
        /// Returns true if the tile pool currently contains the specified letter. This method does not look at spawned tiles.
        /// </summary>
        /// <param name="letter">The letter to search for.</param>
        /// <returns>True if the letter exists in the tile pool and is not spawned; otherwise false.</returns>
        bool Contains(Letter letter);
        /// <summary>
        /// Gets the amount of occurances of the specified letter within the tile pool. This method does not look at spawned tiles.
        /// </summary>
        /// <returns>The number of occurances of the specified letter.</returns>
        /// <param name="letter">The letter to search for.</param>
        int GetOccurances(Letter letter);
        /// <summary>
        /// Determines the index of a specific letter in the ITilePool.
        /// </summary>
        /// <returns>The index of item if found in the list; otherwise, -1.</returns>
        /// <param name="letter">The letter to search for.</param>
        int IndexOf(Letter letter);
         /// <summary>
        /// Determines the last index of a specific letter in the ITilePool.
        /// </summary>
        /// <returns>The last index of item if found in the list; otherwise, -1.</returns>
        /// <param name="letter">The letter to search for.</param>
        int LastIndexOf(Letter letter);
    }
}
