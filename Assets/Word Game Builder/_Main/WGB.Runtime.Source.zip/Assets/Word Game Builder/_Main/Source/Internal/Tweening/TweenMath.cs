﻿//
// TweenMath.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2014 Thinksquirrel Software, LLC
//
using UnityEngine;
using Thinksquirrel.WordGameBuilder.Tweening;

namespace Thinksquirrel.WordGameBuilderInternal.Tweening
{
    static class TweenMath
    {
        const float EPSILON = 1.175494351E-38f;

        public static float EaseNone(float t, float b, float c, float d)
        {
            return c * t / d + b;
        }

        public static float EaseInQuad(float t, float b, float c, float d)
        {
            return c * (t /= d) * t + b;
        }

        public static float EaseOutQuad(float t, float b, float c, float d)
        {
            return -c * (t /= d) * (t - 2) + b;
        }

        public static float EaseInOutQuad(float t, float b, float c, float d)
        {
            return (t /= d / 2) < 1 ? c / 2 * t * t + b : -c / 2 * ((--t) * (t - 2) - 1) + b;
        }

        public static float EaseOutInQuad(float t, float b, float c, float d)
        {
            return t < d / 2 ? EaseOutQuad(t * 2, b, c / 2, d) : EaseInQuad((t * 2) - d, b + c / 2, c / 2, d);
        }

        public static float EaseInCubic(float t, float b, float c, float d)
        {
            return c * (t /= d) * t * t + b;
        }

        public static float EaseOutCubic(float t, float b, float c, float d)
        {
            return c * ((t = t / d - 1) * t * t + 1) + b;
        }

        public static float EaseInOutCubic(float t, float b, float c, float d)
        {
            return (t /= d / 2) < 1 ? c / 2 * t * t * t + b : c / 2 * ((t -= 2) * t * t + 2) + b;
        }

        public static float EaseOutInCubic(float t, float b, float c, float d)
        {
            return t < d / 2 ? EaseOutCubic(t * 2, b, c / 2, d) : EaseInCubic((t * 2) - d, b + c / 2, c / 2, d);
        }

        public static float EaseInQuart(float t, float b, float c, float d)
        {
            return c * (t /= d) * t * t * t + b;
        }

        public static float EaseOutQuart(float t, float b, float c, float d)
        {
            return -c * ((t = t / d - 1) * t * t * t - 1) + b;
        }

        public static float EaseInOutQuart(float t, float b, float c, float d)
        {
            return (t /= d / 2) < 1 ? c / 2 * t * t * t * t + b : -c / 2 * ((t -= 2) * t * t * t - 2) + b;
        }

        public static float EaseOutInQuart(float t, float b, float c, float d)
        {
            return t < d / 2 ? EaseOutQuart(t * 2, b, c / 2, d) : EaseInQuart((t * 2) - d, b + c / 2, c / 2, d);
        }

        public static float EaseInQuint(float t, float b, float c, float d)
        {
            return c * (t /= d) * t * t * t * t + b;
        }

        public static float EaseOutQuint(float t, float b, float c, float d)
        {
            return c * ((t = t / d - 1) * t * t * t * t + 1) + b;
        }

        public static float EaseInOutQuint(float t, float b, float c, float d)
        {
            return (t /= d / 2) < 1 ? c / 2 * t * t * t * t * t + b : c / 2 * ((t -= 2) * t * t * t * t + 2) + b;
        }

        public static float EaseOutInQuint(float t, float b, float c, float d)
        {
            return t < d / 2 ? EaseOutQuint(t * 2, b, c / 2, d) : EaseInQuint((t * 2) - d, b + c / 2, c / 2, d);
        }

        public static float EaseInSine(float t, float b, float c, float d)
        {
            return -c * Mathf.Cos(t / d * (Mathf.PI / 2)) + c + b;
        }

        public static float EaseOutSine(float t, float b, float c, float d)
        {
            return c * Mathf.Sin(t / d * (Mathf.PI / 2)) + b;
        }

        public static float EaseInOutSine(float t, float b, float c, float d)
        {
            return -c / 2 * (Mathf.Cos(Mathf.PI * t / d) - 1) + b;
        }

        public static float EaseOutInSine(float t, float b, float c, float d)
        {
            return t < d / 2 ? EaseOutSine(t * 2, b, c / 2, d) : EaseInSine((t * 2) - d, b + c / 2, c / 2, d);
        }

        public static float EaseInExpo(float t, float b, float c, float d)
        {
            return (System.Math.Abs(t) < EPSILON) ? b : c * Mathf.Pow(2, 10 * (t / d - 1)) + b - c * 0.001f;
        }

        public static float EaseOutExpo(float t, float b, float c, float d)
        {
            return (System.Math.Abs(t - d) < EPSILON) ? b + c : c * 1.001f * (-Mathf.Pow(2, -10 * t / d) + 1) + b;
        }

        public static float EaseInOutExpo(float t, float b, float c, float d)
        {
            return System.Math.Abs(t) < EPSILON ? b : System.Math.Abs(t - d) < EPSILON ? b + c : (t /= d / 2) < 1 ? c / 2 * Mathf.Pow(2, 10 * (t - 1)) + b - c * 0.0005f : c / 2 * 1.0005f * (-Mathf.Pow(2, -10 * --t) + 2) + b;
        }

        public static float EaseOutInExpo(float t, float b, float c, float d)
        {
            return t < d / 2 ? EaseOutExpo(t * 2, b, c / 2, d) : EaseInExpo((t * 2) - d, b + c / 2, c / 2, d);
        }

        public static float EaseInCirc(float t, float b, float c, float d)
        {
            return -c * (Mathf.Sqrt(1 - (t /= d) * t) - 1) + b;
        }

        public static float EaseOutCirc(float t, float b, float c, float d)
        {
            return c * Mathf.Sqrt(1 - (t = t / d - 1) * t) + b;
        }

        public static float EaseInOutCirc(float t, float b, float c, float d)
        {
            return (t /= d / 2) < 1 ? -c / 2 * (Mathf.Sqrt(1 - t * t) - 1) + b : c / 2 * (Mathf.Sqrt(1 - (t -= 2) * t) + 1) + b;
        }

        public static float EaseOutInCirc(float t, float b, float c, float d)
        {
            return t < d / 2 ? EaseOutCirc(t * 2, b, c / 2, d) : EaseInCirc((t * 2) - d, b + c / 2, c / 2, d);
        }

        public static float EaseInElastic(float t, float b, float c, float d)
        {
            if (System.Math.Abs(t) < EPSILON)
                return b;
            if (System.Math.Abs((t /= d) - 1) < EPSILON)
                return b + c;
            float p = d * .3f;
            float s;
            float a = 0;
            if (System.Math.Abs(a) < EPSILON || a < Mathf.Abs(c))
            {
                a = c;
                s = p / 4;
            }
            else
            {
                s = p / (2 * Mathf.PI) * Mathf.Asin(c / a);
            }
            return -(a * Mathf.Pow(2, 10 * (t -= 1)) * Mathf.Sin((t * d - s) * (2 * Mathf.PI) / p)) + b;
        }

        public static float EaseOutElastic(float t, float b, float c, float d)
        {
            if (System.Math.Abs(t) < EPSILON)
                return b;
            if (System.Math.Abs((t /= d) - 1) < EPSILON)
                return b + c;
            float p = d * .3f;
            float s;
            float a = 0;
            if (System.Math.Abs(a) < EPSILON || a < Mathf.Abs(c))
            {
                a = c;
                s = p / 4;
            }
            else
            {
                s = p / (2 * Mathf.PI) * Mathf.Asin(c / a);
            }
            return (a * Mathf.Pow(2, -10 * t) * Mathf.Sin((t * d - s) * (2 * Mathf.PI) / p) + c + b);
        }

        public static float EaseInOutElastic(float t, float b, float c, float d)
        {
            if (System.Math.Abs(t) < EPSILON)
                return b;
            if (System.Math.Abs((t /= d / 2) - 2) < EPSILON)
                return b + c;
            float p = d * (.3f * 1.5f);
            float s;
            float a = 0;
            if (System.Math.Abs(a) < EPSILON || a < Mathf.Abs(c))
            {
                a = c;
                s = p / 4;
            }
            else
            {
                s = p / (2 * Mathf.PI) * Mathf.Asin(c / a);
            }
            if (t < 1)
                return -.5f * (a * Mathf.Pow(2, 10 * (t -= 1)) * Mathf.Sin((t * d - s) * (2 * Mathf.PI) / p)) + b;
            return a * Mathf.Pow(2, -10 * (t -= 1)) * Mathf.Sin((t * d - s) * (2 * Mathf.PI) / p) * .5f + c + b;
        }

        public static float EaseOutInElastic(float t, float b, float c, float d)
        {
            return t < d / 2 ? EaseOutElastic(t * 2, b, c / 2, d) : EaseInElastic((t * 2) - d, b + c / 2, c / 2, d);
        }

        public static float EaseInBack(float t, float b, float c, float d)
        {
            const float s = 1.70158f;
            return c * (t /= d) * t * ((s + 1) * t - s) + b;
        }

        public static float EaseOutBack(float t, float b, float c, float d)
        {
            const float s = 1.70158f;
            return c * ((t = t / d - 1) * t * ((s + 1) * t + s) + 1) + b;
        }

        public static float EaseInOutBack(float t, float b, float c, float d)
        {
            float s = 1.70158f;
            return (t /= d / 2) < 1 ? c / 2 * (t * t * (((s *= (1.525f)) + 1) * t - s)) + b : c / 2 * ((t -= 2) * t * (((s *= (1.525f)) + 1) * t + s) + 2) + b;
        }

        public static float EaseOutInBack(float t, float b, float c, float d)
        {
            return t < d / 2 ? EaseOutBack(t * 2, b, c / 2, d) : EaseInBack((t * 2) - d, b + c / 2, c / 2, d);
        }

        public static float EaseInBounce(float t, float b, float c, float d)
        {
            return c - EaseOutBounce(d - t, 0, c, d) + b;
        }

        public static float EaseOutBounce(float t, float b, float c, float d)
        {
            return (t /= d) < (1 / 2.75f) ? c * (7.5625f * t * t) + b : t < (2 / 2.75f) ? c * (7.5625f * (t -= (1.5f / 2.75f)) * t + .75f) + b : t < (2.5f / 2.75f) ? c * (7.5625f * (t -= (2.25f / 2.75f)) * t + .9375f) + b : c * (7.5625f * (t -= (2.625f / 2.75f)) * t + .984375f) + b;
        }

        public static float EaseInOutBounce(float t, float b, float c, float d)
        {
            return t < d / 2 ? EaseInBounce(t * 2, 0, c, d) * .5f + b : EaseOutBounce(t * 2 - d, 0, c, d) * .5f + c * .5f + b;
        }

        public static float EaseOutInBounce(float t, float b, float c, float d)
        {
            return t < d / 2 ? EaseOutBounce(t * 2, b, c / 2, d) : EaseInBounce((t * 2) - d, b + c / 2, c / 2, d);
        }

        public static Vector2 ChangeVector2(float t, Vector2 vB, Vector2 vC, float d, Easing ease)
        {
            float x = 0;
            float y = 0;

            switch (ease)
            {
                case Easing.Linear:
                    x = EaseNone(t, vB.x, vC.x, d);
                    y = EaseNone(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInQuad:
                    x = EaseInQuad(t, vB.x, vC.x, d);
                    y = EaseInQuad(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutQuad:
                    x = EaseOutQuad(t, vB.x, vC.x, d);
                    y = EaseOutQuad(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInOutQuad:
                    x = EaseInOutQuad(t, vB.x, vC.x, d);
                    y = EaseInOutQuad(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutInQuad:
                    x = EaseOutInQuad(t, vB.x, vC.x, d);
                    y = EaseOutInQuad(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInCubic:
                    x = EaseInCubic(t, vB.x, vC.x, d);
                    y = EaseInCubic(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutCubic:
                    x = EaseOutCubic(t, vB.x, vC.x, d);
                    y = EaseOutCubic(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInOutCubic:
                    x = EaseInOutCubic(t, vB.x, vC.x, d);
                    y = EaseInOutCubic(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutInCubic:
                    x = EaseOutInCubic(t, vB.x, vC.x, d);
                    y = EaseOutInCubic(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInQuart:
                    x = EaseInQuart(t, vB.x, vC.x, d);
                    y = EaseInQuart(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutQuart:
                    x = EaseOutQuart(t, vB.x, vC.x, d);
                    y = EaseOutQuart(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInOutQuart:
                    x = EaseInOutQuart(t, vB.x, vC.x, d);
                    y = EaseInOutQuart(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutInQuart:
                    x = EaseOutInQuart(t, vB.x, vC.x, d);
                    y = EaseOutInQuart(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInQuint:
                    x = EaseInQuint(t, vB.x, vC.x, d);
                    y = EaseInQuint(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutQuint:
                    x = EaseOutQuint(t, vB.x, vC.x, d);
                    y = EaseOutQuint(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInOutQuint:
                    x = EaseInOutQuint(t, vB.x, vC.x, d);
                    y = EaseInOutQuint(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutInQuint:
                    x = EaseOutInQuint(t, vB.x, vC.x, d);
                    y = EaseOutInQuint(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInSine:
                    x = EaseInSine(t, vB.x, vC.x, d);
                    y = EaseInSine(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutSine:
                    x = EaseOutSine(t, vB.x, vC.x, d);
                    y = EaseOutSine(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInOutSine:
                    x = EaseInOutSine(t, vB.x, vC.x, d);
                    y = EaseInOutSine(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutInSine:
                    x = EaseOutInSine(t, vB.x, vC.x, d);
                    y = EaseOutInSine(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInExpo:
                    x = EaseInExpo(t, vB.x, vC.x, d);
                    y = EaseInExpo(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutExpo:
                    x = EaseOutExpo(t, vB.x, vC.x, d);
                    y = EaseOutExpo(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInOutExpo:
                    x = EaseInOutExpo(t, vB.x, vC.x, d);
                    y = EaseInOutExpo(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutInExpo:
                    x = EaseOutInExpo(t, vB.x, vC.x, d);
                    y = EaseOutInExpo(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInCirc:
                    x = EaseInCirc(t, vB.x, vC.x, d);
                    y = EaseInCirc(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutCirc:
                    x = EaseOutCirc(t, vB.x, vC.x, d);
                    y = EaseOutCirc(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInOutCirc:
                    x = EaseInOutCirc(t, vB.x, vC.x, d);
                    y = EaseInOutCirc(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutInCirc:
                    x = EaseOutInCirc(t, vB.x, vC.x, d);
                    y = EaseOutInCirc(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInElastic:
                    x = EaseInElastic(t, vB.x, vC.x, d);
                    y = EaseInElastic(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutElastic:
                    x = EaseOutElastic(t, vB.x, vC.x, d);
                    y = EaseOutElastic(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInOutElastic:
                    x = EaseInOutElastic(t, vB.x, vC.x, d);
                    y = EaseInOutElastic(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutInElastic:
                    x = EaseOutInElastic(t, vB.x, vC.x, d);
                    y = EaseOutInElastic(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInBack:
                    x = EaseInBack(t, vB.x, vC.x, d);
                    y = EaseInBack(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutBack:
                    x = EaseOutBack(t, vB.x, vC.x, d);
                    y = EaseOutBack(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInOutBack:
                    x = EaseInOutBack(t, vB.x, vC.x, d);
                    y = EaseInOutBack(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutInBack:
                    x = EaseOutInBack(t, vB.x, vC.x, d);
                    y = EaseOutInBack(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInBounce:
                    x = EaseInBounce(t, vB.x, vC.x, d);
                    y = EaseInBounce(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutBounce:
                    x = EaseOutBounce(t, vB.x, vC.x, d);
                    y = EaseOutBounce(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseInOutBounce:
                    x = EaseInOutBounce(t, vB.x, vC.x, d);
                    y = EaseInOutBounce(t, vB.y, vC.y, d);
                    break;
                case Easing.EaseOutInBounce:
                    x = EaseOutInBounce(t, vB.x, vC.x, d);
                    y = EaseOutInBounce(t, vB.y, vC.y, d);
                    break;
            }

            return new Vector2(x, y);
        }

        public static Vector3 ChangeVector3(float t, Vector3 vB, Vector3 vC, float d, Easing ease)
        {
            float x = 0;
            float y = 0;
            float z = 0;

            switch (ease)
            {
                case Easing.Linear:
                    x = EaseNone(t, vB.x, vC.x, d);
                    y = EaseNone(t, vB.y, vC.y, d);
                    z = EaseNone(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInQuad:
                    x = EaseInQuad(t, vB.x, vC.x, d);
                    y = EaseInQuad(t, vB.y, vC.y, d);
                    z = EaseInQuad(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutQuad:
                    x = EaseOutQuad(t, vB.x, vC.x, d);
                    y = EaseOutQuad(t, vB.y, vC.y, d);
                    z = EaseOutQuad(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInOutQuad:
                    x = EaseInOutQuad(t, vB.x, vC.x, d);
                    y = EaseInOutQuad(t, vB.y, vC.y, d);
                    z = EaseInOutQuad(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutInQuad:
                    x = EaseOutInQuad(t, vB.x, vC.x, d);
                    y = EaseOutInQuad(t, vB.y, vC.y, d);
                    z = EaseOutInQuad(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInCubic:
                    x = EaseInCubic(t, vB.x, vC.x, d);
                    y = EaseInCubic(t, vB.y, vC.y, d);
                    z = EaseInCubic(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutCubic:
                    x = EaseOutCubic(t, vB.x, vC.x, d);
                    y = EaseOutCubic(t, vB.y, vC.y, d);
                    z = EaseOutCubic(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInOutCubic:
                    x = EaseInOutCubic(t, vB.x, vC.x, d);
                    y = EaseInOutCubic(t, vB.y, vC.y, d);
                    z = EaseInOutCubic(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutInCubic:
                    x = EaseOutInCubic(t, vB.x, vC.x, d);
                    y = EaseOutInCubic(t, vB.y, vC.y, d);
                    z = EaseOutInCubic(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInQuart:
                    x = EaseInQuart(t, vB.x, vC.x, d);
                    y = EaseInQuart(t, vB.y, vC.y, d);
                    z = EaseInQuart(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutQuart:
                    x = EaseOutQuart(t, vB.x, vC.x, d);
                    y = EaseOutQuart(t, vB.y, vC.y, d);
                    z = EaseOutQuart(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInOutQuart:
                    x = EaseInOutQuart(t, vB.x, vC.x, d);
                    y = EaseInOutQuart(t, vB.y, vC.y, d);
                    z = EaseInOutQuart(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutInQuart:
                    x = EaseOutInQuart(t, vB.x, vC.x, d);
                    y = EaseOutInQuart(t, vB.y, vC.y, d);
                    z = EaseOutInQuart(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInQuint:
                    x = EaseInQuint(t, vB.x, vC.x, d);
                    y = EaseInQuint(t, vB.y, vC.y, d);
                    z = EaseInQuint(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutQuint:
                    x = EaseOutQuint(t, vB.x, vC.x, d);
                    y = EaseOutQuint(t, vB.y, vC.y, d);
                    z = EaseOutQuint(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInOutQuint:
                    x = EaseInOutQuint(t, vB.x, vC.x, d);
                    y = EaseInOutQuint(t, vB.y, vC.y, d);
                    z = EaseInOutQuint(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutInQuint:
                    x = EaseOutInQuint(t, vB.x, vC.x, d);
                    y = EaseOutInQuint(t, vB.y, vC.y, d);
                    z = EaseOutInQuint(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInSine:
                    x = EaseInSine(t, vB.x, vC.x, d);
                    y = EaseInSine(t, vB.y, vC.y, d);
                    z = EaseInSine(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutSine:
                    x = EaseOutSine(t, vB.x, vC.x, d);
                    y = EaseOutSine(t, vB.y, vC.y, d);
                    z = EaseOutSine(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInOutSine:
                    x = EaseInOutSine(t, vB.x, vC.x, d);
                    y = EaseInOutSine(t, vB.y, vC.y, d);
                    z = EaseInOutSine(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutInSine:
                    x = EaseOutInSine(t, vB.x, vC.x, d);
                    y = EaseOutInSine(t, vB.y, vC.y, d);
                    z = EaseOutInSine(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInExpo:
                    x = EaseInExpo(t, vB.x, vC.x, d);
                    y = EaseInExpo(t, vB.y, vC.y, d);
                    z = EaseInExpo(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutExpo:
                    x = EaseOutExpo(t, vB.x, vC.x, d);
                    y = EaseOutExpo(t, vB.y, vC.y, d);
                    z = EaseOutExpo(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInOutExpo:
                    x = EaseInOutExpo(t, vB.x, vC.x, d);
                    y = EaseInOutExpo(t, vB.y, vC.y, d);
                    z = EaseInOutExpo(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutInExpo:
                    x = EaseOutInExpo(t, vB.x, vC.x, d);
                    y = EaseOutInExpo(t, vB.y, vC.y, d);
                    z = EaseOutInExpo(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInCirc:
                    x = EaseInCirc(t, vB.x, vC.x, d);
                    y = EaseInCirc(t, vB.y, vC.y, d);
                    z = EaseInCirc(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutCirc:
                    x = EaseOutCirc(t, vB.x, vC.x, d);
                    y = EaseOutCirc(t, vB.y, vC.y, d);
                    z = EaseOutCirc(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInOutCirc:
                    x = EaseInOutCirc(t, vB.x, vC.x, d);
                    y = EaseInOutCirc(t, vB.y, vC.y, d);
                    z = EaseInOutCirc(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutInCirc:
                    x = EaseOutInCirc(t, vB.x, vC.x, d);
                    y = EaseOutInCirc(t, vB.y, vC.y, d);
                    z = EaseOutInCirc(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInElastic:
                    x = EaseInElastic(t, vB.x, vC.x, d);
                    y = EaseInElastic(t, vB.y, vC.y, d);
                    z = EaseInElastic(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutElastic:
                    x = EaseOutElastic(t, vB.x, vC.x, d);
                    y = EaseOutElastic(t, vB.y, vC.y, d);
                    z = EaseOutElastic(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInOutElastic:
                    x = EaseInOutElastic(t, vB.x, vC.x, d);
                    y = EaseInOutElastic(t, vB.y, vC.y, d);
                    z = EaseInOutElastic(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutInElastic:
                    x = EaseOutInElastic(t, vB.x, vC.x, d);
                    y = EaseOutInElastic(t, vB.y, vC.y, d);
                    z = EaseOutInElastic(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInBack:
                    x = EaseInBack(t, vB.x, vC.x, d);
                    y = EaseInBack(t, vB.y, vC.y, d);
                    z = EaseInBack(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutBack:
                    x = EaseOutBack(t, vB.x, vC.x, d);
                    y = EaseOutBack(t, vB.y, vC.y, d);
                    z = EaseOutBack(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInOutBack:
                    x = EaseInOutBack(t, vB.x, vC.x, d);
                    y = EaseInOutBack(t, vB.y, vC.y, d);
                    z = EaseInOutBack(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutInBack:
                    x = EaseOutInBack(t, vB.x, vC.x, d);
                    y = EaseOutInBack(t, vB.y, vC.y, d);
                    z = EaseOutInBack(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInBounce:
                    x = EaseInBounce(t, vB.x, vC.x, d);
                    y = EaseInBounce(t, vB.y, vC.y, d);
                    z = EaseInBounce(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutBounce:
                    x = EaseOutBounce(t, vB.x, vC.x, d);
                    y = EaseOutBounce(t, vB.y, vC.y, d);
                    z = EaseOutBounce(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseInOutBounce:
                    x = EaseInOutBounce(t, vB.x, vC.x, d);
                    y = EaseInOutBounce(t, vB.y, vC.y, d);
                    z = EaseInOutBounce(t, vB.z, vC.z, d);
                    break;
                case Easing.EaseOutInBounce:
                    x = EaseOutInBounce(t, vB.x, vC.x, d);
                    y = EaseOutInBounce(t, vB.y, vC.y, d);
                    z = EaseOutInBounce(t, vB.z, vC.z, d);
                    break;
            }

            return new Vector3(x, y, z);
        }

        public static Vector4 ChangeVector4(float t, Vector4 vB, Vector4 vC, float d, Easing ease)
        {
            float x = 0;
            float y = 0;
            float z = 0;
            float w = 0;

            switch (ease)
            {
                case Easing.Linear:
                    x = EaseNone(t, vB.x, vC.x, d);
                    y = EaseNone(t, vB.y, vC.y, d);
                    z = EaseNone(t, vB.z, vC.z, d);
                    w = EaseNone(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInQuad:
                    x = EaseInQuad(t, vB.x, vC.x, d);
                    y = EaseInQuad(t, vB.y, vC.y, d);
                    z = EaseInQuad(t, vB.z, vC.z, d);
                    w = EaseInQuad(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutQuad:
                    x = EaseOutQuad(t, vB.x, vC.x, d);
                    y = EaseOutQuad(t, vB.y, vC.y, d);
                    z = EaseOutQuad(t, vB.z, vC.z, d);
                    w = EaseOutQuad(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInOutQuad:
                    x = EaseInOutQuad(t, vB.x, vC.x, d);
                    y = EaseInOutQuad(t, vB.y, vC.y, d);
                    z = EaseInOutQuad(t, vB.z, vC.z, d);
                    w = EaseInOutQuad(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutInQuad:
                    x = EaseOutInQuad(t, vB.x, vC.x, d);
                    y = EaseOutInQuad(t, vB.y, vC.y, d);
                    z = EaseOutInQuad(t, vB.z, vC.z, d);
                    w = EaseOutInQuad(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInCubic:
                    x = EaseInCubic(t, vB.x, vC.x, d);
                    y = EaseInCubic(t, vB.y, vC.y, d);
                    z = EaseInCubic(t, vB.z, vC.z, d);
                    w = EaseInCubic(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutCubic:
                    x = EaseOutCubic(t, vB.x, vC.x, d);
                    y = EaseOutCubic(t, vB.y, vC.y, d);
                    z = EaseOutCubic(t, vB.z, vC.z, d);
                    w = EaseOutCubic(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInOutCubic:
                    x = EaseInOutCubic(t, vB.x, vC.x, d);
                    y = EaseInOutCubic(t, vB.y, vC.y, d);
                    z = EaseInOutCubic(t, vB.z, vC.z, d);
                    w = EaseInOutCubic(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutInCubic:
                    x = EaseOutInCubic(t, vB.x, vC.x, d);
                    y = EaseOutInCubic(t, vB.y, vC.y, d);
                    z = EaseOutInCubic(t, vB.z, vC.z, d);
                    w = EaseOutInCubic(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInQuart:
                    x = EaseInQuart(t, vB.x, vC.x, d);
                    y = EaseInQuart(t, vB.y, vC.y, d);
                    z = EaseInQuart(t, vB.z, vC.z, d);
                    w = EaseInQuart(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutQuart:
                    x = EaseOutQuart(t, vB.x, vC.x, d);
                    y = EaseOutQuart(t, vB.y, vC.y, d);
                    z = EaseOutQuart(t, vB.z, vC.z, d);
                    w = EaseOutQuart(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInOutQuart:
                    x = EaseInOutQuart(t, vB.x, vC.x, d);
                    y = EaseInOutQuart(t, vB.y, vC.y, d);
                    z = EaseInOutQuart(t, vB.z, vC.z, d);
                    w = EaseInOutQuart(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutInQuart:
                    x = EaseOutInQuart(t, vB.x, vC.x, d);
                    y = EaseOutInQuart(t, vB.y, vC.y, d);
                    z = EaseOutInQuart(t, vB.z, vC.z, d);
                    w = EaseOutInQuart(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInQuint:
                    x = EaseInQuint(t, vB.x, vC.x, d);
                    y = EaseInQuint(t, vB.y, vC.y, d);
                    z = EaseInQuint(t, vB.z, vC.z, d);
                    w = EaseInQuint(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutQuint:
                    x = EaseOutQuint(t, vB.x, vC.x, d);
                    y = EaseOutQuint(t, vB.y, vC.y, d);
                    z = EaseOutQuint(t, vB.z, vC.z, d);
                    w = EaseOutQuint(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInOutQuint:
                    x = EaseInOutQuint(t, vB.x, vC.x, d);
                    y = EaseInOutQuint(t, vB.y, vC.y, d);
                    z = EaseInOutQuint(t, vB.z, vC.z, d);
                    w = EaseInOutQuint(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutInQuint:
                    x = EaseOutInQuint(t, vB.x, vC.x, d);
                    y = EaseOutInQuint(t, vB.y, vC.y, d);
                    z = EaseOutInQuint(t, vB.z, vC.z, d);
                    w = EaseOutInQuint(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInSine:
                    x = EaseInSine(t, vB.x, vC.x, d);
                    y = EaseInSine(t, vB.y, vC.y, d);
                    z = EaseInSine(t, vB.z, vC.z, d);
                    w = EaseInSine(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutSine:
                    x = EaseOutSine(t, vB.x, vC.x, d);
                    y = EaseOutSine(t, vB.y, vC.y, d);
                    z = EaseOutSine(t, vB.z, vC.z, d);
                    w = EaseOutSine(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInOutSine:
                    x = EaseInOutSine(t, vB.x, vC.x, d);
                    y = EaseInOutSine(t, vB.y, vC.y, d);
                    z = EaseInOutSine(t, vB.z, vC.z, d);
                    w = EaseInOutSine(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutInSine:
                    x = EaseOutInSine(t, vB.x, vC.x, d);
                    y = EaseOutInSine(t, vB.y, vC.y, d);
                    z = EaseOutInSine(t, vB.z, vC.z, d);
                    w = EaseOutInSine(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInExpo:
                    x = EaseInExpo(t, vB.x, vC.x, d);
                    y = EaseInExpo(t, vB.y, vC.y, d);
                    z = EaseInExpo(t, vB.z, vC.z, d);
                    w = EaseInExpo(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutExpo:
                    x = EaseOutExpo(t, vB.x, vC.x, d);
                    y = EaseOutExpo(t, vB.y, vC.y, d);
                    z = EaseOutExpo(t, vB.z, vC.z, d);
                    w = EaseOutExpo(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInOutExpo:
                    x = EaseInOutExpo(t, vB.x, vC.x, d);
                    y = EaseInOutExpo(t, vB.y, vC.y, d);
                    z = EaseInOutExpo(t, vB.z, vC.z, d);
                    w = EaseInOutExpo(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutInExpo:
                    x = EaseOutInExpo(t, vB.x, vC.x, d);
                    y = EaseOutInExpo(t, vB.y, vC.y, d);
                    z = EaseOutInExpo(t, vB.z, vC.z, d);
                    w = EaseOutInExpo(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInCirc:
                    x = EaseInCirc(t, vB.x, vC.x, d);
                    y = EaseInCirc(t, vB.y, vC.y, d);
                    z = EaseInCirc(t, vB.z, vC.z, d);
                    w = EaseInCirc(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutCirc:
                    x = EaseOutCirc(t, vB.x, vC.x, d);
                    y = EaseOutCirc(t, vB.y, vC.y, d);
                    z = EaseOutCirc(t, vB.z, vC.z, d);
                    w = EaseOutCirc(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInOutCirc:
                    x = EaseInOutCirc(t, vB.x, vC.x, d);
                    y = EaseInOutCirc(t, vB.y, vC.y, d);
                    z = EaseInOutCirc(t, vB.z, vC.z, d);
                    w = EaseInOutCirc(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutInCirc:
                    x = EaseOutInCirc(t, vB.x, vC.x, d);
                    y = EaseOutInCirc(t, vB.y, vC.y, d);
                    z = EaseOutInCirc(t, vB.z, vC.z, d);
                    w = EaseOutInCirc(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInElastic:
                    x = EaseInElastic(t, vB.x, vC.x, d);
                    y = EaseInElastic(t, vB.y, vC.y, d);
                    z = EaseInElastic(t, vB.z, vC.z, d);
                    w = EaseInElastic(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutElastic:
                    x = EaseOutElastic(t, vB.x, vC.x, d);
                    y = EaseOutElastic(t, vB.y, vC.y, d);
                    z = EaseOutElastic(t, vB.z, vC.z, d);
                    w = EaseOutElastic(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInOutElastic:
                    x = EaseInOutElastic(t, vB.x, vC.x, d);
                    y = EaseInOutElastic(t, vB.y, vC.y, d);
                    z = EaseInOutElastic(t, vB.z, vC.z, d);
                    w = EaseInOutElastic(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutInElastic:
                    x = EaseOutInElastic(t, vB.x, vC.x, d);
                    y = EaseOutInElastic(t, vB.y, vC.y, d);
                    z = EaseOutInElastic(t, vB.z, vC.z, d);
                    w = EaseOutInElastic(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInBack:
                    x = EaseInBack(t, vB.x, vC.x, d);
                    y = EaseInBack(t, vB.y, vC.y, d);
                    z = EaseInBack(t, vB.z, vC.z, d);
                    w = EaseInBack(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutBack:
                    x = EaseOutBack(t, vB.x, vC.x, d);
                    y = EaseOutBack(t, vB.y, vC.y, d);
                    z = EaseOutBack(t, vB.z, vC.z, d);
                    w = EaseOutBack(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInOutBack:
                    x = EaseInOutBack(t, vB.x, vC.x, d);
                    y = EaseInOutBack(t, vB.y, vC.y, d);
                    z = EaseInOutBack(t, vB.z, vC.z, d);
                    w = EaseInOutBack(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutInBack:
                    x = EaseOutInBack(t, vB.x, vC.x, d);
                    y = EaseOutInBack(t, vB.y, vC.y, d);
                    z = EaseOutInBack(t, vB.z, vC.z, d);
                    w = EaseOutInBack(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInBounce:
                    x = EaseInBounce(t, vB.x, vC.x, d);
                    y = EaseInBounce(t, vB.y, vC.y, d);
                    z = EaseInBounce(t, vB.z, vC.z, d);
                    w = EaseInBounce(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutBounce:
                    x = EaseOutBounce(t, vB.x, vC.x, d);
                    y = EaseOutBounce(t, vB.y, vC.y, d);
                    z = EaseOutBounce(t, vB.z, vC.z, d);
                    w = EaseOutBounce(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseInOutBounce:
                    x = EaseInOutBounce(t, vB.x, vC.x, d);
                    y = EaseInOutBounce(t, vB.y, vC.y, d);
                    z = EaseInOutBounce(t, vB.z, vC.z, d);
                    w = EaseInOutBounce(t, vB.w, vC.w, d);
                    break;
                case Easing.EaseOutInBounce:
                    x = EaseOutInBounce(t, vB.x, vC.x, d);
                    y = EaseOutInBounce(t, vB.y, vC.y, d);
                    z = EaseOutInBounce(t, vB.z, vC.z, d);
                    w = EaseOutInBounce(t, vB.w, vC.w, d);
                    break;
            }

            return new Vector4(x, y, z, w);
        }

        public static Color ChangeColor(float t, Color cB, Color cC, float d, Easing ease)
        {
            float r = 0;
            float g = 0;
            float b = 0;
            float a = 0;

            switch (ease)
            {
                case Easing.Linear:
                    r = EaseNone(t, cB.r, cC.r, d);
                    g = EaseNone(t, cB.g, cC.g, d);
                    b = EaseNone(t, cB.b, cC.b, d);
                    a = EaseNone(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInQuad:
                    r = EaseInQuad(t, cB.r, cC.r, d);
                    g = EaseInQuad(t, cB.g, cC.g, d);
                    b = EaseInQuad(t, cB.b, cC.b, d);
                    a = EaseInQuad(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutQuad:
                    r = EaseOutQuad(t, cB.r, cC.r, d);
                    g = EaseOutQuad(t, cB.g, cC.g, d);
                    b = EaseOutQuad(t, cB.b, cC.b, d);
                    a = EaseOutQuad(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInOutQuad:
                    r = EaseInOutQuad(t, cB.r, cC.r, d);
                    g = EaseInOutQuad(t, cB.g, cC.g, d);
                    b = EaseInOutQuad(t, cB.b, cC.b, d);
                    a = EaseInOutQuad(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutInQuad:
                    r = EaseOutInQuad(t, cB.r, cC.r, d);
                    g = EaseOutInQuad(t, cB.g, cC.g, d);
                    b = EaseOutInQuad(t, cB.b, cC.b, d);
                    a = EaseOutInQuad(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInCubic:
                    r = EaseInCubic(t, cB.r, cC.r, d);
                    g = EaseInCubic(t, cB.g, cC.g, d);
                    b = EaseInCubic(t, cB.b, cC.b, d);
                    a = EaseInCubic(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutCubic:
                    r = EaseOutCubic(t, cB.r, cC.r, d);
                    g = EaseOutCubic(t, cB.g, cC.g, d);
                    b = EaseOutCubic(t, cB.b, cC.b, d);
                    a = EaseOutCubic(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInOutCubic:
                    r = EaseInOutCubic(t, cB.r, cC.r, d);
                    g = EaseInOutCubic(t, cB.g, cC.g, d);
                    b = EaseInOutCubic(t, cB.b, cC.b, d);
                    a = EaseInOutCubic(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutInCubic:
                    r = EaseOutInCubic(t, cB.r, cC.r, d);
                    g = EaseOutInCubic(t, cB.g, cC.g, d);
                    b = EaseOutInCubic(t, cB.b, cC.b, d);
                    a = EaseOutInCubic(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInQuart:
                    r = EaseInQuart(t, cB.r, cC.r, d);
                    g = EaseInQuart(t, cB.g, cC.g, d);
                    b = EaseInQuart(t, cB.b, cC.b, d);
                    a = EaseInQuart(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutQuart:
                    r = EaseOutQuart(t, cB.r, cC.r, d);
                    g = EaseOutQuart(t, cB.g, cC.g, d);
                    b = EaseOutQuart(t, cB.b, cC.b, d);
                    a = EaseOutQuart(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInOutQuart:
                    r = EaseInOutQuart(t, cB.r, cC.r, d);
                    g = EaseInOutQuart(t, cB.g, cC.g, d);
                    b = EaseInOutQuart(t, cB.b, cC.b, d);
                    a = EaseInOutQuart(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutInQuart:
                    r = EaseOutInQuart(t, cB.r, cC.r, d);
                    g = EaseOutInQuart(t, cB.g, cC.g, d);
                    b = EaseOutInQuart(t, cB.b, cC.b, d);
                    a = EaseOutInQuart(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInQuint:
                    r = EaseInQuint(t, cB.r, cC.r, d);
                    g = EaseInQuint(t, cB.g, cC.g, d);
                    b = EaseInQuint(t, cB.b, cC.b, d);
                    a = EaseInQuint(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutQuint:
                    r = EaseOutQuint(t, cB.r, cC.r, d);
                    g = EaseOutQuint(t, cB.g, cC.g, d);
                    b = EaseOutQuint(t, cB.b, cC.b, d);
                    a = EaseOutQuint(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInOutQuint:
                    r = EaseInOutQuint(t, cB.r, cC.r, d);
                    g = EaseInOutQuint(t, cB.g, cC.g, d);
                    b = EaseInOutQuint(t, cB.b, cC.b, d);
                    a = EaseInOutQuint(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutInQuint:
                    r = EaseOutInQuint(t, cB.r, cC.r, d);
                    g = EaseOutInQuint(t, cB.g, cC.g, d);
                    b = EaseOutInQuint(t, cB.b, cC.b, d);
                    a = EaseOutInQuint(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInSine:
                    r = EaseInSine(t, cB.r, cC.r, d);
                    g = EaseInSine(t, cB.g, cC.g, d);
                    b = EaseInSine(t, cB.b, cC.b, d);
                    a = EaseInSine(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutSine:
                    r = EaseOutSine(t, cB.r, cC.r, d);
                    g = EaseOutSine(t, cB.g, cC.g, d);
                    b = EaseOutSine(t, cB.b, cC.b, d);
                    a = EaseOutSine(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInOutSine:
                    r = EaseInOutSine(t, cB.r, cC.r, d);
                    g = EaseInOutSine(t, cB.g, cC.g, d);
                    b = EaseInOutSine(t, cB.b, cC.b, d);
                    a = EaseInOutSine(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutInSine:
                    r = EaseOutInSine(t, cB.r, cC.r, d);
                    g = EaseOutInSine(t, cB.g, cC.g, d);
                    b = EaseOutInSine(t, cB.b, cC.b, d);
                    a = EaseOutInSine(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInExpo:
                    r = EaseInExpo(t, cB.r, cC.r, d);
                    g = EaseInExpo(t, cB.g, cC.g, d);
                    b = EaseInExpo(t, cB.b, cC.b, d);
                    a = EaseInExpo(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutExpo:
                    r = EaseOutExpo(t, cB.r, cC.r, d);
                    g = EaseOutExpo(t, cB.g, cC.g, d);
                    b = EaseOutExpo(t, cB.b, cC.b, d);
                    a = EaseOutExpo(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInOutExpo:
                    r = EaseInOutExpo(t, cB.r, cC.r, d);
                    g = EaseInOutExpo(t, cB.g, cC.g, d);
                    b = EaseInOutExpo(t, cB.b, cC.b, d);
                    a = EaseInOutExpo(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutInExpo:
                    r = EaseOutInExpo(t, cB.r, cC.r, d);
                    g = EaseOutInExpo(t, cB.g, cC.g, d);
                    b = EaseOutInExpo(t, cB.b, cC.b, d);
                    a = EaseOutInExpo(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInCirc:
                    r = EaseInCirc(t, cB.r, cC.r, d);
                    g = EaseInCirc(t, cB.g, cC.g, d);
                    b = EaseInCirc(t, cB.b, cC.b, d);
                    a = EaseInCirc(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutCirc:
                    r = EaseOutCirc(t, cB.r, cC.r, d);
                    g = EaseOutCirc(t, cB.g, cC.g, d);
                    b = EaseOutCirc(t, cB.b, cC.b, d);
                    a = EaseOutCirc(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInOutCirc:
                    r = EaseInOutCirc(t, cB.r, cC.r, d);
                    g = EaseInOutCirc(t, cB.g, cC.g, d);
                    b = EaseInOutCirc(t, cB.b, cC.b, d);
                    a = EaseInOutCirc(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutInCirc:
                    r = EaseOutInCirc(t, cB.r, cC.r, d);
                    g = EaseOutInCirc(t, cB.g, cC.g, d);
                    b = EaseOutInCirc(t, cB.b, cC.b, d);
                    a = EaseOutInCirc(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInElastic:
                    r = EaseInElastic(t, cB.r, cC.r, d);
                    g = EaseInElastic(t, cB.g, cC.g, d);
                    b = EaseInElastic(t, cB.b, cC.b, d);
                    a = EaseInElastic(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutElastic:
                    r = EaseOutElastic(t, cB.r, cC.r, d);
                    g = EaseOutElastic(t, cB.g, cC.g, d);
                    b = EaseOutElastic(t, cB.b, cC.b, d);
                    a = EaseOutElastic(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInOutElastic:
                    r = EaseInOutElastic(t, cB.r, cC.r, d);
                    g = EaseInOutElastic(t, cB.g, cC.g, d);
                    b = EaseInOutElastic(t, cB.b, cC.b, d);
                    a = EaseInOutElastic(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutInElastic:
                    r = EaseOutInElastic(t, cB.r, cC.r, d);
                    g = EaseOutInElastic(t, cB.g, cC.g, d);
                    b = EaseOutInElastic(t, cB.b, cC.b, d);
                    a = EaseOutInElastic(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInBack:
                    r = EaseInBack(t, cB.r, cC.r, d);
                    g = EaseInBack(t, cB.g, cC.g, d);
                    b = EaseInBack(t, cB.b, cC.b, d);
                    a = EaseInBack(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutBack:
                    r = EaseOutBack(t, cB.r, cC.r, d);
                    g = EaseOutBack(t, cB.g, cC.g, d);
                    b = EaseOutBack(t, cB.b, cC.b, d);
                    a = EaseOutBack(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInOutBack:
                    r = EaseInOutBack(t, cB.r, cC.r, d);
                    g = EaseInOutBack(t, cB.g, cC.g, d);
                    b = EaseInOutBack(t, cB.b, cC.b, d);
                    a = EaseInOutBack(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutInBack:
                    r = EaseOutInBack(t, cB.r, cC.r, d);
                    g = EaseOutInBack(t, cB.g, cC.g, d);
                    b = EaseOutInBack(t, cB.b, cC.b, d);
                    a = EaseOutInBack(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInBounce:
                    r = EaseInBounce(t, cB.r, cC.r, d);
                    g = EaseInBounce(t, cB.g, cC.g, d);
                    b = EaseInBounce(t, cB.b, cC.b, d);
                    a = EaseInBounce(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutBounce:
                    r = EaseOutBounce(t, cB.r, cC.r, d);
                    g = EaseOutBounce(t, cB.g, cC.g, d);
                    b = EaseOutBounce(t, cB.b, cC.b, d);
                    a = EaseOutBounce(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseInOutBounce:
                    r = EaseInOutBounce(t, cB.r, cC.r, d);
                    g = EaseInOutBounce(t, cB.g, cC.g, d);
                    b = EaseInOutBounce(t, cB.b, cC.b, d);
                    a = EaseInOutBounce(t, cB.a, cC.a, d);
                    break;
                case Easing.EaseOutInBounce:
                    r = EaseOutInBounce(t, cB.r, cC.r, d);
                    g = EaseOutInBounce(t, cB.g, cC.g, d);
                    b = EaseOutInBounce(t, cB.b, cC.b, d);
                    a = EaseOutInBounce(t, cB.a, cC.a, d);
                    break;
            }

            return new Vector4(r, g, b, a);
        }

        public static float ChangeFloat(float t, float b, float c, float d, Easing ease)
        {
            float value = 0;

            switch (ease)
            {
                case Easing.Linear:
                    value = EaseNone(t, b, c, d);
                    break;
                case Easing.EaseInQuad:
                    value = EaseInQuad(t, b, c, d);
                    break;
                case Easing.EaseOutQuad:
                    value = EaseOutQuad(t, b, c, d);
                    break;
                case Easing.EaseInOutQuad:
                    value = EaseInOutQuad(t, b, c, d);
                    break;
                case Easing.EaseOutInQuad:
                    value = EaseOutInQuad(t, b, c, d);
                    break;
                case Easing.EaseInCubic:
                    value = EaseInCubic(t, b, c, d);
                    break;
                case Easing.EaseOutCubic:
                    value = EaseOutCubic(t, b, c, d);
                    break;
                case Easing.EaseInOutCubic:
                    value = EaseInOutCubic(t, b, c, d);
                    break;
                case Easing.EaseOutInCubic:
                    value = EaseOutInCubic(t, b, c, d);
                    break;
                case Easing.EaseInQuart:
                    value = EaseInQuart(t, b, c, d);
                    break;
                case Easing.EaseOutQuart:
                    value = EaseOutQuart(t, b, c, d);
                    break;
                case Easing.EaseInOutQuart:
                    value = EaseInOutQuart(t, b, c, d);
                    break;
                case Easing.EaseOutInQuart:
                    value = EaseOutInQuart(t, b, c, d);
                    break;
                case Easing.EaseInQuint:
                    value = EaseInQuint(t, b, c, d);
                    break;
                case Easing.EaseOutQuint:
                    value = EaseOutQuint(t, b, c, d);
                    break;
                case Easing.EaseInOutQuint:
                    value = EaseInOutQuint(t, b, c, d);
                    break;
                case Easing.EaseOutInQuint:
                    value = EaseOutInQuint(t, b, c, d);
                    break;
                case Easing.EaseInSine:
                    value = EaseInSine(t, b, c, d);
                    break;
                case Easing.EaseOutSine:
                    value = EaseOutSine(t, b, c, d);
                    break;
                case Easing.EaseInOutSine:
                    value = EaseInOutSine(t, b, c, d);
                    break;
                case Easing.EaseOutInSine:
                    value = EaseOutInSine(t, b, c, d);
                    break;
                case Easing.EaseInExpo:
                    value = EaseInExpo(t, b, c, d);
                    break;
                case Easing.EaseOutExpo:
                    value = EaseOutExpo(t, b, c, d);
                    break;
                case Easing.EaseInOutExpo:
                    value = EaseInOutExpo(t, b, c, d);
                    break;
                case Easing.EaseOutInExpo:
                    value = EaseOutInExpo(t, b, c, d);
                    break;
                case Easing.EaseInCirc:
                    value = EaseInCirc(t, b, c, d);
                    break;
                case Easing.EaseOutCirc:
                    value = EaseOutCirc(t, b, c, d);
                    break;
                case Easing.EaseInOutCirc:
                    value = EaseInOutCirc(t, b, c, d);
                    break;
                case Easing.EaseOutInCirc:
                    value = EaseOutInCirc(t, b, c, d);
                    break;
                case Easing.EaseInElastic:
                    value = EaseInElastic(t, b, c, d);
                    break;
                case Easing.EaseOutElastic:
                    value = EaseOutElastic(t, b, c, d);
                    break;
                case Easing.EaseInOutElastic:
                    value = EaseInOutElastic(t, b, c, d);
                    break;
                case Easing.EaseOutInElastic:
                    value = EaseOutInElastic(t, b, c, d);
                    break;
                case Easing.EaseInBack:
                    value = EaseInBack(t, b, c, d);
                    break;
                case Easing.EaseOutBack:
                    value = EaseOutBack(t, b, c, d);
                    break;
                case Easing.EaseInOutBack:
                    value = EaseInOutBack(t, b, c, d);
                    break;
                case Easing.EaseOutInBack:
                    value = EaseOutInBack(t, b, c, d);
                    break;
                case Easing.EaseInBounce:
                    value = EaseInBounce(t, b, c, d);
                    break;
                case Easing.EaseOutBounce:
                    value = EaseOutBounce(t, b, c, d);
                    break;
                case Easing.EaseInOutBounce:
                    value = EaseInOutBounce(t, b, c, d);
                    break;
                case Easing.EaseOutInBounce:
                    value = EaseOutInBounce(t, b, c, d);
                    break;
            }

            return value;
        }
    }
}
