//
// TaskDistributor.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using System.Threading;
using System.Collections.Generic;

namespace Thinksquirrel.WordGameBuilderInternal.Threading
{
    /// <summary>
    /// Task distributor. Dispatches multiple background tasks.
    /// </summary>
    sealed class TaskDistributor : DispatcherBase
    {
        TaskWorker[] m_WorkerThreads;

        internal WaitHandle NewDataWaitHandle { get { return m_DataEvent; } }

        static TaskDistributor s_MainTaskDistributor;

        /// <summary>
        /// Returns the first created TaskDistributor instance. When no instance has been created an exception will be thrown.
        /// </summary>
        public static TaskDistributor main
        {
            get
            {
                if (s_MainTaskDistributor == null)
                    throw new System.InvalidOperationException("No default TaskDistributor found, please create a new TaskDistributor instance before calling this property.");

                return s_MainTaskDistributor;
            }
        }

        /// <summary>
        /// Creates a new instance of the TaskDistributor with ProcessorCount x3 worker threads.
        /// The task distributor will auto start his worker threads.
        /// </summary>
        public TaskDistributor()
            : this(0)
        {
        }

        /// <summary>
        /// Creates a new instance of the TaskDistributor.
        /// The task distributor will auto start his worker threads.
        /// </summary>
        /// <param name="workerThreadCount">The number of worker threads, a value below one will create ProcessorCount x3 worker threads.</param>
        public TaskDistributor(int workerThreadCount)
            : this(workerThreadCount, true)
        {
        }

        /// <summary>
        /// Creates a new instance of the TaskDistributor.
        /// </summary>
        /// <param name="workerThreadCount">The number of worker threads, a value below one will create ProcessorCount x3 worker threads.</param>
        /// <param name="autoStart">Should the instance auto start the worker threads.</param>
        public TaskDistributor(int workerThreadCount, bool autoStart)
        {
            if (workerThreadCount <= 0)
                workerThreadCount = UnityEngine.SystemInfo.processorCount * 3;

            m_WorkerThreads = new TaskWorker[workerThreadCount];
            lock (m_WorkerThreads)
            {
                for (var i = 0; i < workerThreadCount; ++i)
                    m_WorkerThreads [i] = new TaskWorker(this);
            }

            if (s_MainTaskDistributor == null)
                s_MainTaskDistributor = this;

            if (autoStart)
                Start();
        }

        /// <summary>
        /// Starts the TaskDistributor if its not currently running.
        /// </summary>
        public void Start()
        {
            lock (m_WorkerThreads)
            {
                for (var i = 0; i < m_WorkerThreads.Length; ++i)
                {
                    if (!m_WorkerThreads [i].isAlive)
                    {
                        m_WorkerThreads [i].dispatcher.AddTasks(SplitTasks(m_WorkerThreads.Length));
                        m_WorkerThreads [i].Start();
                    }
                }
            }
        }

        internal void FillTasks(DispatcherBase target)
        {
            target.AddTasks(IsolateTasks(1));
        }

        protected override void CheckAccessLimitation()
        {
            if (ThreadBase.currentThread is TaskWorker && ((TaskWorker)ThreadBase.currentThread).taskDistributor == this)
            {
                throw new System.InvalidOperationException("Access to TaskDistributor prohibited when called from inside a TaskDistributor thread. Dont dispatch new Tasks through the same TaskDistributor. If you want to distribute new tasks create a new TaskDistributor and use the new created instance. Remember to dispose the new instance to prevent thread spamming.");
            }
        }

        #region IDisposable Members

        /// <summary>
        /// Disposes all TaskDistributor, worker threads, resources and remaining tasks.
        /// </summary>
        public override void Dispose()
        {
            while (true)
            {
                TaskBase currentTask;
                lock (m_TaskQueue)
                {
                    if (m_TaskQueue.Count != 0)
                        currentTask = m_TaskQueue.Dequeue();
                    else
                        break;
                }
                currentTask.Dispose();
            }

            lock (m_WorkerThreads)
            {
                for (var i = 0; i < m_WorkerThreads.Length; ++i)
                    m_WorkerThreads[i].Dispose();
                m_WorkerThreads = new TaskWorker[0];
            }

            m_DataEvent.Close();
            m_DataEvent = null;

            if (s_MainTaskDistributor == this)
                s_MainTaskDistributor = null;
        }
        public void AbortAll()
        {
            while (true)
            {
                TaskBase currentTask;
                lock (m_TaskQueue)
                {
                    if (m_TaskQueue.Count != 0)
                        currentTask = m_TaskQueue.Dequeue();
                    else
                        break;
                }
                currentTask.Abort();
            }
        }
        public void AbortAllWaitForSeconds(float seconds)
        {
            var events = new List<WaitHandle>();

            while (true)
            {
                TaskBase currentTask;
                lock (m_TaskQueue)
                {
                    if (m_TaskQueue.Count != 0)
                    {
                        currentTask = m_TaskQueue.Dequeue();
                        events.Add(currentTask.GetAbortEvent());
                    }
                    else
                        break;
                }

                currentTask.Abort();
            }

            WaitHandle.WaitAll(events.ToArray(), System.TimeSpan.FromSeconds(seconds));
        }
        #endregion
    }
/*! \cond PRIVATE */
    sealed class TaskWorker : ThreadBase
    {
        public Dispatcher dispatcher;
        public TaskDistributor taskDistributor;

        WaitHandle[] m_WaitHandles = new WaitHandle[2];

        public TaskWorker(TaskDistributor taskDistributor)
            : base(false)
        {
            this.taskDistributor = taskDistributor;
            this.dispatcher = new Dispatcher(false);
        }
        
        bool CheckExitEvent()
        {
            return ThreadUtility.WaitOne(m_ExitEvent, 0);
        }
        
        protected override void Do()
        {
            while (!CheckExitEvent())
            {
                if (!dispatcher.ProcessNextTask())
                {
                    taskDistributor.FillTasks(dispatcher);
                    if (dispatcher.taskCount == 0)
                    {
                        m_WaitHandles[0] = m_ExitEvent;
                        m_WaitHandles[1] = taskDistributor.NewDataWaitHandle;
                        var result = WaitHandle.WaitAny(m_WaitHandles);
                        if (result == 0)
                            return;
                        taskDistributor.FillTasks(dispatcher);
                    }
                }
            }
        }
/*! \endcond */
        public override void Dispose()
        {
            base.Dispose();
            if (dispatcher != null)
                dispatcher.Dispose();
            dispatcher = null;
        }
    }
}
