﻿//
// LetterTileAnimation.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using UnityEngine;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using Thinksquirrel.WordGameBuilderInternal;

#if !UNITY_3_5
namespace Thinksquirrel.WordGameBuilder.Tiles
{
#else
using Thinksquirrel.WordGameBuilder;
#endif
    /// <summary>
    /// Adds animation to a letter tile.
    /// </summary>
    /// <remarks>
    /// This component must be on the same object as a letter tile.
    /// </remarks>
    [RequireComponent(typeof(ILetterTileDisplay))]
    [AddComponentMenu("Word Game Builder/Tiles/Letter Tile Visibility")]
    [WGBDocumentationName("Thinksquirrel.WordGameBuilder.Tiles.LetterTileAnimation")]
    public sealed class LetterTileAnimation : WGBBase
    {
        [SerializeField] Animation m_TileAnimation;
        [SerializeField] AnimationClip m_SpawnAnimationClip;
        [SerializeField] AnimationClip m_EnableAnimationClip;
        [SerializeField] AnimationClip m_DisableAnimationClip;
        [SerializeField] AnimationClip m_ChangeAnimationClip;

        ILetterTileDisplay m_LetterTile;
        bool m_IsInitialized;
        bool m_LastEnabledState;

        /// <summary>
        /// The animation component to use. If this value is not set, any animation component on this component's GameObject will be used.
        /// </summary>
        public Animation tileAnimation
        {
            get { return m_TileAnimation; }
            set
            {
                if (m_TileAnimation != value)
                {
                    if (m_TileAnimation)
                        Uninitialize();

                    m_TileAnimation = value;
                    Initialize();
                }
            }
        }
        /// <summary>
        /// The animation clip to play when a tile spawns.
        /// </summary>
        public AnimationClip spawnAnimationClip
        {
            get { return m_SpawnAnimationClip; }
            set
            {
                if (m_SpawnAnimationClip != value)
                {
                    if (m_TileAnimation)
                        Uninitialize();

                    m_SpawnAnimationClip = value;
                    Initialize();
                }
            }
        }
        /// <summary>
        /// The animation clip to play when a tile is enabled.
        /// </summary>
        public AnimationClip enableAnimationClip
        {
            get { return m_EnableAnimationClip; }
            set
            {
                if (m_EnableAnimationClip != value)
                {
                    if (m_TileAnimation)
                        Uninitialize();
                    
                    m_EnableAnimationClip = value;
                    Initialize();
                }
            }
        }
        /// <summary>
        /// The animation clip to play when a tile is disabled.
        /// </summary>
        public AnimationClip disableAnimationClip
        {
            get { return m_DisableAnimationClip; }
            set
            {
                if (m_DisableAnimationClip != value)
                {
                    if (m_TileAnimation)
                        Uninitialize();
                    
                    m_DisableAnimationClip = value;
                    Initialize();
                }
            }
        }
        /// <summary>
        /// The animation clip to play when a tile changes, and its enabled state has not changed.
        /// </summary>
        public AnimationClip changeAnimationClip
        {
            get { return m_ChangeAnimationClip; }
            set
            {
                if (m_ChangeAnimationClip != value)
                {
                    if (m_TileAnimation)
                        Uninitialize();

                    m_ChangeAnimationClip = value;
                    Initialize();
                }
            }
        }

        void OnEnable()
        {
            hideFlags = HideFlags.NotEditable;

            m_LetterTile = GetComponentFromInterface<ILetterTileDisplay>();

            if (m_LetterTile == null)
                return;

            m_LetterTile.onTileSpawn += UpdateSpawnAnimation;
            m_LetterTile.onTileChange += UpdateChangeAnimation;
            
            if (!m_TileAnimation)
                m_TileAnimation = animation;

            Initialize();
        }

        void Initialize()
        {
            if (!m_TileAnimation)
                return;

            m_TileAnimation.playAutomatically = false;

            if (m_SpawnAnimationClip)
            {
                m_TileAnimation.AddClip(m_SpawnAnimationClip, "OnTileSpawn");
                m_TileAnimation["OnTileSpawn"].layer = 0;
            }
            if (m_EnableAnimationClip)
            {
                m_TileAnimation.AddClip(m_EnableAnimationClip, "OnTileEnable");
                m_TileAnimation["OnTileEnable"].layer = 1;
            }
            if (m_DisableAnimationClip)
            {
                m_TileAnimation.AddClip(m_DisableAnimationClip, "OnTileDisable");
                m_TileAnimation["OnTileDisable"].layer = 2;
            }
            if (m_ChangeAnimationClip)
            {
                m_TileAnimation.AddClip(m_ChangeAnimationClip, "OnTileChange");
                m_TileAnimation["OnTileChange"].layer = 3;
            }

            m_IsInitialized = true;
        }

        void Uninitialize()
        {
            if (!m_TileAnimation || !m_IsInitialized)
                return;
            
            if (m_SpawnAnimationClip)
            {
                m_TileAnimation.RemoveClip("OnTileSpawn");
            }
            if (m_EnableAnimationClip)
            {
                m_TileAnimation.RemoveClip("OnTileEnable");
            }
            if (m_DisableAnimationClip)
            {
                m_TileAnimation.RemoveClip("OnTileDisable");
            }
            if (m_ChangeAnimationClip)
            {
                m_TileAnimation.RemoveClip("OnTileChange");
            }

            m_IsInitialized = false;
        }

        void OnDisable()
        {
            if (m_LetterTile == null)
                return;

            m_LetterTile.onTileSpawn -= UpdateSpawnAnimation;
            m_LetterTile.onTileChange -= UpdateChangeAnimation;
        
            Uninitialize();
        }
        
        void UpdateSpawnAnimation()
        {
            if (!m_TileAnimation)
                return;

            bool spawn = m_LetterTile.isActive;

            if (m_SpawnAnimationClip && spawn)
            {
                m_TileAnimation.enabled = true;
                m_TileAnimation.Play("OnTileSpawn", PlayMode.StopSameLayer);
            }

            if (!spawn)
            {
                m_TileAnimation.Rewind();
                m_TileAnimation.enabled = false;
            }
        }

        void UpdateChangeAnimation()
        {
            if (!m_TileAnimation || !m_LetterTile.shouldAnimate)
                return;

            if (m_LastEnabledState != m_LetterTile.enabled)
            {
                if (m_LastEnabledState && m_DisableAnimationClip)
                    m_TileAnimation.Play("OnTileDisable", PlayMode.StopSameLayer);

                if (!m_LastEnabledState && m_EnableAnimationClip)
                    m_TileAnimation.Play("OnTileEnable", PlayMode.StopSameLayer);

                m_LastEnabledState = m_LetterTile.enabled;
            }
            else
            {
                if (m_ChangeAnimationClip)
                {
                    m_TileAnimation.Play("OnTileChange", PlayMode.StopSameLayer);
                }
            }
        }
    }
#if !UNITY_3_5
}
#endif
