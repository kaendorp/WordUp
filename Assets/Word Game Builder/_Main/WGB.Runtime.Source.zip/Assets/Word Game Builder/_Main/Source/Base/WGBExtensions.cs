//
// WGBExtensions.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
#if (UNITY_WP8 || UNITY_METRO || NETFX_CORE) && !UNITY_EDITOR
#define UNITY_WIN8_RUNTIME
#endif
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using Random = System.Random;


namespace Thinksquirrel.WordGameBuilder
{
    /// <summary>
    /// Contains extension methods for various classes.
    /// </summary>
    public static class WGBExtensions
    {
#if UNITY_WIN8_RUNTIME
        internal static PropertyInfo GetProperty(this System.Type type, string propertyName)
        {
            return type.GetTypeInfo().GetDeclaredProperty(propertyName);
        }
        internal static EventInfo GetEvent(this System.Type type, string eventName)
        {
            return type.GetTypeInfo().GetDeclaredEvent(eventName);
        }
        internal static MethodInfo GetMethod(this System.Type type, string methodName)
        {
            return type.GetTypeInfo().GetDeclaredMethod(methodName);
        }
        internal static IEnumerable<MethodInfo> GetMethods(this System.Type type, string methodName)
        {
            return type.GetTypeInfo().GetDeclaredMethods(methodName);
        }
        internal static FieldInfo GetField(this System.Type type, string fieldName)
        {
            return type.GetTypeInfo().GetDeclaredField(fieldName);
        }
        internal static Type GetNestedType(this System.Type type, string typeName)
        {
            return type.GetTypeInfo().GetDeclaredNestedType(typeName).AsType();
        }
#else
        internal static IEnumerable<MethodInfo> GetMethods(this System.Type type, string methodName)
        {
            return type.GetMethods().Where(m => m.Name == methodName);
        }
        internal static System.Delegate CreateDelegate(this MethodInfo methodInfo, System.Type delegateType, object target)
        {
            return System.Delegate.CreateDelegate(delegateType, target, methodInfo);
        }
#endif
        /// <summary>
        /// Gets a component from its interface type. (Extension method)
        /// </summary>
        /// <typeparam name='T'>
        /// The interface type of the component. Must be an IMonoBehaviour.
        /// </typeparam>
        /// <param name="gameObject">The GameObject to search.</param>
        /// <returns>The found object as an interface. Returns null if no object was found.</returns>
        public static T GetComponentFromInterface<T>(this GameObject gameObject) where T : class, IMonoBehaviour
        {
            return FindInterface<T>(gameObject.GetComponents<MonoBehaviour>());
        }
        /// <summary>
        /// Gets all components from its interface type. (Extension method)
        /// </summary>
        /// <typeparam name='T'>
        /// The interface type of the component. Must be an IMonoBehaviour.
        /// </typeparam>
        /// <param name="gameObject">The GameObject to search.</param>
        /// <returns>An array of found objects, as an interface. Returns an empty array if no objects were found.</returns>
        public static T[] GetComponentsFromInterface<T>(this GameObject gameObject) where T : class, IMonoBehaviour
        {
            return FindInterfaces<T>(gameObject.GetComponents<MonoBehaviour>());
        }
        /// <summary>
        /// Gets a component from its interface type, searching through this GameObject and all children. (Extension method)
        /// </summary>
        /// <typeparam name='T'>
        /// The interface type of the component. Must be an IMonoBehaviour.
        /// </typeparam>
        /// <param name="gameObject">The GameObject to search.</param>
        /// <returns>The found object as an interface. Returns null if no object was found.</returns>
        public static T GetComponentInChildrenFromInterface<T>(this GameObject gameObject) where T : class, IMonoBehaviour
        {
            return FindInterface<T>(gameObject.GetComponentsInChildren<MonoBehaviour>());
        }
        /// <summary>
        /// Gets all components from its interface type, searching through this GameObject and all children. (Extension method)
        /// </summary>
        /// <typeparam name='T'>
        /// The interface type of the component. Must be an IMonoBehaviour.
        /// </typeparam>
        /// <param name="gameObject">The GameObject to search.</param>
        /// <returns>An array of found objects, as an interface. Returns an empty array if no objects were found.</returns>
        public static T[] GetComponentsInChildrenFromInterface<T>(this GameObject gameObject) where T : class, IMonoBehaviour
        {
            return FindInterfaces<T>(gameObject.GetComponentsInChildren<MonoBehaviour>());
        }
        /// <summary>
        /// Gets a component from its interface type. (Extension method)
        /// </summary>
        /// <typeparam name='T'>
        /// The interface type of the component. Must be an IMonoBehaviour.
        /// </typeparam>
        /// <param name="component">The Component to search.</param>
        /// <returns>The found object as an interface. Returns null if no object was found.</returns>
        public static T GetComponentFromInterface<T>(this Component component) where T : class, IMonoBehaviour
        {
            return GetComponentFromInterface<T>(component.gameObject);
        }
        /// <summary>
        /// Gets all components from its interface type. (Extension method)
        /// </summary>
        /// <typeparam name='T'>
        /// The interface type of the component. Must be an IMonoBehaviour.
        /// </typeparam>
        /// <param name="component">The Component to search.</param>
        /// <returns>An array of found objects, as an interface. Returns an empty array if no objects were found.</returns>
        public static T[] GetComponentsFromInterface<T>(this Component component) where T : class, IMonoBehaviour
        {
            return GetComponentsFromInterface<T>(component.gameObject);
        }
        /// <summary>
        /// Gets a component from its interface type, searching through this GameObject and all children. (Extension method)
        /// </summary>
        /// <typeparam name='T'>
        /// The interface type of the component. Must be an IMonoBehaviour.
        /// </typeparam>
        /// <param name="component">The Component to search.</param>
        /// <returns>The found object as an interface. Returns null if no object was found.</returns>
        public static T GetComponentInChildrenFromInterface<T>(this Component component) where T : class, IMonoBehaviour
        {
            return GetComponentInChildrenFromInterface<T>(component.gameObject);
        }
        /// <summary>
        /// Gets all components from its interface type, searching through this GameObject and all children. (Extension method)
        /// </summary>
        /// <typeparam name='T'>
        /// The interface type of the component. Must be an IMonoBehaviour.
        /// </typeparam>
        /// <param name="component">The Component to search.</param>
        /// <returns>An array of found objects, as an interface. Returns an empty array if no objects were found.</returns>
        public static T[] GetComponentsInChildrenFromInterface<T>(this Component component) where T : class, IMonoBehaviour
        {
            return GetComponentsInChildrenFromInterface<T>(component.gameObject);
        }

        internal static T FindInterface<T>(Object[] objects) where T : class, IMonoBehaviour
        {
            for (int i = 0; i < objects.Length; i++)
            {
                var c = objects[i] as T;
                if (c != null)
                {
                    return c;
                }
            }

            return null;
        }
        internal static T[] FindInterfaces<T>(Object[] objects) where T : class, IMonoBehaviour
        {
            var result = new List<T>();
            for (int i = 0; i < objects.Length; i++)
            {
                var c = objects[i] as T;
                if (c != null)
                {
                    result.Add(c);
                }
            }

            return result.ToArray();
        }

       	internal static T GetRandomElement<T>(this ICollection<T> collection, Random rand)
        {
            // If there are no elements in the collection, return the default value of T
            int count = collection.Count;
            return count == 0 ? default(T) : collection.ElementAt(rand.Next(count));
        }
             
        internal static void Shuffle<T>(this IList<T> list, Random rand)
        {
            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = rand.Next(n + 1);
                T value = list [k];
                list [k] = list [n];
                list [n] = value;
            }
        }
    }
}
