﻿//
// TweenTimer.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2014 Thinksquirrel Software, LLC
//
using UnityEngine;
using Thinksquirrel.WordGameBuilder;

#if !UNITY_3_5
namespace Thinksquirrel.WordGameBuilderInternal.Tweening
{
#else
using Thinksquirrel.WordGameBuilderInternal.Tweening;
#endif
    [AddComponentMenu("")]
    class TweenTimer : WGBBase
    {
        static System.Action<float> s_OnTweenUpdate;
        public static event System.Action<float> onTweenUpdate
        {
            add
            {
                EnsureInstance();
                s_OnTweenUpdate += value;
            }
            remove
            {
                // Analysis disable DelegateSubtraction
                s_OnTweenUpdate -= value;
                // Analysis restore DelegateSubtraction
            }
        }

        static TweenTimer s_Instance;
        static void EnsureInstance()
        {
            // Analysis disable RedundantCast
            if ((object)s_Instance == null)
            {
                s_Instance = FindObjectOfType(typeof(TweenTimer)) as TweenTimer;
                if (!s_Instance)
                {
                    var go = new GameObject("TweenTimer");
                    go.hideFlags = HideFlags.HideInHierarchy;
                    DontDestroyOnLoad(go);
                    s_Instance = go.AddComponent<TweenTimer>();
                }
            }
            // Analysis restore RedundantCast
        }

        void Update()
        {
            if (s_OnTweenUpdate != null)
                s_OnTweenUpdate(Time.realtimeSinceStartup);
        }
    }
#if !UNITY_3_5
}
#endif
