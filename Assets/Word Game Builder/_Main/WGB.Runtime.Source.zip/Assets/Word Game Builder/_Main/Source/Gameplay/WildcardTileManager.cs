//
// WildcardTileManager.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using UnityEngine;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using Thinksquirrel.WordGameBuilderInternal;

#if !UNITY_3_5
namespace Thinksquirrel.WordGameBuilder.Gameplay
{
#else
using Thinksquirrel.WordGameBuilder;
using Thinksquirrel.WordGameBuilder.Gameplay;
#endif
    /// <summary>
    /// A manager class for selecting wildcard tiles.
    /// </summary>
    /// <remarks>
    /// This component does not have any implementation on if/how wildcard tiles should be selected.
    /// It only sends a message to a target game object, which provides the implementation.
    /// </remarks>
    [AddComponentMenu("Word Game Builder/Gameplay/Wildcard Tile Manager")]
    [WGBDocumentationName("Thinksquirrel.WordGameBuilder.Gameplay.WildcardTileManager")]
    public sealed class WildcardTileManager : WGBBase, IWildcardTileManager
    {
        [SerializeField] WGBEvent m_OnWildcardTileSelect;

        /// <summary>
        /// This event fires when a selection attempt occurs on a blank tile.
        /// </summary>
        /// <remarks>
        /// Variables set:
        /// * WGBEvent.currentLanguage
        /// * WGBEvent.currentLetterTile
        /// * WGBEvent.currentWildcardTileManager
        /// * WGBEvent.currentPlayer
        ///
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWildcardTileManager.onWildcardTileSelect">IWildcardTileManager</see>.
        /// </remarks>
        public WGBEvent onWildcardTileSelect { get { return m_OnWildcardTileSelect; } set { m_OnWildcardTileSelect = value; } }

        public void SelectWildcardTile(ILetterTile tile, WordGameLanguage lang, IWordGamePlayer player)
        {
            WGBEvent.Invoke(m_OnWildcardTileSelect, lang, tile, null, this, player, null);
        }
    }
#if !UNITY_3_5
}
#endif
