//
// ThreadUtility.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using UnityEngine;
using System.Collections.Generic;
using Thinksquirrel.WordGameBuilder;

namespace Thinksquirrel.WordGameBuilderInternal.Threading
{
    /// <summary>
    /// Thread helper component. Handles dispatchers and distributors and manages threads.
    /// </summary>
    /*! \author Original Unity Thread Helper classes (c) 2011 Marrrk (http://forum.unity3d.com/members/39278-Marrrk)*/
    [AddComponentMenu("")]
    sealed class ThreadUtility : WGBBase
    {
        static ThreadUtility s_Instance;
        static bool s_IsWebPlayer;
        // HACK - Web player support
        static System.Reflection.MethodInfo s_WebPlayerWaitMethod1;
        static System.Reflection.MethodInfo s_WebPlayerWaitMethod2;
        [System.ThreadStatic] static object[] s_WaitOneArgs;

        static ThreadUtility instance
        {
            get
            {
                EnsureInstance();
                return s_Instance;
            }
        }
    
        public static void EnsureInstance()
        {
            // Analysis disable RedundantCast
            if ((object)s_Instance == null)
            {
                s_Instance = FindObjectOfType(typeof(ThreadUtility)) as ThreadUtility;
                if (!s_Instance)
                {
                    s_IsWebPlayer = Application.isWebPlayer;
                    var go = new GameObject("ThreadDispatcher");
                    go.hideFlags = HideFlags.HideInHierarchy;
                    DontDestroyOnLoad(go);
                    s_Instance = go.AddComponent<ThreadUtility>();
                    s_Instance.EnsureHelper();
                }
            }
            // Analysis restore RedundantCast
        }

        public static bool isWebPlayer
        {
            get
            {
                return s_IsWebPlayer;
            }
        }
        
        static void CacheWaitOneMethods()
        {
            var type = typeof(System.Threading.WaitHandle);
            var methods = type.GetMethods("WaitOne");
            var enumerator = methods.GetEnumerator();

            while (enumerator.MoveNext())
            {
                var method = enumerator.Current;

                var parameters = method.GetParameters();

                if (parameters.Length != 1)
                    continue;

                if (parameters[0].ParameterType == typeof(int))
                    s_WebPlayerWaitMethod1 = method;
                else if (parameters[0].ParameterType == typeof(System.TimeSpan))
                    s_WebPlayerWaitMethod2 = method;
            }
        }

        public static bool WaitOne(System.Threading.WaitHandle evt)
        {
            return evt.WaitOne();
        }

        public static bool WaitOne(System.Threading.WaitHandle evt, int ms)
        {
            if (evt == null)
                return false;

            if (!s_IsWebPlayer)
            {
                return evt.WaitOne(ms, false);
            }

            if (s_WaitOneArgs == null)
                s_WaitOneArgs = new object[1];

            s_WaitOneArgs[0] = ms;
            
            if (s_WebPlayerWaitMethod1 == null)
                CacheWaitOneMethods();

            return s_WebPlayerWaitMethod1 != null && (bool)s_WebPlayerWaitMethod1.Invoke(evt, s_WaitOneArgs);

        }

        public static bool WaitOne(System.Threading.WaitHandle evt, System.TimeSpan timeSpan)
        {
            if (evt == null)
                return false;

            if (!s_IsWebPlayer)
            {
                return evt.WaitOne(timeSpan, false);
            }

            if (s_WaitOneArgs == null)
                s_WaitOneArgs = new object[1];

            s_WaitOneArgs[0] = timeSpan;

            if (s_WebPlayerWaitMethod2 == null)
                CacheWaitOneMethods();

            return s_WebPlayerWaitMethod2 != null && (bool)s_WebPlayerWaitMethod2.Invoke(evt, s_WaitOneArgs);

        }
        
        /// <summary>
        /// Returns the GUI/Main Dispatcher.
        /// </summary>
        public static Dispatcher dispatcher
        {
            get
            {
                return instance.currentDispatcher;
            }
        }
    
        /// <summary>
        /// Returns the TaskDistributor.
        /// </summary>
        public static TaskDistributor taskDistributor
        {
            get
            {
                return instance.currentTaskDistributor;
            }
        }
/*! \cond PRIVATE */
        Dispatcher m_Dispatcher;

        public Dispatcher currentDispatcher
        {
            get
            {
                return m_Dispatcher;
            }
        }
    
        TaskDistributor m_TaskDistributor;

        public TaskDistributor currentTaskDistributor
        {
            get
            {
                return m_TaskDistributor;
            }
        }
/*! \endcond */
        
        void EnsureHelper()
        {
            if (m_Dispatcher == null)
                m_Dispatcher = new Dispatcher();
    
            if (m_TaskDistributor == null)
                m_TaskDistributor = new TaskDistributor();
        }
    
        /// <summary>
        /// Creates new thread which runs the given action. The given action will be wrapped so that any exception will be catched and logged.
        /// </summary>
        /// <param name="action">The action which the new thread should run.</param>
        /// <param name="autoStartThread">True when the thread should start immediately after creation.</param>
        /// <returns>The instance of the created thread class.</returns>
        public static ActionThread CreateThread(System.Action<ActionThread> action, bool autoStartThread)
        {
            instance.EnsureHelper();
    
            System.Action<ActionThread> actionWrapper = currentThread =>
            {
                try
                {
                    action(currentThread);
                }
                catch (System.Exception ex)
                {
                    WGBBase.LogException(ex);
                }
            };
            var thread = new ActionThread(actionWrapper, autoStartThread);
            instance.RegisterThread(thread);
            return thread;
        }
    
        /// <summary>
        /// Creates new thread which runs the given action and starts it after creation. The given action will be wrapped so that any exception will be catched and logged.
        /// </summary>
        /// <param name="action">The action which the new thread should run.</param>
        /// <returns>The instance of the created thread class.</returns>
        public static ActionThread CreateThread(System.Action<ActionThread> action)
        {
            return CreateThread(action, true);
        }
    
        /// <summary>
        /// Creates new thread which runs the given action. The given action will be wrapped so that any exception will be catched and logged.
        /// </summary>
        /// <param name="action">The action which the new thread should run.</param>
        /// <param name="autoStartThread">True when the thread should start immediately after creation.</param>
        /// <returns>The instance of the created thread class.</returns>
        public static ActionThread CreateThread(System.Action action, bool autoStartThread)
        {
            return CreateThread(thread => action(), autoStartThread);
        }
    
        /// <summary>
        /// Creates new thread which runs the given action and starts it after creation. The given action will be wrapped so that any exception will be catched and logged.
        /// </summary>
        /// <param name="action">The action which the new thread should run.</param>
        /// <returns>The instance of the created thread class.</returns>
        public static ActionThread CreateThread(System.Action action)
        {
            return CreateThread(thread => action(), true);
        }
    
        List<ThreadBase> m_RegisteredThreads = new List<ThreadBase>();

        void RegisterThread(ThreadBase thread)
        {
            m_RegisteredThreads.Add(thread);
        }
    
        void OnDestroy()
        {
            for (int i = 0; i < m_RegisteredThreads.Count; i++)
            {
                var thread = m_RegisteredThreads[i];
                thread.Dispose();
            }
    
            if (m_Dispatcher != null)
                m_Dispatcher.Dispose();
            m_Dispatcher = null;
    
            if (m_TaskDistributor != null)
                m_TaskDistributor.Dispose();
            m_TaskDistributor = null;
        }
    
        void Update()
        {
            if (m_Dispatcher != null)
                m_Dispatcher.ProcessTasks();
    
            for(int i = m_RegisteredThreads.Count - 1; i >= 0; --i)
            {
                var thread = m_RegisteredThreads[i];
                if (thread.isAlive)
                    continue;

                thread.Dispose();
                m_RegisteredThreads.RemoveAt(i);
            }
        }
    }
}
