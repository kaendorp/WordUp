﻿//
// AsyncTask.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using InternalTask = Thinksquirrel.WordGameBuilderInternal.Threading.Task;
using Thinksquirrel.WordGameBuilderInternal;

namespace Thinksquirrel.WordGameBuilder
{
    /// <summary>
    /// Represents an asynchronous task.
    /// </summary>
    public sealed class AsyncTask : System.IDisposable
    {
        internal InternalTask _internalTask;
        internal static ObjectPool<AsyncTask> _taskPool; // Using a pool to allocate more tasks earlier

        AsyncTask(InternalTask internalTask)
        {
            _internalTask = internalTask;
        }

        internal static AsyncTask Create(InternalTask internalTask)
        {
            if (_taskPool == null)
                _taskPool = new ObjectPool<AsyncTask>(() => new AsyncTask(internalTask), task => task._internalTask = null );

            return _taskPool.Pop();
        }

        internal bool shouldAbort
        {
            get
            {
                return _internalTask != null && _internalTask.shouldAbort;
            }
        }
        
        /// <summary>
        /// Returns true if this task has ended, been skipped, or been aborted.
        /// </summary>
        public bool hasEnded
        {
            get
            {
                return _internalTask == null || _internalTask.hasEnded;
            }
        }
        
        /// <summary>
        /// Returns true if this task was successful.
        /// </summary>
        public bool isSucceeded
        {
            get
            {
                return _internalTask == null || _internalTask.isSucceeded;
            }
        }
        
        /// <summary>
        /// Returns true if this task has failed.
        /// </summary>
        public bool isFailed
        {
            get
            {
                return _internalTask != null && _internalTask.isFailed;
            }
        }
        
        /// <summary>
        /// Abort this task.
        /// </summary>
        public void Abort()
        {
            if (_internalTask != null)
                _internalTask.Abort();
        }
        
        /// <summary>
        /// Abort this task, and wait until it has ended.
        /// </summary>
        public void AbortWait()
        {
            if (_internalTask != null)
                _internalTask.AbortWait();
        }
        
        /// <summary>
        /// Abort this task, and wait until it has ended, or the specified amount of time (in seconds) has passed.
        /// </summary>
        /// <param name='seconds'>The maximum amount of seconds to wait.</param>
        public void AbortWaitForSeconds(float seconds)
        {
            if (_internalTask != null)
                _internalTask.AbortWaitForSeconds(seconds);
        }
        
        /// <summary>
        /// Blocks the calling thread until the task has ended.
        /// </summary>
        public void Wait()
        {
            if (_internalTask != null)
                _internalTask.Wait();
        }
        
        /// <summary>
        /// Blocks the calling thread until the task has ended, or the specified amount of time (in seconds) has passed.
        /// </summary>
		/// <param name='seconds'>The maximum amount of seconds to wait.</param>
        public void WaitForSeconds(float seconds)
        {
            if (_internalTask != null)
                _internalTask.WaitForSeconds(seconds);
        }

        /// <summary>
        /// Disposes this task and waits for completion if it is still running.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            System.GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Places this task back into an object pool. Use this to eliminate garbage collection on the task and reuse it later.
        /// </summary>
        /// <remarks>
        /// This will not abort the task or wait for completion; however, the task object itself will no longer be usable.
        /// </remarks>
        public void SetReusable()
        {
            _taskPool.Push(this);
        }

        void Dispose(bool isDisposing)
        {
            // Decrease the pool capacity to ease up memory pressure
            _taskPool.Capacity -= 1;

            if (isDisposing)
            {
                if (_internalTask != null)
                    _internalTask.Dispose();
            }
            else if (_internalTask != null)
            {
                InternalTask.Destroy(_internalTask);
            }

            _internalTask = null;
        }

        ~ AsyncTask()
        {
            Dispose(false);
        }
    }
}
