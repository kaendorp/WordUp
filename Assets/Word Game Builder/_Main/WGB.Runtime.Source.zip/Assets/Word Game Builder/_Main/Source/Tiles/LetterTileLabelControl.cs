﻿//
// LetterTileLabelControl.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using UnityEngine;
using Thinksquirrel.WordGameBuilderInternal;
using Thinksquirrel.WordGameBuilder.ObjectModel;

#if !UNITY_3_5
namespace Thinksquirrel.WordGameBuilder.Tiles
{
#else
using Thinksquirrel.WordGameBuilder;
#endif
    /// <summary>
    /// Automatically controls the text on objects based on a letter tile's state.
    /// </summary>
    /// <remarks>
    /// This component must be on the same object as a letter tile.
    /// </remarks>
    [RequireComponent(typeof(ILetterTileDisplay))]
    [AddComponentMenu("Word Game Builder/Tiles/Letter Tile Label Control")]
    [WGBDocumentationName("Thinksquirrel.WordGameBuilder.Tiles.LetterTileLabelControl")]
    public sealed class LetterTileLabelControl : WGBBase
    {
        [SerializeField] Object m_LetterLabel;
        [SerializeField] Object m_ScoreLabel;

        /// <summary>
        /// The letter label.
        /// </summary>
        /// <remarks>
        /// Supported object types:
        /// * TextMesh
        /// * GUIText
        /// * GameObject (will select the first component)
        /// </remarks>
        public Object letterLabel { get { return m_LetterLabel; } set { m_LetterLabel = value; } }
        /// <summary>
        /// The score label.
        /// </summary>
        /// <remarks>
        /// Supported object types:
        /// * TextMesh
        /// * GUIText
        /// * GameObject (will select the first component)
        /// </remarks>
        public Object scoreLabel { get { return m_ScoreLabel; } set { m_ScoreLabel = value; } }

        ILetterTileDisplay m_LetterTile;

        void OnEnable()
        {
            m_LetterTile = GetComponentFromInterface<ILetterTileDisplay>();

            if (m_LetterTile != null)
            {
                m_LetterTile.onTileChange += UpdateTileLabel;
            }
            UpdateTileLabel();
        }

        void OnDisable()
        {
            if (m_LetterTile != null)
            {
                m_LetterTile.onTileChange -= UpdateTileLabel;
            }
        }

        void UpdateTileLabel()
        {
            if (!m_LetterTile.shouldChangeLabel)
                return;

            if (m_LetterLabel != null)
            {
                var letterGameObject = m_LetterLabel as GameObject;
                var textMesh = letterGameObject != null ? letterGameObject.GetComponent<TextMesh>() : m_LetterLabel as TextMesh;
                var guiTxt = letterGameObject != null ? letterGameObject.GetComponent<GUIText>() : m_LetterLabel as GUIText;

                if (textMesh != null && textMesh)
                {
                    textMesh.text = m_LetterTile.currentLetterLabel;
                }
                else if (guiTxt != null && guiTxt)
                {
                    guiTxt.text = m_LetterTile.currentLetterLabel;
                }
            }
            if (m_ScoreLabel != null)
            {
                var scoreGameObject = m_ScoreLabel as GameObject;
                var textMesh = scoreGameObject != null ? scoreGameObject.GetComponent<TextMesh>() : m_ScoreLabel as TextMesh;
                var guiTxt = scoreGameObject != null ? scoreGameObject.GetComponent<GUIText>() : m_ScoreLabel as GUIText;

                if (textMesh != null && textMesh)
                {
                    textMesh.text = m_LetterTile.currentScoreLabel;
                }
                else if (guiTxt != null && guiTxt)
                {
                    guiTxt.text = m_LetterTile.currentScoreLabel;
                }
            }
        }
    }
    #if !UNITY_3_5
}
#endif
