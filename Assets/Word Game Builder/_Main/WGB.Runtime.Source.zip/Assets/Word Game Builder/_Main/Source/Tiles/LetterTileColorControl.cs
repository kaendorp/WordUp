﻿//
// LetterTileColorControl.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using UnityEngine;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using Thinksquirrel.WordGameBuilderInternal;

#if !UNITY_3_5
namespace Thinksquirrel.WordGameBuilder.Tiles
{
#else
using Thinksquirrel.WordGameBuilder;
#endif
    /// <summary>
    /// Automatically controls the color of objects based on a letter tile's state.
    /// </summary>
    /// <remarks>
    /// This component must be on the same object as a letter tile.
    /// </remarks>
    [RequireComponent(typeof(ILetterTileDisplay))]
    [AddComponentMenu("Word Game Builder/Tiles/Letter Tile Color Control")]
    [WGBDocumentationName("Thinksquirrel.WordGameBuilder.Tiles.LetterTileColorControl")]
    public sealed class LetterTileColorControl : WGBBase
    {
        [SerializeField] Object[] m_Background;
        [SerializeField] Object[] m_Text;
        [SerializeField] string[] m_ColorProperties = { "_Color", "_TintColor" };

        /// <summary>
        /// The background objects to control with this component.
        /// </summary>
        /// <remarks>
        /// Accessing this property at runtime may cause new materials/meshes to be instantiated.
        ///
        /// Supported object types:
        /// * SpriteRenderer [Unity 4.3+] (color)
        /// * Renderer (color properties on material shader)
        /// * MeshFilter (vertex colors)
        /// * GameObject (will select the first component)
        /// </remarks>
        public Object[] background { get { m_CopiedMaterialsBackground = false; return m_Background; } set { m_CopiedMaterialsBackground = false; m_Background = value; } }
        /// <summary>
        /// The text objects to control with this component.
        /// </summary>
        /// <remarks>
        /// Accessing this property at runtime may cause new materials/meshes to be instantiated.
        ///
        /// Supported object types:
        /// * TextMesh (Unity 4.3: color property, other versions: color properties on material shader)
        /// * GUIText (Unity 4.3: color property, other versions: color properties on material shader)
        /// * Renderer (color properties on material shader)
        /// * MeshFilter (vertex colors)
        /// * GameObject (will select the first component)
        /// </remarks>
        public Object[] text { get { m_CopiedMaterialsText = false; return m_Text; } set { m_CopiedMaterialsText = false; m_Text = value; } }
        /// <summary>
        /// Gets or sets the color properties to change.
        /// </summary>
        public string[] colorProperties { get { return m_ColorProperties; } set { m_ColorProperties = value; } }

        ILetterTileDisplay m_LetterTile;
        bool m_CopiedMaterialsBackground;
        bool m_CopiedMaterialsText;

        void OnEnable()
        {
            m_LetterTile = GetComponentFromInterface<ILetterTileDisplay>();

            if (m_LetterTile != null)
            {
                m_LetterTile.onTileChange += UpdateTileRenderer;
            }
            UpdateTileRenderer();
        }

        void OnDisable()
        {
            if (m_LetterTile != null)
            {
                m_LetterTile.onTileChange -= UpdateTileRenderer;
            }
        }

        void UpdateTileRenderer()
        {
            if (m_Background == null || m_Text == null || !m_LetterTile.shouldChangeColor)
                return;

            for(int i = 0; i < m_Background.Length; ++i)
            {
                var bgGameObject = m_Background[i] as GameObject;

#if !(UNITY_3_5 || UNITY_4_0 || UNITY_4_1 || UNITY_4_2)
                var spriteRendererComponent = bgGameObject != null ? bgGameObject.GetComponent<SpriteRenderer>() : m_Background[i] as SpriteRenderer;

                if (spriteRendererComponent != null && spriteRendererComponent)
                {
                    spriteRendererComponent.color = m_LetterTile.currentBackgroundColor;
                    continue;
                }
#endif
                var rendererComponent = bgGameObject != null ? bgGameObject.GetComponent<Renderer>() : m_Background[i] as Renderer;
                var meshFilterComponent = bgGameObject != null ? bgGameObject.GetComponent<MeshFilter>() : m_Background[i] as MeshFilter;
                if (m_ColorProperties != null && rendererComponent != null && rendererComponent && rendererComponent.sharedMaterials != null)
                {
                    var materials = m_CopiedMaterialsBackground ? rendererComponent.sharedMaterials : rendererComponent.materials;
                    for (int j = 0; j < materials.Length; ++j)
                    {
                        var material = materials[j];

                        for (int k = 0; k < m_ColorProperties.Length; ++k)
                        {
                            var property = m_ColorProperties[k];

                            if (!string.IsNullOrEmpty(property) && material.HasProperty(property))
                                material.SetColor(property, m_LetterTile.currentBackgroundColor);
                        }
                    }
                }
                else if (meshFilterComponent != null && meshFilterComponent && meshFilterComponent.sharedMesh != null)
                {
                    var mesh = m_CopiedMaterialsBackground ? meshFilterComponent.sharedMesh : meshFilterComponent.mesh;
                    var colors = mesh.colors;

                    for (int j = 0; j < colors.Length; ++j)
                    {
                        colors[j] = m_LetterTile.currentBackgroundColor;
                    }

                    mesh.colors = colors;
                }
            }
            for(int i = 0; i < m_Text.Length; ++i)
            {
                var textGameObject = m_Text[i] as GameObject;

                var textMeshComponent = textGameObject != null ? textGameObject.GetComponent<TextMesh>() : m_Text[i] as TextMesh;
                var guiTextComponent = textGameObject != null ? textGameObject.GetComponent<GUIText>() : m_Text[i] as GUIText;
                var rendererComponent = textGameObject != null ? textGameObject.GetComponent<Renderer>() : m_Text[i] as Renderer;
                var meshFilterComponent = textGameObject != null ? textGameObject.GetComponent<MeshFilter>() : m_Text[i] as MeshFilter;

                if (textMeshComponent != null && textMeshComponent)
                {
#if (UNITY_3_5 || UNITY_4_0 || UNITY_4_1 || UNITY_4_2)
                    rendererComponent = textMeshComponent.renderer;
#else
                    textMeshComponent.color = m_LetterTile.currentTextColor;
#endif
                }
#if !(UNITY_3_5 || UNITY_4_0 || UNITY_4_1 || UNITY_4_2)
                else
#endif
                if (guiTextComponent != null && guiTextComponent)
                {
#if (UNITY_3_5 || UNITY_4_0 || UNITY_4_1 || UNITY_4_2)
                    var material = m_CopiedMaterialsText ? guiTextComponent.material : new Material(guiTextComponent.material);

                    for (int k = 0; k < m_ColorProperties.Length; ++k)
                    {
                    var property = m_ColorProperties [k];

                    if (!string.IsNullOrEmpty(property) && material.HasProperty(property))
                    material.SetColor(property, m_LetterTile.currentTextColor);
                    }
#else
                    guiTextComponent.color = m_LetterTile.currentTextColor;
#endif
                }
                else if (m_ColorProperties != null && rendererComponent != null && rendererComponent && rendererComponent.sharedMaterials != null)
                {
                    var materials = m_CopiedMaterialsText ? rendererComponent.sharedMaterials : rendererComponent.materials;

                    for (int j = 0; j < materials.Length; ++j)
                    {
                        var material = materials [j];

                        for (int k = 0; k < m_ColorProperties.Length; ++k)
                        {
                            var property = m_ColorProperties [k];

                            if (!string.IsNullOrEmpty(property) && material.HasProperty(property))
                                material.SetColor(property, m_LetterTile.currentTextColor);
                        }
                    }
                }
                else if (meshFilterComponent != null && meshFilterComponent && meshFilterComponent.sharedMesh != null)
                {
                    var mesh = m_CopiedMaterialsBackground ? meshFilterComponent.sharedMesh : meshFilterComponent.mesh;
                    var colors = mesh.colors;

                    for (int j = 0; j < colors.Length; ++j)
                    {
                        colors[j] = m_LetterTile.currentTextColor;
                    }

                    mesh.colors = colors;
                }
            }

            m_CopiedMaterialsBackground = true;
            m_CopiedMaterialsText = true;
        }
    }
#if !UNITY_3_5
}
#endif
