//
// WordGameLanguage.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEngine;
using Thinksquirrel.WordGameBuilderInternal;

#if !UNITY_3_5
namespace Thinksquirrel.WordGameBuilder
{
#else
using Thinksquirrel.WordGameBuilder;
#endif
    /// <summary>
    /// Represents a language for a word game.
    /// </summary>
    /// <remarks>
    /// Most aspects of a language are edited through the Language Editor.
    /// </remarks>
    public sealed class WordGameLanguage : ScriptableObject
    {
        #region Static fields, properties, and methods
        internal const string k_ResourceFolder = "WGB Languages";
        static WordGameLanguage s_Current;
        static readonly Dictionary<string, WordGameLanguage> s_Languages = new Dictionary<string, WordGameLanguage>();
        static bool s_DecompressOnLoad = true;
        static readonly Regex s_CopyRegex = new Regex(@" \d+$");

        //! \cond PRIVATE
        [System.Obsolete("Use WordGameLanguage.GetAllLanguages instead")]
        public static WordGameLanguage[] all
        {
            get
            {
                return GetAllLanguages();
            }
        }

        /// <summary>
        /// Gets an array with every currently loaded language.
        /// </summary>
        /// <returns>An array with every currently loaded language.</returns>
        /// <remarks>This operation should not be called every frame.</remarks>
        public static WordGameLanguage[] GetAllLanguages()
        {
            return s_Languages.Values.Where(l => (bool)l).ToArray();
        }

        /// <summary>
        /// Gets the loaded language count.
        /// </summary>
        /// <returns>The number of currently loaded languages.</returns>
        public static int GetLanguageCount()
        {
            int count = 0;

            var enumerator = s_Languages.GetEnumerator();

            while (enumerator.MoveNext())
            {
                var kvp = enumerator.Current;

                if (kvp.Value)
                    count++;
            }

            return count;
        }

        //! \cond PRIVATE
        [System.Obsolete("Use WordGameLanguage.FindByName instead")]
        public static WordGameLanguage Find(string name)
        {
            return FindByName(name);
        }
        //! \endcond

        /// <summary>
        /// Finds a loaded language by identifier.
        /// </summary>
        /// <param name="identifier">The identifier to search for.</param>
        /// <returns>The found language, or <c>null</c> if no language was found.</returns>.
        public static WordGameLanguage FindByIdentifier(string identifier)
        {
            if (string.IsNullOrEmpty(identifier))
                return null;

            WordGameLanguage l;
            bool f = s_Languages.TryGetValue(identifier, out l);
            return f ? l : null;
        }

        /// <summary>
        /// Finds the first occurance of a loaded language by name.
        /// </summary>
        /// <param name="name">The name to search for.</param>
        /// <returns>The found language, or <c>null</c> if no language was found.</returns>.
        public static WordGameLanguage FindByName(string name)
        {
            var enumerator = s_Languages.GetEnumerator();

            while (enumerator.MoveNext())
            {
                var kvp = enumerator.Current;

                if (kvp.Value.languageName == name)
                    return kvp.Value;
            }

            return null;
        }

        //! \cond PRIVATE
        [System.Obsolete("Use WordGameLanguage.RemoveByName instead")]
        public static void Remove(string name)
        {
            RemoveByName(name);
        }
        //! \endcond

        /// <summary>
        /// Unloads a language by identifier.
        /// </summary>
        /// <remarks>
        /// This method does not delete the actual language file, to prevent unintentional data loss.
        /// </remarks>
        /// <param name="identifier">The identifier to search for.</param>
        public static void RemoveByIdentifier(string identifier)
        {
            WordGameLanguage l;

            if (s_Languages.TryGetValue(identifier, out l))
            {
                if (s_Current == l)
                {
                    s_Current = null;
                }
                l.wordSet.CollapseSet();
                s_Languages.Remove(identifier);
            }
        }
        /// <summary>
        /// Unloads the first occurance of a language by name.
        /// </summary>
        /// <remarks>
        /// This method does not delete the actual language file, to prevent unintentional data loss.
        /// </remarks>
        /// <param name="name">The name to search for.</param>
        public static void RemoveByName(string name)
        {
            WordGameLanguage l = null;
            var enumerator = s_Languages.GetEnumerator();

            while (enumerator.MoveNext())
            {
                var kvp = enumerator.Current;

                if (kvp.Value.languageName == name)
                {
                    l = kvp.Value;
                    break;
                }
            }

            if (l != null)
            {
                if (s_Current == l)
                {
                    s_Current = null;
                }
                l.wordSet.CollapseSet();
                s_Languages.Remove(l.identifier);
            }
        }
        /// <summary>
        /// Completely unloads all languages.
        /// </summary>
        /// <remarks>
        /// This method does not delete the actual language file, to prevent unintentional data loss.
        /// </remarks>
        public static void RemoveAll()
        {
            s_Current = null;

            var enumerator = s_Languages.GetEnumerator();
            while (enumerator.MoveNext())
            {
                var kvp = enumerator.Current;

                kvp.Value.wordSet.CollapseSet();
            }

            s_Languages.Clear();
        }

        // Analysis disable ConvertToAutoProperty
        /// <summary>
        /// Should a language automatically be decompressed on load?
        /// </summary>
        /// <remarks>
        /// Note that this only applies to languages called with Language.current. Other languages will only decompress if set to the current language.
        /// </remarks>
        public static bool decompressOnLoad
        {
            get
            {
                return s_DecompressOnLoad;
            }
            set
            {
                s_DecompressOnLoad = value;
            }
        }
        // Analysis restore ConvertToAutoProperty

        /// <summary>
        /// Gets or sets the default language, by name. This value is saved to PlayerPrefs.
        /// </summary>
        /// <remarks>
        /// This is initially set to English.
        /// </remarks>
        public static string defaultLanguage
        {
            get
            {
                return PlayerPrefs.GetString("Thinksquirrel.WordGameBuilder.DefaultLanguage", "English");
            }
            set
            {
                PlayerPrefs.SetString("Thinksquirrel.WordGameBuilder.DefaultLanguage", value);
            }
        }

        /// <summary>
        /// Gets or sets the current language.
        /// </summary>
        /// <remarks>
        /// If the current language is not set, this property returns the default language (if available), or the first loaded language. If no languages are loaded, this property attempts to load all langauges with Language.LoadLanguages().
        /// Due to how Unity compares objects, this property is not thread-safe. To get around this, cache the language first.
        /// </remarks>
        public static WordGameLanguage current
        {
            get
            {
                if (!s_Current)
                {
                    if (s_Languages.Count > 0)
                    {
                        WordGameLanguage selected = null;
                        for (var i = s_Languages.Values.GetEnumerator(); i.MoveNext();)
                        {
                            var lang = i.Current;

                            if (!selected)
                                selected = lang;

                            if (lang.languageName == defaultLanguage)
                            {
                                selected = lang;
                                break;
                            }
                        }
                        s_Current = selected;
                    }
                    else
                    {
                        WordGameLanguage.LoadAllLanguages();
                    }
                }
                if (s_Current)
                {
                    if (s_DecompressOnLoad)
                    {
                        if (!s_Current.m_WordSet.isExpanded)
                        {
                            s_Current.m_WordSet.Decompress();
                        }
                    }
                }
                return (bool)s_Current ? s_Current : null;
            }
            set
            {
                if (value && value != s_Current)
                {
                    s_Current = value;
                }
            }
        }
        static void InitializeLanguage(WordGameLanguage language)
        {
            // Add to the static dictionary (or replace if reloading)
            if (s_Languages.ContainsKey(language.identifier))
            {
                s_Languages[language.identifier] = language;
            }
            else
            {
                s_Languages.Add(language.identifier, language);
            }
        }
        //! \cond PRIVATE
        [System.Obsolete("Use WordGameLanguage.LoadAllLanguages")]
        public static void LoadLanguages()
        {
            LoadAllLanguages();
        }
        //! \endcond

        /// <summary>
        /// Loads all language files from resources.
        /// </summary>
        public static void LoadAllLanguages()
        {
            s_Languages.Clear();
            s_Current = null;

            var languages = Resources.LoadAll(k_ResourceFolder, typeof(WordGameLanguage)).Cast<WordGameLanguage>();

            if (languages == null)
                return;

            var enumerator = languages.GetEnumerator();

            while(enumerator.MoveNext())
            {
                InitializeLanguage(enumerator.Current);
            }

            if (s_Languages.Count > 0)
            {
                WordGameLanguage selected = null;
                for (var i = s_Languages.Values.GetEnumerator(); i.MoveNext();)
                {
                    var lang = i.Current;

                    if (!selected)
                        selected = lang;

                    if (lang.languageName == defaultLanguage)
                    {
                        selected = lang;
                        break;
                    }
                }
                s_Current = selected;
            }
        }

        /// <summary>
        /// Loads a language by identifier (file name).
        /// </summary>
        /// <param name="identifier">The language identifier to load.</param>
        /// <returns>The loaded language.</returns>
        public static WordGameLanguage LoadLanguage(string identifier)
        {
            var language = Resources.Load(string.Format("{0}/{1}/language", k_ResourceFolder, identifier), typeof(WordGameLanguage)) as WordGameLanguage;

            if (language == null)
                throw new FileNotFoundException("language not found", identifier);

            InitializeLanguage(language);

            return language;
        }
        #endregion

        #region Member fields
        [SerializeField] [HideInInspector] string m_LanguageName = "";
        [SerializeField] [HideInInspector] string m_Identifier = "";
        [SerializeField] [HideInInspector] string m_Culture = "";
        [SerializeField] [HideInInspector] bool m_AllowBlanks;
        [SerializeField] [HideInInspector] bool m_CaseSensitive;
        [SerializeField] [HideInInspector] int m_BlankLetterWeight;
        [SerializeField] [HideInInspector] LetterList m_LetterList;
        [SerializeField] [HideInInspector] WordSet m_WordSet;

        readonly List<Letter> m_RandomDistribution = new List<Letter>();
        readonly List<Letter> m_WeightedDistribution = new List<Letter>();
        CultureInfo m_CultureInfoCached = CultureInfo.InvariantCulture;
        System.Random m_Random = new System.Random();
        #endregion
        #region Initializers
        /// <summary>
        /// Creates a language with the given name and identifier (file name).
        /// </summary>
        /// <param name="name">The new language name.</param>
        /// <param name="identifier">The new language identifier. Must be unique.</param>
        /// <returns>The created language.</returns>
        public static WordGameLanguage Create(string name, string identifier)
        {
            return CreateInternal(name, identifier, false);
        }
        internal static WordGameLanguage CreateInternal(string name, string identifier, bool overwrite)
        {
            if (identifier == null)
                throw new System.ArgumentNullException("identifier");
            if (name == null)
                throw new System.ArgumentNullException("name");

            if (overwrite)
            {
                WordGameLanguage.RemoveByIdentifier(identifier);
            }
            if (overwrite || !s_Languages.ContainsKey(identifier))
            {
                WordGameLanguage result = ScriptableObject.CreateInstance<WordGameLanguage>();

                ScriptableObject so = result;
                so.name = "language";

                result.m_LanguageName = name;
                result.m_Identifier = identifier;

                InitializeLanguage(result);

                if (s_Current == null)
                {
                    s_Current = result;
                }

                return result;
            }
            throw new System.ArgumentException("language identifier exists", "identifier");
        }

        /// <summary>
        /// Deep copy this language to a new language. A unique name will be assigned to the language identifier.
        /// </summary>
        /// <returns>
        /// The newly copied language.
        /// </returns>
        /// <remarks>>
        /// The language's random number generator is not deep copied with this method.
        /// </remarks>
        public WordGameLanguage Copy()
        {
            string id = s_CopyRegex.Replace(m_Identifier, "");
            string newId = id;
            int append = 1;

            while (WordGameLanguage.FindByIdentifier(newId) != null)
            {
                newId = string.Format("{0} {1}", id, append);
                ++append;
            }

            return Copy(m_LanguageName, newId);
        }
        /// <summary>
        /// Deep copy this language to a new language.
        /// </summary>
        /// <param name="newName">The name of the new language.</param>
        /// <param name="newIdentifier">The idenfitier of the new language. Must be unique.</param>
        /// <returns>
        /// The newly copied language. This language will not be expanded and must be decompressed. Runtime sets will not be copied.
        /// </returns>
        /// <remarks>>
        /// The language's random number generator is not deep copied with this method.
        /// </remarks>
        public WordGameLanguage Copy(string newName, string newIdentifier)
        {
            WordGameLanguage result = WordGameLanguage.Create(newName, newIdentifier);
            result.m_AllowBlanks = m_AllowBlanks;
            result.m_BlankLetterWeight = m_BlankLetterWeight;
            result.m_CaseSensitive = m_CaseSensitive;
            result.m_Culture = m_Culture;
            result.m_CultureInfoCached = m_CultureInfoCached;
            result.m_LetterList.AddRange(m_LetterList);

            using (var wordStream = new MemoryStream())
            {
                ExportWordsToCsv(wordStream);
                wordStream.Position = 0;
                result.ImportWordsFromCsv(wordStream);
            }

            result.m_WordSet.CollapseSet();

            return result;
        }
        #endregion
        #region OnEnable/Destroy
        void OnEnable()
        {
            // Set the letter list
            if (m_LetterList == null) m_LetterList = new LetterList(this);

            // Set the culture
            SetCultureInternal(m_Culture, false);

            // Initialize the word set
            if (m_WordSet == null)
                m_WordSet = ScriptableObject.CreateInstance<WordSet>();

            m_WordSet.Initialize(this);
        }
        void OnDisable()
        {
            // Remove from the dictionaries
            s_Languages.Remove(base.name);
        }
        #endregion
        #region Overrides
        /// <summary>
        /// Returns a string that represents the current language.
        /// </summary>
        /// <returns>
        /// A string that represents the current language.
        /// </returns>
        public override string ToString()
        {
            return string.Format("{0}({1})", languageName, GetType());
        }
        #endregion
        #region Properties
        //! \cond PRIVATE
        [System.Obsolete("Use WordGameLanguage.languageName instead")]
        public new string name
        {
            get { return languageName; }
            set { languageName = value; }
        }
        //! \endcond

        /// <summary>
        /// Gets or sets the language name.
        /// </summary>
        public string languageName
        {
            get
            {
                return m_LanguageName;
            }
            set
            {
                if (m_LanguageName != value && value != null)
                {
                    m_LanguageName = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the language's identifier (usually the file name).
        /// </summary>
        public string identifier
        {
            get
            {
                return m_Identifier;
            }
            set
            {
                if (m_Identifier != value && !string.IsNullOrEmpty(value) && !s_Languages.ContainsKey(value))
                {
                    if (m_Identifier != null && s_Languages.ContainsKey(m_Identifier))
                    {
                        s_Languages.Remove(m_Identifier);
                    }
                    m_Identifier = value;
                    s_Languages.Add(m_Identifier, this);
                }
            }
        }

        /// <summary>
        /// The language's culture.
        /// </summary>
        /// <remarks>
        /// Returns the invariant culture by default.
        /// </remarks>
        public CultureInfo culture
        {
            get
            {
                return m_CultureInfoCached ?? new CultureInfo(m_Culture);
            }
        }

        /// <summary>
        /// The language's culture code.
        /// </summary>
        public string cultureName
        {
            get
            {
                return m_Culture;
            }
        }

        /// <summary>
        /// Gets the list of letters in the language.
        /// </summary>
        /// <remarks>
        /// This list is automatically sorted in alphabetical order, based on the language's culture. Modifying this list may automatically trigger word list optimization.
        /// </remarks>
        public IList<Letter> letters
        {
            get
            {
                return m_LetterList;
            }
        }

        /// <summary>
        /// The WordSet data structure of the language.
        /// </summary>
        /// <remarks>
        /// This holds all of a language's words.
        /// </remarks>
        public WordSet wordSet
        {
            get
            {
                return m_WordSet;
            }
        }

        /// <summary>
        /// Gets an array of all words in the language.
        /// </summary>
        /// <remarks>
        /// This is a very expensive operation and is usually not needed.
        /// </remarks>
        /// <returns>An list of all words. This array can be very large!</returns>
        public IList<string> GetWords()
        {
            return m_WordSet.GetWords();
        }

        /// <summary>
        /// Gets the number of words in the language.
        /// </summary>
        public int wordCount
        {
            get
            {
                return m_WordSet.wordCount;
            }
        }

        // Analysis disable ConvertToAutoProperty
        /// <summary>
        /// Gets or sets whether the language should allow blank or wildcard letters.
        /// </summary>
        public bool allowBlanks
        {
            get
            {
                return m_AllowBlanks;
            }
            set
            {
                m_AllowBlanks = value;
            }
        }

        /// <summary>
        /// Gets or sets whether string lookups should be case-sensitive.
        /// </summary>
        /// <remarks>
        /// If disabled, all data is normalized to upper-case.
        /// </remarks>
        public bool caseSensitive
        {
            get
            {
                return m_CaseSensitive;
            }
            set
            {
                m_CaseSensitive = value;
            }
        }

        /// <summary>
        /// Gets or sets the weight of blank letters for random distribution.
        /// </summary>
        /// <remarks>
        /// Must be positive. Higher values = less occurances.
        /// </remarks>
        public int blankLetterWeight
        {
            get
            {
                return m_BlankLetterWeight;
            }
            set
            {
                m_BlankLetterWeight = value;
            }
        }
        // Analysis restore ConvertToAutoProperty

        #endregion
        #region General Methods
        /// <summary>
        /// Sets the culture of a language.
        /// </summary>
        /// <param name="cultureCode">The culture code to set.</param>
        /// <remarks>This will trigger a re-optimization of the language.</remarks>
        public void SetCulture(string cultureCode)
        {
            SetCultureInternal(cultureCode, true);
        }

        internal void SetCultureInternal(string cultureCode, bool optimize)
        {
            if (string.IsNullOrEmpty(cultureCode))
            {
                var words = optimize ? m_WordSet.GetWords() as List<string> : null;
                ClearCulture();
                if (optimize)
                {
                    m_LetterList.Sort();
                    m_WordSet.DoOptimize(words, false);
                }
                return;
            }

            try
            {
                var words = optimize ? m_WordSet.GetWords() as List<string> : null;
                m_CultureInfoCached = new CultureInfo(cultureCode);
                m_Culture = cultureCode;
                if (optimize)
                {
                    m_LetterList.Sort();
                    m_WordSet.DoOptimize(words, false);
                }
            }
            catch
            {
                WGBBase.LogError("Invalid culture provided!", "Word Game Builder", "Language", this);
            }
        }
        /// <summary>
        /// Clears the culture of a language, resetting it to use the invariant culture.
        /// </summary>
        public void ClearCulture()
        {
            m_CultureInfoCached = CultureInfo.InvariantCulture;
            m_Culture = "";
        }
        #endregion
        #region Import/Export
        /// <summary>
        /// Imports the letters of a language from a CSV file.
        /// </summary>
        /// <param name="filePath">The path to import letters from.</param>
        public void ImportLettersFromCsv(string filePath)
        {
            ImportLettersFromCsvInternal(filePath, null, false);
        }

        /// <summary>
        /// Imports the letters of a language from a CSV stream.
        /// </summary>
        /// <param name="stream">The stream to import letters from.</param>
        /// <remarks>
        /// After importing, the stream must be closed manually.
        /// </remarks>
        public void ImportLettersFromCsv(Stream stream)
        {
            ImportLettersFromCsvInternal(null, stream, true);
        }

        /// <summary>
        /// Imports the words of a language from a CSV file.
        /// </summary>
        /// <param name="filePath">The path to import words from.</param>
        public void ImportWordsFromCsv(string filePath)
        {
            ImportWordsFromCsvInternal(filePath, null, false, false);
        }

        /// <summary>
        /// Imports the words of a language from a CSV file.
        /// </summary>
        /// <param name="filePath">The path to import words from.</param>
        /// <param name="append">If <c>true</c>, append the words to the current set.</param>
        public void ImportWordsFromCsv(string filePath, bool append)
        {
            ImportWordsFromCsvInternal(filePath, null, false, append);
        }

        /// <summary>
        /// Imports the words of a language from a CSV file.
        /// </summary>
        /// <param name="stream">The stream to import words from.</param>
        /// <remarks>
        /// After importing, the stream must be closed manually.
        /// </remarks>
        public void ImportWordsFromCsv(Stream stream)
        {
            ImportWordsFromCsvInternal(null, stream, true, false);
        }

        /// <summary>
        /// Imports the words of a language from a CSV file.
        /// </summary>
        /// <param name="stream">The stream to import words from.</param>
        /// <param name="append">If <c>true</c>, append the words to the current set.</param>
        /// <remarks>
        /// After importing, the stream must be closed manually.
        /// </remarks>
        public void ImportWordsFromCsv(Stream stream, bool append)
        {
            ImportWordsFromCsvInternal(null, stream, true, append);
        }

        /// <summary>
        /// Exports the letters of a language to a CSV file.
        /// </summary>
        /// <param name="filePath">The path to export letters to.</param>
        public void ExportLettersToCsv(string filePath)
        {
            ExportLettersToCsvInternal(filePath, null, false);
        }

        /// <summary>
        /// Exports the letters of a language to a CSV file.
        /// </summary>
        /// <param name="stream">The stream to export letters to.</param>
        /// <remarks>
        /// After exporting, the stream must be closed manually.
        /// </remarks>
        public void ExportLettersToCsv(Stream stream)
        {
            ExportLettersToCsvInternal(null, stream, true);
        }

        /// <summary>
        /// Exports the words of a language to a CSV file.
        /// </summary>
        /// <param name="filePath">The path to export letters to.</param>
        public void ExportWordsToCsv(string filePath)
        {
            ExportWordsToCsvInternal(filePath, null, false);
        }

        /// <summary>
        /// Exports the words of a language to a CSV file.
        /// </summary>
        /// <param name="stream">The stream to export letters to.</param>
        /// <remarks>
        /// After exporting, the stream must be closed manually.
        /// </remarks>
        public void ExportWordsToCsv(Stream stream)
        {
            ExportWordsToCsvInternal(null, stream, true);
        }

        void ImportLettersFromCsvInternal(string filePath, Stream stream, bool isStream)
        {
            try
            {
                m_LetterList.ClearInternal();

                // No using statements here (we don't want to close the stream)
                var csv = isStream ? new CsvReader(stream) : new CsvReader(filePath);
                {
                    string[] fields;

                    while ((fields = csv.GetCsvLine()) != null)
                    {
                        m_LetterList.AddInternal(new Letter(fields[0], System.Convert.ToChar(fields[1]), System.Convert.ToInt32(fields[2])));
                    }
                }

                // Sort the letters
                m_LetterList.Sort();
            }
            catch (System.Exception e)
            {
                WGBBase.LogException(e, this);
                WGBBase.LogError("Unable to parse letters from CSV file!", "Word Game Builder", "Language", this);
                return;
            }
            try
            {
                m_WordSet.Optimize();
            }
            catch (System.Exception e)
            {
                WGBBase.LogException(e, this);
                WGBBase.LogError("Unable to initialize letters", "Word Game Builder", "Language", this);
            }
        }

        void ImportWordsFromCsvInternal(string filePath, Stream stream, bool isStream, bool append)
        {
            var fileContents = new List<string>();
            try
            {
                // No using statements here (we don't want to close the stream)
                var csv = isStream ? new CsvReader(stream) : new CsvReader(filePath);
                {
                    string[] fields;

                    while ((fields = csv.GetCsvLine()) != null)
                    {
                        for (int i = 0; i < fields.Length; i++)
                        {
                            string field = fields[i];
                            fileContents.Add(field);
                        }
                    }
                }
            }
            catch (System.Exception e)
            {
                WGBBase.LogException(e, this);
                WGBBase.LogError("Unable to parse words from CSV file!", "Word Game Builder", "Language", this);
            }

            // Generate the tree
            try
            {
                m_WordSet.DoOptimize(fileContents, append);
            }
            catch (System.Exception e)
            {
                WGBBase.LogException(e, this);
                WGBBase.LogError("Unable to initialize words", "Word Game Builder", "Language", this);
            }
        }

        void ExportLettersToCsvInternal(string filePath, Stream stream, bool isStream)
        {
            // No using statements here (we don't want to close the stream)
            var csv = isStream ? new CsvWriter(stream) : new CsvWriter(filePath);
            {
                for (int i = 0; i < m_LetterList.Count; i++)
                {
                    Letter letter = m_LetterList[i];
                    csv.WriteFields(new object[] {
                        letter.text,
                        letter.character,
                        letter.score
                    });
                }
            }
            csv.Flush();
        }

        void ExportWordsToCsvInternal(string filePath, Stream stream, bool isStream)
        {
            // No using statements here (we don't want to close the stream)
            var csv = isStream ? new CsvWriter(stream) : new CsvWriter(filePath);
            {
                csv.WriteFields(GetWords().ToArray());
            }
            csv.Flush();
        }
        #endregion
        #region Letter methods
        /// <summary>
        /// Gets the Letter struct for the specified string (Letter.text).
        /// </summary>
        /// <param name="letter">The letter string to search for.</param>
        /// <returns>A Letter struct representing the specified string.</returns>
        public Letter GetLetter(string letter)
        {
            if (m_AllowBlanks && letter == string.Empty)
                return Letter.empty;

            for (int i = 0; i < m_LetterList.Count; i++)
            {
                Letter l = m_LetterList[i];
                if (culture.CompareInfo.Compare(l.text, letter, !caseSensitive ? CompareOptions.OrdinalIgnoreCase : CompareOptions.Ordinal) == 0)
                {
                    return l;
                }
            }

            return Letter.empty;
        }

        /// <summary>
        /// Gets the Letter struct for the specified character value (Letter.character).
        /// </summary>
        /// <param name="letterValue">The letter character value to search for.</param>
        /// <returns>A Letter struct representing the specified character value.</returns>
        public Letter GetLetter(char letterValue)
        {
            for (int i = 0; i < m_LetterList.Count; i++)
            {
                Letter l = m_LetterList[i];
                if (l.character == letterValue)
                {
                    return l;
                }
            }

            throw new System.ArgumentException("letter not found", "letterValue");
        }

        /// <summary>
        /// Gets the previous letter in the language's alphabet.
        /// </summary>
        /// <remarks>
        /// Wraps back to the last letter by default. If allowBlanks is enabled, includes a blank letter at the end of the alphabet.
        /// </remarks>
        /// <param name="firstLetter">The letter to move from.</param>
        /// <returns>The previous letter in the alphabet.</returns>
        public Letter PreviousLetter(Letter firstLetter)
        {
            return PreviousLetter(firstLetter, true);
        }

        /// <summary>
        /// Gets the previous letter in the language's alphabet.
        /// </summary>
        /// <remarks>
        /// If allowBlanks is enabled, includes a blank letter at the end of the alphabet.
        /// </remarks>
        /// <param name="firstLetter">The letter to move from.</param>
        /// <param name="wrap">If <c>true</c>, wrap to the last letter if this is run on the first letter.</param>
        /// <returns>The previous letter in the alphabet.</returns>
        public Letter PreviousLetter(Letter firstLetter, bool wrap)
        {
            if (!firstLetter.hasValue && m_AllowBlanks)
            {
                return m_LetterList[m_LetterList.Count - 1];
            }

            for (int i = 0; i < m_LetterList.Count; i++)
            {
                if (m_LetterList[i] == firstLetter)
                {
                    if (i == 0)
                    {
                        if (wrap)
                        {
                            return m_LetterList[m_LetterList.Count - 1];
                        }

                        return (m_AllowBlanks) ? Letter.empty : m_LetterList[0];
                    }

                    return m_LetterList[i - 1];
                }
            }

            return Letter.empty;
        }

        /// <summary>
        /// Gets the next letter in the language's alphabet.
        /// </summary>
        /// <remarks>
        /// Wraps back to the first letter by default. If allowBlanks is enabled, includes a blank letter at the end of the alphabet.
        /// </remarks>
        /// <param name="firstLetter">The letter to move from.</param>
        /// <returns>The next letter in the alphabet.</returns>
        public Letter NextLetter(Letter firstLetter)
        {
            return NextLetter(firstLetter, true);
        }

        /// <summary>
        /// Gets the next letter in the language's alphabet.
        /// </summary>
        /// <remarks>
        /// If allowBlanks is enabled, includes a blank letter at the end of the alphabet.
        /// </remarks>
        /// <param name="firstLetter">The letter to move from.</param>
        /// <param name="wrap">If <c>true</c>, wrap to the first letter if this is run on the last letter.</param>
        /// <returns>The next letter in the alphabet.</returns>
        public Letter NextLetter(Letter firstLetter, bool wrap)
        {
            if (!firstLetter.hasValue && m_AllowBlanks)
            {
                return (wrap) ? m_LetterList[0] : Letter.empty;
            }

            for (int i = 0; i < m_LetterList.Count; i++)
            {
                if (m_LetterList[i] == firstLetter)
                {
                    if (i == m_LetterList.Count - 1)
                    {
                        if (wrap)
                        {
                            return (m_AllowBlanks) ? Letter.empty : m_LetterList[0];
                        }

                        return m_LetterList[m_LetterList.Count - 1];
                    }

                    return m_LetterList[i + 1];
                }
            }

            return Letter.empty;
        }

        /// <summary>
        /// Gets a random letter from the language's alphabet.
        /// </summary>
        /// <remarks>
        /// Uses a weighted distribution based on score by default.
        /// </remarks>
        /// <returns>A weighted random letter.</returns>
        public Letter GetRandomLetter()
        {
            return GetRandomLetter(true);
        }

        /// <summary>
        /// Gets a random letter from the language's alphabet.
        /// </summary>
        /// <remarks>
        /// Uses a weighted distribution based on score by default.
        /// </remarks>
        /// <param name="weighted">If <c>true</c>, a weighted distribution of letters will be used, based on score.</param>
        /// <returns>A random letter.</returns>
        public Letter GetRandomLetter(bool weighted)
        {
            if (weighted)
            {
                CreateWeightedDistribution();

                return m_WeightedDistribution.Count > 0 ? m_WeightedDistribution[Random.Range(0, m_WeightedDistribution.Count - 1)] : Letter.empty;
            }

            CreateRandomDistribution();

            return m_RandomDistribution.Count > 0 ? m_RandomDistribution[Random.Range(0, m_RandomDistribution.Count - 1)] : Letter.empty;
        }
        //!\cond PRIVATE
        // Analysis disable InconsistentNaming
        [System.Obsolete("Use WordGameLanguage.GetRandomLetters instead")]
        public IList<Letter> GetRandom_Letters(int count)
        {
            return GetRandomLetters(count, true);
        }
        [System.Obsolete("Use WordGameLanguage.GetRandomLetters instead")]
        public IList<Letter> GetRandom_Letters(int count, bool weighted)
        {
            return GetRandomLetters(count, weighted);
        }
        // Analysis restore InconsistentNaming
        //\endcond
        /// <summary>
        /// Gets a list of random letters from the language's alphabet, up to the specified count.
        /// </summary>
        /// <remarks>
        /// Uses a weighted distribution based on score by default.
        /// </remarks>
        /// <param name="count">The amount of random letters to obtain.</param>
        /// <returns>A list of random letters.</returns>
        public IList<Letter> GetRandomLetters(int count)
        {
            return GetRandomLetters(count, true);
        }
        /// <summary>
        /// Gets a list of random letters from the language's alphabet, up to the specified count.
        /// </summary>
        /// <remarks>
        /// Uses a weighted distribution based on score by default.
        /// </remarks>
        /// <param name="count">The amount of random letters to obtain.</param>
        /// <param name="weighted">If <c>true</c>, a weighted distribution of letters will be used, based on score.</param>
        /// <returns>A list of random letters.</returns>
        public IList<Letter> GetRandomLetters(int count, bool weighted)
        {
            if (weighted)
            {
                CreateWeightedDistribution();

                m_WeightedDistribution.Shuffle(m_Random);

                return m_WeightedDistribution.GetRange(0, count);
            }

            CreateRandomDistribution();

            m_RandomDistribution.Shuffle(m_Random);

            return m_RandomDistribution.GetRange(0, count);
        }

        void CreateWeightedDistribution()
        {
            if (m_WeightedDistribution.Count < 1)
            {
                m_WeightedDistribution.Clear();
                int max = -99999;
                for (int i = 0; i < m_LetterList.Count; i++)
                {
                    max = Mathf.Max(max, m_LetterList[i].score);
                }
                if (m_AllowBlanks)
                {
                    max = Mathf.Max(max, m_BlankLetterWeight);
                }

                for (int i = 0; i < m_LetterList.Count; i++)
                {
                    Letter l = m_LetterList[i];
                    for (int j = 0; j < max / Mathf.Max(l.score, 1); j++)
                    {
                        m_WeightedDistribution.Add(l);
                    }
                }
                if (m_AllowBlanks)
                {
                    for (int i = 0; i < max/Mathf.Max(m_BlankLetterWeight, 1); i++)
                    {
                        m_WeightedDistribution.Add(Letter.empty);
                    }
                }
            }
        }

        void CreateRandomDistribution()
        {
            if (m_RandomDistribution.Count < 1)
            {
                m_RandomDistribution.Clear();
                m_RandomDistribution.AddRange(m_LetterList);
                if (m_AllowBlanks)
                {
                    m_RandomDistribution.Add(Letter.empty);
                }
            }
        }

        /// <summary>
        /// Clears the cache of random letters.
        /// </summary>
        /// <remarks>
        /// This needs to be called manually if you use a random letter method and change letter information or enable/disable blank letters at runtime.
        /// </remarks>
        public void ClearRandomLetterCache()
        {
            m_RandomDistribution.Clear();
            m_WeightedDistribution.Clear();
        }

        /// <summary>
        /// Gets a random word from the language.
        /// </summary>
        /// <returns>A random word from the language.</returns>
        public string GetRandomWord()
        {
            return wordSet.GetRandomWord(m_Random);
        }

        /// <summary>
        /// Gets a random word from the language, ensuring that it is under the maximum amount of letters.
        /// </summary>
        /// <remarks>
        /// This is a recursive random search and hard-capped at 10,000 iterations (it returns null on failure).
        /// It is recommended to prune unused words from the language to help ensure this search does not fail.
        /// </remarks>
        /// <param name="maxLetters">The maximum amount of letters permitted for a random word.</param>
        /// <returns>A random word from the language, up to maxLetters.</returns>
        public string GetRandomWord(int maxLetters)
        {
            if (maxLetters <= 0)
                throw new System.ArgumentOutOfRangeException("maxLetters");

            string wrd = GetRandomWord();

            for (int i = 0; i < 10000; i++)
            {
                if (wrd.Length > maxLetters)
                {
                    wrd = GetRandomWord();
                }
                else
                {
                    return wrd;
                }
            }

            return null;

        }

        /// <summary>
        /// Sets the psuedo-random number generator for the language.
        /// The pRNG's seed is time-based by default.
        /// </summary>
        /// <param name="seed">The random seed to assign to the language.</param>
        /// <remarks>
        /// The pRNG is used for picking random letters, random words, and lossy prefix search.
        /// </remarks>
        public void SetRandomNumberGenerator(int seed)
        {
            m_Random = new System.Random(seed);
        }

        /// <summary>
        /// Gets the psuedo-random number generator for the language.
        /// </summary>
        /// <remarks>
        /// The pRNG is used for picking random letters, random words, and lossy prefix search.
        /// </remarks>
        /// <returns>The language's random number generator.</returns>
        public System.Random GetRandomNumberGenerator()
        {
            return m_Random;
        }
        #endregion
    }

    #region Letter list class
    [System.Serializable]
    class LetterList : IList<Letter>
    {
        [SerializeField] [HideInInspector] List<SerializableLetter> m_InternalList;
        [SerializeField] [HideInInspector] WordGameLanguage m_Language;

        internal int _version;

        public LetterList(WordGameLanguage language)
        {
            m_Language = language;
            m_InternalList = new List<SerializableLetter>();
            SortInternalList();
        }

        public LetterList(IEnumerable<Letter> collection, WordGameLanguage language)
        {
            m_Language = language;
            m_InternalList = new List<SerializableLetter>();

            for (var i = collection.GetEnumerator(); i.MoveNext();)
            {
                m_InternalList.Add(new SerializableLetter(i.Current));
            }
            SortInternalList();
        }

        public LetterList(int capacity, WordGameLanguage language)
        {
            m_Language = language;
            m_InternalList = new List<SerializableLetter>(capacity);
            SortInternalList();
        }

        #region IList implementation
        public int IndexOf(Letter item)
        {
            for (var i = 0; i < m_InternalList.Count; ++i)
            {
                var candidate = new Letter(m_InternalList [i]);

                if (candidate == item)
                    return i;
            }

            return -1;
        }
        public void Insert(int index, Letter item)
        {
            if (!ValidateLetter(ref item, -1))
                throw new System.ArgumentException("Letter is either empty or uses a duplicate character");

            m_InternalList.Insert(index, new SerializableLetter(item));
            if (m_Language && m_Language.wordSet != null) m_Language.wordSet.Optimize();

            _version++;
        }
        public void RemoveAt(int index)
        {
            m_InternalList.RemoveAt(index);
            if (m_Language && m_Language.wordSet != null) m_Language.wordSet.Optimize();

            _version++;
        }
        public Letter this[int index]
        {
            get
            {
                return new Letter(m_InternalList [index]);
            }
            set
            {
                if (new Letter(m_InternalList [index]) != value)
                {
                    if (!ValidateLetter(ref value, index))
                        throw new System.ArgumentException("Letter is either empty or uses a duplicate character");

                    m_InternalList [index].Update(value);
                    SortInternalList();
                    if (m_Language && m_Language.wordSet != null) m_Language.wordSet.Optimize();

                    _version++;
                }
            }
        }
        #endregion
        #region ICollection implementation
        public void Add(Letter item)
        {
            AddInternal(item);
            if (m_Language) SortInternalList();
        }
        internal void AddInternal(Letter item)
        {
            if (!ValidateLetter(ref item, -1))
                throw new System.ArgumentException("Letter is either empty or uses a duplicate character");

            m_InternalList.Add(new SerializableLetter(item));

            _version++;
        }
        public void Clear()
        {
            ClearInternal();
            if (m_Language)
            {
                SortInternalList();
                m_Language.wordSet.Optimize();
            }
        }
        internal void ClearInternal()
        {
            m_InternalList.Clear();
            _version++;
        }
        public bool Contains(Letter item)
        {
            return IndexOf(item) >= 0;
        }
        public void CopyTo(Letter[] array, int arrayIndex)
        {
            for (var i = arrayIndex; i < m_InternalList.Count; ++i)
                array [i] = new Letter(m_InternalList [i]);
        }
        public bool Remove(Letter item)
        {
            var ind = IndexOf(item);

            if (ind >= 0)
            {
                m_InternalList.RemoveAt(ind);
                if (m_Language)
                {
                    SortInternalList();
                    m_Language.wordSet.Optimize();
                }
                _version++;
                return true;
            }

            return false;
        }
        // Analysis disable InconsistentNaming
        public int Count
        {
            get
            {
                return m_InternalList.Count;
            }
        }
        public bool IsReadOnly
        {
            get
            {
                return false;
            }
        }
        // Analysis restore InconsistentNaming
        #endregion
        #region IEnumerable implementation
        public IEnumerator<Letter> GetEnumerator()
        {
            return new Enumerator(this);
        }
        #endregion
        #region IEnumerable implementation
        IEnumerator IEnumerable.GetEnumerator()
        {
            return new Enumerator(this);
        }
        #endregion

        #region List<T> implementation
        public void Sort()
        {
            if (m_Language) SortInternalList();
        }

        public void AddRange(IEnumerable<Letter> collection)
        {
            for (var i = collection.GetEnumerator(); i.MoveNext();)
            {
                var letter = i.Current;
                if (!ValidateLetter(ref letter, -1))
                    throw new System.ArgumentException("Letter is either empty or uses a duplicate character");

                m_InternalList.Add(new SerializableLetter(i.Current));
            }
            if (m_Language) SortInternalList();
            _version++;
        }
        #endregion

        #region Private methods
        bool ValidateLetter(ref Letter letter, int index)
        {
            if (!letter.hasValue)
                return false;

            for (int i = 0; i < m_InternalList.Count; ++i)
            {
                if (i == index)
                    continue;

                var currentLetter = m_InternalList [i];

                if (letter.character == currentLetter.character)
                    return false;
            }

            return true;
        }
        void SortInternalList()
        {
            if (m_Language)
            {
                m_InternalList.Sort((x, y) => m_Language.culture.CompareInfo.Compare(x.text, y.text));
            }
        }
        #endregion

        #region Nested types
        [System.Serializable]
        public struct Enumerator : IEnumerator<Letter>, System.IDisposable, IEnumerator
        {
            readonly LetterList l;
            int m_Next;
            readonly int m_Version;
            Letter m_Current;

            // Analysis disable InconsistentNaming
            public Letter Current
            {
                get
                {
                    return m_Current;
                }
            }
            // Analysis restore InconsistentNaming

            object IEnumerator.Current
            {
                get
                {

                    return m_Current;
                }
            }

            internal Enumerator(LetterList list)
            {
                l = list;
                m_Next = 0;
                m_Version = list._version;
                m_Current = Letter.empty;
            }

            public void Dispose()
            {
            }

            public bool MoveNext()
            {
                if (m_Next < l.Count && m_Version == l._version)
                {
                    m_Current = l[m_Next++];
                    return true;
                }
                if (m_Version != l._version)
                {
                    throw new System.InvalidOperationException();
                }
                m_Next = -1;
                return false;
            }

            public void Reset()
            {
                if (m_Version != l._version)
                {
                    throw new System.InvalidOperationException();
                }
                m_Next = 0;
            }
        }
        #endregion
    }
    #endregion


#if !UNITY_3_5
}
#endif
