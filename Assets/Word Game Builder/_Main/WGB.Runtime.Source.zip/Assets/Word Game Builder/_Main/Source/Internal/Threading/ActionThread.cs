//
// ActionThread.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
namespace Thinksquirrel.WordGameBuilderInternal.Threading
{
    /// <summary>
    /// An action thread.
    /// </summary> 
    sealed class ActionThread : ThreadBase
    {
        System.Action<ActionThread> m_Action;

        /// <summary>
        /// Creates a new Thread which runs the given action.
        /// The thread will start running after creation.
        /// </summary>
        /// <param name="action">The action to run.</param>
        public ActionThread(System.Action<ActionThread> action)
            : this(action, true)
        {
        }

        /// <summary>
        /// Creates a new Thread which runs the given action.
        /// </summary>
        /// <param name="action">The action to run.</param>
        /// <param name="autoStartThread">Should the thread start after creation.</param>
        public ActionThread(System.Action<ActionThread> action, bool autoStartThread)
            : base(Dispatcher.current, false)
        {
            m_Action = action;
            if (autoStartThread)
                Start();
        }
/*! \cond PRIVATE */
        protected override void Do()
        {
            m_Action(this);
        }
/*! \endcond */
    }
}