﻿//
// LetterTileDaikonForgeControl.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using UnityEngine;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using Thinksquirrel.WordGameBuilderInternal;
using System.Reflection;

#if !UNITY_3_5
//! Contains letter tile helper classes for Daikon Forge GUI.
namespace Thinksquirrel.WordGameBuilder.Tiles.DaikonForge
{
#else
using Thinksquirrel.WordGameBuilder;
#endif
    /// <summary>
    /// Adds Daikon Forge GUI display to a letter tile.
    /// </summary>
    /// <remarks>
    /// This component must be on the same object as a letter tile. Use LetterTileVisibilityControl to modify control and label visibility.
    /// </remarks>
    [RequireComponent(typeof(ILetterTileDisplay))]
    [AddComponentMenu("Word Game Builder/Tiles/DF-GUI/Letter Tile Daikon Forge Control")]
    [WGBDocumentationName("Thinksquirrel.WordGameBuilder.Tiles.DaikonForge.LetterTileDaikonForgeControl")]
    public sealed class LetterTileDaikonForgeControl : WGBBase
    {
        [SerializeField] MonoBehaviour[] m_Controls;
        [SerializeField] MonoBehaviour m_LetterLabel;
        [SerializeField] MonoBehaviour m_ScoreLabel;

        /// <summary>
        /// Gets or sets the list of controls.
        /// </summary>
        /// <remarks>
        /// All controls must be of the type dfControl.
        /// </remarks>
        public MonoBehaviour[] controls { get { return m_Controls; } set { m_Controls = value; } }
        /// <summary>
        /// Gets or sets the letter label.
        /// </summary>
        /// <remarks>
        /// The label must be of the type dfLabel.
        /// </remarks>
        public MonoBehaviour letterLabel { get { return m_LetterLabel; } set { m_LetterLabel = value; } }
        /// <summary>
        /// Gets or sets the score label.
        /// </summary>
        /// <remarks>
        /// The label must be of the type dfLabel.
        /// </remarks>
        public MonoBehaviour scoreLabel { get { return m_ScoreLabel; } set { m_ScoreLabel = value; } }

        ILetterTileDisplay m_LetterTile;

        PropertyInfo m_ColorProperty;
        PropertyInfo m_TextProperty;

        void BindComponents()
        {
            var assemblies = System.AppDomain.CurrentDomain.GetAssemblies();

            bool foundControl = false;
            bool foundLabel = false;

            for(int i = 0; i < assemblies.Length; ++i)
            {
                if (foundControl && foundLabel)
                    break;

                var assembly = assemblies[i];

                if (!foundControl)
                {
                    var controlType = assembly.GetType("dfControl");

                    if (controlType != null && controlType.Namespace == null)
                    {
                        m_ColorProperty = controlType.GetProperty("Color");
                        foundControl = m_ColorProperty != null;
                    }
                }

                if (!foundLabel)
                {
                    var labelType = assembly.GetType("dfLabel");

                    if (labelType != null && labelType.Namespace == null)
                    {
                        m_TextProperty = labelType.GetProperty("Text");
                        foundLabel = m_TextProperty != null;
                    }
                }
            }

        }

        void OnEnable()
        {
            BindComponents();
            m_LetterTile = GetComponentFromInterface<ILetterTileDisplay>();

            if (m_LetterTile != null)
            {
                m_LetterTile.onTileChange += UpdateTileSprite;
            }
            UpdateTileSprite();
        }

        void OnDisable()
        {
            if (m_LetterTile != null)
            {
                m_LetterTile.onTileChange -= UpdateTileSprite;
            }
        }

        void UpdateTileSprite()
        {
            if (m_Controls == null)
                return;

            if (m_ColorProperty != null && m_LetterTile.shouldChangeColor)
            {
                for (int i = 0; i < m_Controls.Length; ++i)
                {
                    var control = m_Controls[i];
                    
                    if (control)
                    {
                        try
                        {
                            m_ColorProperty.SetValue(control, (Color32)m_LetterTile.currentBackgroundColor, null);
                        }
                        catch
                        {
                            WGBBase.LogError(string.Format("Unable to assign color property to {0}", m_Controls[i].name), "Word Game Builder", "LetterTileDaikonForgeControl");
                        }
                    }
                }

                if (letterLabel)
                {
                    try
                    {
                        m_ColorProperty.SetValue(m_LetterLabel, (Color32)m_LetterTile.currentTextColor, null);
                    }
                    catch
                    {
                        WGBBase.LogError(string.Format("Unable to assign color property to {0}", m_LetterLabel.name), "Word Game Builder", "LetterTileDaikonForgeControl");
                    }
                }

                if (scoreLabel)
                {
                    try
                    {
                        m_ColorProperty.SetValue(m_ScoreLabel, (Color32)m_LetterTile.currentTextColor, null);
                    }
                    catch
                    {
                        WGBBase.LogError(string.Format("Unable to assign color property to {0}", m_ScoreLabel.name), "Word Game Builder", "LetterTileDaikonForgeControl");
                    }
                }

            }

            if (m_TextProperty != null && m_LetterTile.shouldChangeLabel)
            {
                if (letterLabel)
                {
                    try
                    {
                        m_TextProperty.SetValue(m_LetterLabel, m_LetterTile.currentLetterLabel, null);
                    }
                    catch
                    {
                        WGBBase.LogError(string.Format("Unable to assign text property to {0}", m_LetterLabel.name), "Word Game Builder", "LetterTileDaikonForgeControl");
                    }
                }

                if (scoreLabel)
                {
                    try
                    {
                        m_TextProperty.SetValue(m_ScoreLabel, m_LetterTile.currentScoreLabel, null);
                    }
                    catch
                    {
                        WGBBase.LogError(string.Format("Unable to assign text property to {0}", m_ScoreLabel.name), "Word Game Builder", "LetterTileDaikonForgeControl");
                    }
                }
            }
        }
    }
#if !UNITY_3_5
}
#endif
