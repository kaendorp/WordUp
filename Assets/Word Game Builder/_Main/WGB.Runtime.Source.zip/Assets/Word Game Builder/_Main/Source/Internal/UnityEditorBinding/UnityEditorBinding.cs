//
// UnityEditorBinding.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
#if (UNITY_WP8 || UNITY_METRO || NETFX_CORE) && !UNITY_EDITOR
#define UNITY_WIN8_RUNTIME
#endif
using System.Reflection;
using UnityEngine;

namespace Thinksquirrel.WordGameBuilderInternal
{
    static class UnityEditorBinding
    {
        static Assembly s_EditorAssembly;
        
        static void LoadAssembly()
        {
#if !UNITY_WIN8_RUNTIME
            // Get the Unity Editor assembly
            s_EditorAssembly = Assembly.Load("UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null");
#endif
        }
        
        /// <summary>
        /// Run the specified static method with the specified arguments.
        /// </summary>
        /// <param name='method'>
        /// The name of the static method in the UnityEditor namespace to run (ex: EditorUtility.DisplayProgressBar)
        /// </param>
        /// <param name='arguments'>
        /// The arguments to pass to the method. (optional)
        /// </param>
        public static object RunStatic(string method, params object[] arguments)
        {
#if UNITY_WIN8_RUNTIME
            return null;
#else
            // Return if not in the editor
            if (!Application.isEditor)
                return null;
                
            if (s_EditorAssembly == null)
                LoadAssembly();
                
            if (s_EditorAssembly == null)
                return null;
            
            // Get the type
            var typeString = method.Substring(0, method.LastIndexOf('.'));
            var type = s_EditorAssembly.GetType(string.Format("UnityEditor.{0}", typeString));
            
            if (type == null)
                return null;
            
            // Get the Method
            var methodString = method.Substring(method.LastIndexOf('.') + 1);
            var methodInfo = type.GetMethod(methodString, BindingFlags.Static | BindingFlags.Public);
            
            return methodInfo == null ? null : methodInfo.Invoke(null, arguments);
            
#endif
        }
        
        /// <summary>
        /// Run the specified instance method with the specified arguments.
        /// </summary>
        /// <param name='instance'>
        /// The object to run the method on. (ex: an EditorWindow instance)
        /// </param>
        /// <param name='method'>
        /// The name of the instance method in the UnityEditor namespace to run (ex: Repaint)
        /// </param>
        /// <param name='arguments'>
        /// The arguments to pass to the method. (optional)
        /// </param>
        public static object RunInstance(object instance, string method, params object[] arguments)
        {
#if UNITY_WIN8_RUNTIME
            return null;
#else
            // Return if not in the editor
            if (!Application.isEditor)
                return null;
            
            if (s_EditorAssembly == null)
                LoadAssembly();
                
            if (s_EditorAssembly == null)
                return null;
            
            // Get the type
            var type = instance.GetType();
            
            if (type == null)
                return null;
            
            // Get the Method
            var methodString = method.Substring(method.LastIndexOf('.') + 1);
            var methodInfo = type.GetMethod(methodString, BindingFlags.Instance | BindingFlags.Public);
            
            return methodInfo == null ? null : methodInfo.Invoke(instance, arguments);
#endif
        }
    }
}
