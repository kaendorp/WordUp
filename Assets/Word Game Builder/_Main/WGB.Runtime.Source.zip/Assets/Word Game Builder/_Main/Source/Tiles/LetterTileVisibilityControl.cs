﻿//
// LetterTileVisibilityControl.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using UnityEngine;
using Thinksquirrel.WordGameBuilderInternal;
using Thinksquirrel.WordGameBuilder.ObjectModel;

#if !UNITY_3_5
namespace Thinksquirrel.WordGameBuilder.Tiles
{
#else
using Thinksquirrel.WordGameBuilder;
#endif
    /// <summary>
    /// Automatically controls the visibility of objects based on a letter tile's state.
    /// </summary>
    /// <remarks>
    /// This component must be on the same object as a letter tile.
    /// </remarks>
    [RequireComponent(typeof(ILetterTile))]
    [AddComponentMenu("Word Game Builder/Tiles/Letter Tile Visibility Control")]
    [WGBDocumentationName("Thinksquirrel.WordGameBuilder.Tiles.LetterTileVisibilityControl")]
    public sealed class LetterTileVisibilityControl : WGBBase
    {
        [SerializeField] Object[] m_Objects;

        /// <summary>
        /// The objects to toggle when a tile spawns or despawns.
        /// </summary>
        /// <remarks>
        /// Supported object types:
        /// * Renderer (enabled property)
        /// * Collider (enabled property)
        /// * Behaviour (enabled property)
        /// * GameObject (SetActive method)
        /// </remarks>
        public Object[] objects { get { return m_Objects; } set { m_Objects = value; } }

        ILetterTile m_LetterTile;
        
        void OnEnable()
        {
            m_LetterTile = GetComponentFromInterface<ILetterTile>();
            
            if (m_LetterTile != null)
            {
                m_LetterTile.onTileSpawn += UpdateTileVisibility;
            }
            UpdateTileVisibility();
        }
        
        void OnDisable()
        {
            if (m_LetterTile != null)
            {
                m_LetterTile.onTileSpawn -= UpdateTileVisibility;
            }
        }
        
        void UpdateTileVisibility()
        {
            if (m_Objects != null)
            {
                for(int i = 0; i < m_Objects.Length; ++i)
                {
                    var obj = m_Objects[i];

                    if (!obj)
                        continue;

                    var rend = obj as Renderer;
                    var col = obj as Collider;
                    var behaviour = obj as Behaviour;
                    var go = obj as GameObject;

                    if (rend != null && rend)
                    {
                        rend.enabled = m_LetterTile.isActive;
                    }
                    else if (col != null && col)
                    {
                        col.enabled = m_LetterTile.isActive;
                    }
                    else if (behaviour != null && behaviour && behaviour != this)
                    {
                        behaviour.enabled = m_LetterTile.isActive;
                    }
                    else if (go != null && go && go != gameObject)
                    {
#if UNITY_3_5
                        go.SetActiveRecursively(m_LetterTile.isActive);
#else
                        go.SetActive(m_LetterTile.isActive);
#endif

                    }
                }
            }
        }
    }
#if !UNITY_3_5
}
#endif
