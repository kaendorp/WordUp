//
// IMonoBehaviour.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using UnityEngine;
using System.Collections;

//! Contains all Word Game Builder interfaces.
namespace Thinksquirrel.WordGameBuilder.ObjectModel
{
    /// <summary>
    /// An interface representation of a MonoBehaviour.
    /// </summary>
    /// <remarks>
    /// Also includes an additional user data property, that is not used by Word Game Builder.
    /// Allows easy access to some MonoBehaviour properties and components from an interface.
    /// \see https://docs.unity3d.com/Documentation/ScriptReference/MonoBehaviour.html
    /// \see https://docs.unity3d.com/Documentation/ScriptReference/Behaviour.html
    /// \see https://docs.unity3d.com/Documentation/ScriptReference/Component.html
    /// \see https://docs.unity3d.com/Documentation/ScriptReference/Object.html
    /// </remarks>
    public interface IMonoBehaviour
    {
        #region User data
        /// <summary>
        /// Additional user data associated with this object. This is unused by default.
        /// </summary>
        object userData { get; set; }
        #endregion
   
        #region MonoBehaviour (only the essentials are included here)
        /// <summary>
        /// Cancels all Invoke calls on this MonoBehaviour.
        /// </summary>
        void CancelInvoke();
        /// <summary>
        /// Invokes the method <c>methodName</c> in <c>time</c> seconds.
        /// </summary>
        /// <param name='methodName'>The method to invoke.</param>
        /// <param name='time'>The amount of time to wait, in seconds, before invoking the method.</param>
        void Invoke(string methodName, float time);
        /// <summary>
        /// Invokes the method methodName in time seconds.
        /// </summary>
        /// <remarks>
        /// After the first invocation repeats calling that function every <c>repeatRate</c> seconds.
        /// </remarks>
        /// <param name='methodName'>The method to invoke.</param>
        /// <param name='time'>The amount of time to wait, in seconds, before invoking the method.</param>
        /// <param name='repeatRate'>The amount of time to wait between repeat calls.</param>
        void InvokeRepeating(string methodName, float time, float repeatRate);
        /// <summary>
        /// Cancels all Invoke calls with name <c>methodName</c> on this behaviour.
        /// </summary>
        /// <param name='methodName'>The method to cancel.</param>
        void CancelInvoke(string methodName);
        /// <summary>
        /// Is any invoke pending on this MonoBehaviour?
        /// </summary>
        /// <returns>
        /// <c>true</c> if the method is invoking, otherwise <c>false</c>.
        /// </returns>
        bool IsInvoking();
        /// <summary>
        /// Is any invoke on methodName pending?
        /// </summary>
        /// <param name='methodName'>The method to check.</param>
        /// <returns>
        /// <c>true</c> if the method is invoking, otherwise <c>false</c>.
        /// </returns>
        bool IsInvoking(string methodName);
        /// <summary>
        /// Starts a coroutine.
        /// </summary>
        /// <param name='routine'>The coroutine to start.</param>
        /// <returns>
        /// StartCoroutine always returns immediately, however you can yield the result. This will wait until the coroutine has finished execution.
        /// </returns>
        Coroutine StartCoroutine(IEnumerator routine);
        /// <summary>
        /// Starts a coroutine named methodName.
        /// </summary>
        /// <param name='methodName'>The method to start.</param>
        /// <returns>
        /// StartCoroutine always returns immediately, however you can yield the result. This will wait until the coroutine has finished execution.
        /// </returns>
        Coroutine StartCoroutine(string methodName);
        /// <summary>
        /// Starts a coroutine named methodName.
        /// </summary>
        /// <param name='methodName'>The method to check.</param>
        /// <param name='value'>An argument to pass to the method.</param>
        /// <returns>
        /// StartCoroutine always returns immediately, however you can yield the result. This will wait until the coroutine has finished execution.
        /// </returns>
        Coroutine StartCoroutine(string methodName, object value);
        /// <summary>
        /// Stops all coroutines named methodName running on this behaviour.
        /// </summary>
        /// <param name='methodName'>The method to stop.</param>
        void StopCoroutine(string methodName);
        /// <summary>
        /// Stops all coroutines running on this behaviour.
        /// </summary>
        void StopAllCoroutines();
        #endregion

        #region Behaviour
        /// <summary>
        /// Enabled Behaviours are Updated, disabled Behaviours are not.
        /// </summary>
        bool enabled
        {
            get;
            set;
        }
        #endregion

        #region Component (only the essentials are included here)
        /// <summary>
        /// The game object this component is attached to. A component is always attached to a game object.
        /// </summary>
        GameObject gameObject
        {
            get;
        }
        /// <summary>
        /// The Transform attached to this GameObject. A component is always attached to a transform.
        /// </summary>
        Transform transform
        {
            get;
        }
        /// <summary>
        /// The tag of this game object.
        /// </summary>
        string tag
        {
            get;
            set;
        }
        #endregion

        #region Object (only the essentials are included here)
        /// <summary>
        /// The name of the object.
        /// </summary>
        string name
        {
            get;
            set;
        }
        /// <summary>
        /// Should the object be hidden, saved with the scene or modifiable by the user?
        /// </summary>
        HideFlags hideFlags
        {
            get;
            set;
        }
        /// <summary>
        /// Returns the instance id of the object.
        /// </summary>
        /// <returns>
        /// The instance id of this object.
        /// </returns>
        int GetInstanceID();
        /// <summary>
        /// Returns the name of the game object.
        /// </summary>
        /// <returns>
        /// The name of the game object.
        /// </returns>
        string ToString();
        #endregion
    }
}
