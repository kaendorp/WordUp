//
// ThreadBase.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using System.Threading;

namespace Thinksquirrel.WordGameBuilderInternal.Threading
{
    /// <summary>
    /// Base class for threads.
    /// </summary>
    abstract class ThreadBase : System.IDisposable
    {
        protected Dispatcher m_TargetDispatcher;
        protected Thread m_Thread;
        protected ManualResetEvent m_ExitEvent = new ManualResetEvent(false);
        [System.ThreadStatic] static ThreadBase s_CurrentThread;

        /// <summary>
        /// Returns the currently ThreadBase instance which is running in this thread.
        /// </summary>
        public static ThreadBase currentThread { get { return s_CurrentThread; } }
        
        protected ThreadBase()
            : this(true)
        {
        }

        protected ThreadBase(bool autoStartThread)
            : this(Dispatcher.current, autoStartThread)
        {
        }

        protected ThreadBase(Dispatcher targetDispatcher)
            : this(targetDispatcher, true)
        {
            this.m_TargetDispatcher = targetDispatcher;
        }

        protected ThreadBase(Dispatcher targetDispatcher, bool autoStartThread)
        {
            this.m_TargetDispatcher = targetDispatcher;
            if (autoStartThread)
                Start();
        }

        /// <summary>
        /// Returns true if the thread is working.
        /// </summary>
        public bool isAlive { get { return m_Thread != null && m_Thread.IsAlive; } }

        /// <summary>
        /// Returns true if the thread should stop working.
        /// </summary>
        public bool shouldStop { get { return ThreadUtility.WaitOne(m_ExitEvent, 0); } }

        /// <summary>
        /// Starts the thread.
        /// </summary>
        public void Start()
        {
            if (m_Thread != null)
                Abort();

            m_ExitEvent.Reset();
            m_Thread = new Thread(DoInternal);
            m_Thread.Start();
        }

        /// <summary>
        /// Notifies the thread to stop working.
        /// </summary>
        public void Exit()
        {
            if (m_Thread != null)
                m_ExitEvent.Set();
        }

        /// <summary>
        /// Notifies the thread to stop working.
        /// </summary>
        public void Abort()
        {
            Exit();
            if (m_Thread != null)
                m_Thread.Join();
        }

        /// <summary>
        /// Notifies the thread to stop working and waits for completion for the given ammount of time.
        /// When the thread soes not stop after the given timeout the thread will be terminated.
        /// </summary>
        /// <param name="seconds">The time this method will wait until the thread will be terminated.</param>
        public void AbortWaitForSeconds(float seconds)
        {
            Exit();
            if (m_Thread != null)
            {
                m_Thread.Join((int)(seconds * 1000));
                if (m_Thread.IsAlive)
                    m_Thread.Abort();
            }
        }

        /// <summary>
        /// Creates a new Task for the target Dispatcher (default: the main Dispatcher) based upon the given function.
        /// </summary>
        /// <typeparam name="T">The return value of the task.</typeparam>
        /// <param name="function">The function to process at the dispatchers thread.</param>
        /// <returns>The new task.</returns>
        public Task<T> Dispatch<T>(System.Func<TaskBase, T> function)
        {
            return m_TargetDispatcher.Dispatch(function);
        }

        /// <summary>
        /// Creates a new Task for the target Dispatcher (default: the main Dispatcher) based upon the given function.
        /// This method will wait for the task completion and returns the return value.
        /// </summary>
        /// <typeparam name="T">The return value of the task.</typeparam>
        /// <param name="function">The function to process at the dispatchers thread.</param>
        /// <returns>The return value of the tasks function.</returns>
        public T DispatchAndWait<T>(System.Func<TaskBase, T> function)
        {
            var task = Dispatch(function);
            task.Wait();
            return task.result;
        }

        /// <summary>
        /// Creates a new Task for the target Dispatcher (default: the main Dispatcher) based upon the given function.
        /// This method will wait for the task completion or the timeout and returns the return value.
        /// </summary>
        /// <typeparam name="T">The return value of the task.</typeparam>
        /// <param name="function">The function to process at the dispatchers thread.</param>
        /// <param name="timeOutSeconds">Time in seconds after the waiting process will stop.</param>
        /// <returns>The return value of the tasks function.</returns>
        public T DispatchAndWait<T>(System.Func<TaskBase, T> function, float timeOutSeconds)
        {
            var task = Dispatch(function);
            task.WaitForSeconds(timeOutSeconds);
            return task.result;
        }

        /// <summary>
        /// Creates a new Task for the target Dispatcher (default: the main Dispatcher) based upon the given action.
        /// </summary>
        /// <param name="action">The action to process at the dispatchers thread.</param>
        /// <returns>The new task.</returns>
        public Task Dispatch(System.Action<TaskBase> action)
        {
            return m_TargetDispatcher.Dispatch(action);
        }

        /// <summary>
        /// Creates a new Task for the target Dispatcher (default: the main Dispatcher) based upon the given action.
        /// This method will wait for the task completion.
        /// </summary>
        /// <param name="action">The action to process at the dispatchers thread.</param>
        public void DispatchAndWait(System.Action<TaskBase> action)
        {
            var task = Dispatch(action);
            task.Wait();
        }

        /// <summary>
        /// Creates a new Task for the target Dispatcher (default: the main Dispatcher) based upon the given action.
        /// This method will wait for the task completion or the timeout.
        /// </summary>
        /// <param name="action">The action to process at the dispatchers thread.</param>
        /// <param name="timeOutSeconds">Time in seconds after the waiting process will stop.</param>
        public void DispatchAndWait(System.Action<TaskBase> action, float timeOutSeconds)
        {
            var task = Dispatch(action);
            task.WaitForSeconds(timeOutSeconds);
        }

        protected void DoInternal()
        {
            s_CurrentThread = this;
            Do();
        }
/*! \cond PRIVATE */
        protected abstract void Do();
/*! \endcond */
        #region IDisposable Members

        /// <summary>
        /// Disposes the thread and all resources.
        /// </summary>
        public virtual void Dispose()
        {
            AbortWaitForSeconds(1.0f);
        }

        #endregion
    }
}
