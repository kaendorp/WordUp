//
// Task.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using System.Threading;


namespace Thinksquirrel.WordGameBuilderInternal.Threading
{
    /// <summary>
    /// A task to be performed by a dispatcher.
    /// </summary>
    sealed class Task : TaskBase
    {
        System.Action<TaskBase> m_Action;

        static ObjectPool<Task> s_TaskPool;

        static Task()
        {
            s_TaskPool = new ObjectPool<Task>(() => new Task(null),
                task =>
                {
                    task.m_Action = null;
                    task.Dispose();
                    task.m_AbortEvent = new ManualResetEvent(false);
                    task.m_EndedEvent = new ManualResetEvent(false);
                    task.m_HasStarted = false;
                });
        }
        Task(System.Action<TaskBase> action)
        {
            this.m_Action = action;
        }

        public static Task Create(System.Action<TaskBase> action)
        {
            var task = s_TaskPool.Pop();
            task.m_Action = action;
            return task;
        }

        public static void Destroy(Task task)
        {
            s_TaskPool.Push(task);
        }

        /*! \cond PRIVATE */
        protected override void Do(TaskBase task)
        {
            if (m_Action != null)
            	m_Action(task);
        }
        /*! \endcond */
        
        public override TResult Wait<TResult>()
        {
            throw new System.InvalidOperationException("This task type does not support return values.");
        }

        public override TResult WaitForSeconds<TResult>(float seconds)
        {
            throw new System.InvalidOperationException("This task type does not support return values.");
        }

        public override TResult WaitForSeconds<TResult>(float seconds, TResult defaultReturnValue)
        {
            throw new System.InvalidOperationException("This task type does not support return values.");
        }
    }
    
    /// <summary>
    /// A task to be performed by a dispatcher.
    /// </summary>
    sealed class Task<T> : TaskBase
    {
        System.Func<TaskBase, T> m_Function;
        T m_Result;

        // Analysis disable StaticFieldInGenericType
        static ObjectPool<Task<T>> s_TaskPool;
        // Analysis restore StaticFieldInGenericType
        
        static Task()
        {
            s_TaskPool = new ObjectPool<Task<T>>(() => new Task<T>(null),
                task =>
                {
                    task.m_Function = null;
                    task.Dispose();
                    task.m_AbortEvent = new ManualResetEvent(false);
                    task.m_EndedEvent = new ManualResetEvent(false);
                    task.m_HasStarted = false;
                });
        }

        Task(System.Func<TaskBase, T> function)
        {
            this.m_Function = function;
        }

        public static Task<T> Create(System.Func<TaskBase, T> function)
        {
            var task = s_TaskPool.Pop();
            task.m_Function = function;
            return task;
        }
        
        public static void Destroy(Task<T> task)
        {
            s_TaskPool.Push(task);
        }

        /*! \cond PRIVATE */
        protected override void Do(TaskBase task)
        {
            m_Result = m_Function(task);
        }
        /*! \endcond */
        
        public override TResult Wait<TResult>()
        {
            return (TResult)(object)result;
        }

        public override TResult WaitForSeconds<TResult>(float seconds)
        {
            return WaitForSeconds(seconds, default(TResult));
        }

        public override TResult WaitForSeconds<TResult>(float seconds, TResult defaultReturnValue)
        {
            if (!hasEnded)
                WaitForSeconds(seconds);

            return isSucceeded ? (TResult)(object)m_Result : defaultReturnValue;
        }
        
        /// <summary>
        /// Waits till completion and returns the operation result.
        /// </summary>
        public T result
        {
            get
            {
                if (!hasEnded)
                    Wait();

                return m_Result;
            }
        }
    }
}
