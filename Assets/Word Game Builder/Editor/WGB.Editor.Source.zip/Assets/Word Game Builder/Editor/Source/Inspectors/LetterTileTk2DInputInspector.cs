//
// LetterTileTk2DInputInspector.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using UnityEditor;

#if !UNITY_3_5
using Thinksquirrel.WordGameBuilder.Tiles.Tk2D;
namespace Thinksquirrel.WordGameBuilderEditor
{
#else
    using Thinksquirrel.WordGameBuilderEditor;
#endif
    //! \cond PRIVATE
    [CustomEditor(typeof(LetterTileTk2DInput))]
    [CanEditMultipleObjects]
    sealed class LetterTileTk2DInputInspector : WGBInspectorBase
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
        }
    }
    //! \endcond
#if !UNITY_3_5
}
#endif
