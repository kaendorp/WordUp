//
// LanguageEditor.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using System.IO;
using System.Linq;
using System.Text;
using Thinksquirrel.WordGameBuilder;
using UnityEditor;
using UnityEngine;

#if !UNITY_3_5
//! Contains all editor-only classes.
namespace Thinksquirrel.WordGameBuilderEditor
{
#else
using Thinksquirrel.WordGameBuilderEditor;
#endif
    /// <summary>
    /// Various resources for modifying languages through editor scripts.
    /// </summary>
    public sealed class LanguageEditor : EditorWindow
    {
        /// <summary>
        /// The path for Word Game Builder languages.
        /// </summary>
        /// <remarks>
        /// This value is persistent (stored in editor preferences). In order to ensure that this value does not change when switching machines or clearing
        /// editor preferences, it is recommended to create a static editor class that sets this value with the [InitializeOnLoad] attribute.
        ///
        /// Example:
        /// <code>
        /// using UnityEditor;
        /// using Thinksquirrel.WordGameBuilderEditor;
        ///
        /// [InitializeOnLoad]
        /// static class SetLanguagePath
        /// {
        ///     SetLanguagePath()
        ///     {
        ///         LanguageEditor.languagePath = "My/Settings/Folder";
        ///     }
        /// }
        /// </code>
        /// </remarks>
        public static string languagePath
        {
            get
            {
                s_LanguagePath = EditorPrefs.GetString("Thinksquirrel.WordGameBuilderEditor.LanguagePath", "WGB-UserSettings");
                return s_LanguagePath;
            }
            set
            {
                if (s_LanguagePath != value)
                {
                    if (System.Uri.IsWellFormedUriString(value, System.UriKind.Relative))
                    {
                        s_LanguagePath = value;
                        EditorPrefs.SetString("Thinksquirrel.WordGameBuilderEditor.LanguagePath", value);
                    }
                    else
                    {
                        WGBBase.LogError("Language folder path is not a valid relative path name", "Word Game Builder", "LanguageEditor");
                    }
                }
            }
        }
        static string s_LanguagePath;

        [SerializeField] bool m_LanguageSelectionFoldout = true;
        [SerializeField] bool m_LanguageInfoFoldout = true;
        [SerializeField] bool m_LanguageSettingsFoldout = true;
        [SerializeField] bool m_LettersFoldout;
        [SerializeField] bool m_WordsFoldout = true;
        [SerializeField] bool m_ImportExportFoldout = true;
        [SerializeField] bool m_AdditionalOptionsFoldout;

        [SerializeField] string m_NewLanguage = "";
        [SerializeField] string m_NewLangName = "";
        [SerializeField] string m_NewWord = "";
        [SerializeField] string m_NewLetter = "";
        [SerializeField] string m_NewValue = "";
        [SerializeField] int m_NewScore;
        [SerializeField] bool m_AllowBlanks;
        [SerializeField] bool m_CaseSensitive;

        [SerializeField] Vector2 m_ScrollPosition;

        [SerializeField] int m_Index = -1;
        [SerializeField] int m_Columns = 1;

        bool m_RemoveLetter;
        Letter m_Letter;
        int m_BlankLetterWeight;
        bool m_Cancelled;
        bool m_WordCheck;
        internal static WordGameLanguage _startLanguage;

        void OnEnable()
        {
            LoadFoldouts();
            bool decompress = WordGameLanguage.decompressOnLoad;
            WordGameLanguage.decompressOnLoad = false;
            WordGameLanguage.LoadAllLanguages();
            InitializeGUI();
            WordGameLanguage.decompressOnLoad = decompress;
        }

        void OnDisable()
        {
            CultureIDPopup.ClosePopup();
            SaveFoldouts();
        }

        void LoadFoldouts()
        {
            m_LanguageSelectionFoldout = EditorPrefs.GetBool("Thinksquirrel.WordGameBuilderEditor.LanguageEditor.LanguageSelectionFoldout", true);
            m_LanguageInfoFoldout = EditorPrefs.GetBool("Thinksquirrel.WordGameBuilderEditor.LanguageEditor.LanguageInfoFoldout", true);
            m_LanguageSettingsFoldout = EditorPrefs.GetBool("Thinksquirrel.WordGameBuilderEditor.LanguageEditor.LanguageSettingsFoldout", true);
            m_LettersFoldout = EditorPrefs.GetBool("Thinksquirrel.WordGameBuilderEditor.LanguageEditor.LettersFoldout", false);
            m_WordsFoldout = EditorPrefs.GetBool("Thinksquirrel.WordGameBuilderEditor.LanguageEditor.WordsFoldout", true);
            m_ImportExportFoldout = EditorPrefs.GetBool("Thinksquirrel.WordGameBuilderEditor.LanguageEditor.ImportExportFoldout", true);
            m_AdditionalOptionsFoldout = EditorPrefs.GetBool("Thinksquirrel.WordGameBuilderEditor.LanguageEditor.AdditionalOptionsFoldout", false);
        }

        void SaveFoldouts()
        {
            EditorPrefs.SetBool("Thinksquirrel.WordGameBuilderEditor.LanguageEditor.LanguageSelectionFoldout", m_LanguageSelectionFoldout);
            EditorPrefs.SetBool("Thinksquirrel.WordGameBuilderEditor.LanguageEditor.LanguageInfoFoldout", m_LanguageInfoFoldout);
            EditorPrefs.SetBool("Thinksquirrel.WordGameBuilderEditor.LanguageEditor.LanguageSettingsFoldout", m_LanguageSettingsFoldout);
            EditorPrefs.SetBool("Thinksquirrel.WordGameBuilderEditor.LanguageEditor.LettersFoldout", m_LettersFoldout);
            EditorPrefs.SetBool("Thinksquirrel.WordGameBuilderEditor.LanguageEditor.WordsFoldout", m_WordsFoldout);
            EditorPrefs.SetBool("Thinksquirrel.WordGameBuilderEditor.LanguageEditor.ImportExportFoldout", m_ImportExportFoldout);
            EditorPrefs.SetBool("Thinksquirrel.WordGameBuilderEditor.LanguageEditor.AdditionalOptionsFoldout", m_AdditionalOptionsFoldout);
        }

        void OnLanguageLoad()
        {
            m_Cancelled = false;
            Repaint();
        }

        void OnLanguageLoadCancel()
        {
            m_Cancelled = true;
        }

        void InitializeGUI()
        {
            m_Cancelled = false;

            ChangeLanguage(_startLanguage != null ? _startLanguage : WordGameLanguage.current, false, false);
        }

        void ChangeLanguage(WordGameLanguage language, bool newLanguage, bool saveLanguage)
        {
            if (!language)
                return;

            _startLanguage = null;
            WordGameLanguage.current = language;
            m_Cancelled = false;
            WGBEditorHelpers.LoadLanguageWithProgressBar(language.identifier, OnLanguageLoad, OnLanguageLoadCancel);
            if (newLanguage)
            {
                m_NewLanguage = "";
            }
            if (saveLanguage)
            {
                SaveLanguage(language);
            }
            m_AllowBlanks = language.allowBlanks;
            m_CaseSensitive = language.caseSensitive;
            Repaint();
        }

        void OnGUI()
        {
            bool decompress = WordGameLanguage.decompressOnLoad;
            WordGameLanguage.decompressOnLoad = false;

            var languages = WordGameLanguage.GetAllLanguages();
            var languageNames = languages.Select(l => l.languageName).ToArray();

            for (int i = 0; i < languageNames.Length; ++i)
            {
                if(System.Array.IndexOf<string>(languageNames, languageNames[i]) < i)
                    languageNames[i] = string.Format("{0} ({1})", languageNames[i], languages[i].identifier);
            }

            if (_startLanguage != null || !WordGameLanguage.current)
            {
                InitializeGUI();
            }

            m_ScrollPosition = GUILayout.BeginScrollView(
                m_ScrollPosition,
                false,
                false);

            if (WordGameLanguage.current)
            {
                for (int i = 0; i < languages.Length; i++)
                {
                    if (WordGameLanguage.current == languages[i])
                    {
                        m_Index = i;
                        break;
                    }
                }
            }

            if (Event.current.type == EventType.Layout)
            {
                m_Columns = Mathf.Max((int)(position.width / 275f), 1);
            }
            minSize = new Vector2(275, 50);

            GUILayout.Space(10);
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            GUILayout.Label("Word Game Builder: Language Editor", EditorStyles.largeLabel);
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            GUILayout.Space(10);

            GUI.enabled = !CultureIDPopup.popupEnabled;
            GUILayout.BeginVertical(GUI.skin.GetStyle("ShurikenEffectBg"));

            GUI.backgroundColor = Color.gray;
            m_LanguageSelectionFoldout = GUILayout.Toggle(m_LanguageSelectionFoldout, "Language Selection", GUI.skin.GetStyle("Toolbarbutton"), GUILayout.ExpandWidth(true));
            GUI.backgroundColor = Color.white;

            if (m_LanguageSelectionFoldout)
            {
                GUILayout.BeginVertical(GUI.skin.GetStyle("ShurikenModuleBg"));

                WordGameLanguage.defaultLanguage = EditorGUILayout.TextField("Default Language", WordGameLanguage.defaultLanguage);

                EditorGUILayout.BeginHorizontal();
                m_NewLanguage = EditorGUILayout.TextField("New Language", m_NewLanguage, GUILayout.ExpandWidth(true));

                if (GUILayout.Button("+", EditorStyles.miniButton, GUILayout.Width(25)))
                {
                    if (!string.IsNullOrEmpty(m_NewLanguage))
                    {
                        ChangeLanguage(WordGameLanguage.Create(m_NewLanguage, LangToIdentifier(m_NewLanguage)), true, true);
                    }
                }
                EditorGUILayout.EndHorizontal();

                if (GUILayout.Button("Import Default Languages"))
                    WGBMenuItems.ImportDefaultLanguages();

                if (languages.Length == 0)
                {
                    EditorGUILayout.HelpBox("To create a language, either import the a default language, or enter a name and click \"+\". More options will become visible once a language has been created.", MessageType.Info);
                    GUILayout.EndVertical();
                    GUILayout.EndVertical();
                    GUILayout.FlexibleSpace();
                    GUILayout.EndScrollView();
                    WordGameLanguage.decompressOnLoad = decompress;
                    return;
                }

                GUILayout.BeginHorizontal();
                int lastIndex = m_Index;
                m_Index = EditorGUILayout.Popup("Current Language", Mathf.Clamp(m_Index, 0, languages.Length - 1), languageNames);

                GUILayout.EndHorizontal();

                if (!WGBEditorHelpers.isLoadingLanguage && (WordGameLanguage.current && (m_Cancelled || !WordGameLanguage.current.wordSet.isExpanded)))
                {
                    if (GUILayout.Button("Reload"))
                    {
                        ChangeLanguage(languages [m_Index], false, false);
                    }
                    GUILayout.EndHorizontal();
                    GUILayout.EndVertical();
                    EditorGUILayout.HelpBox("The current language must be reloaded first!", MessageType.Warning);
                    GUILayout.FlexibleSpace();
                    GUILayout.EndScrollView();
                    WordGameLanguage.decompressOnLoad = decompress;
                    return;
                }

                if (WGBEditorHelpers.isLoadingLanguage)
                {
                    GUILayout.EndHorizontal();
                    GUILayout.EndVertical();
                    EditorGUILayout.HelpBox(string.Format("Loading {0}...", WordGameLanguage.current.languageName), MessageType.Info);
                    GUILayout.FlexibleSpace();
                    GUILayout.EndScrollView();
                    WordGameLanguage.decompressOnLoad = decompress;
                    return;
                }

                if (lastIndex != m_Index)
                {
                    ChangeLanguage(languages [m_Index], false, false);
                }

                GUILayout.EndVertical();
            }

            if (WordGameLanguage.current)
            {
                GUI.backgroundColor = Color.gray;
                m_LanguageInfoFoldout = GUILayout.Toggle(m_LanguageInfoFoldout, "Language Info", GUI.skin.GetStyle("Toolbarbutton"), GUILayout.ExpandWidth(true));
                GUI.backgroundColor = Color.white;
                if (m_LanguageInfoFoldout)
                {
                    GUILayout.BeginVertical(GUI.skin.GetStyle("ShurikenModuleBg"));
                    if (m_Columns > 1)
                        GUILayout.BeginHorizontal();
                    EditorGUILayout.LabelField("Letter Count", WordGameLanguage.current.letters.Count.ToString());
                    EditorGUILayout.LabelField("Word Count", WordGameLanguage.current.wordCount.ToString());
                    if (m_Columns > 1)
                        GUILayout.EndHorizontal();
                    GUILayout.EndVertical();
                }

                GUI.backgroundColor = Color.gray;
                m_LanguageSettingsFoldout = GUILayout.Toggle(m_LanguageSettingsFoldout, "Language Settings", GUI.skin.GetStyle("Toolbarbutton"), GUILayout.ExpandWidth(true));
                GUI.backgroundColor = Color.white;
                if (m_LanguageSettingsFoldout)
                {
                    GUILayout.BeginVertical(GUI.skin.GetStyle("ShurikenModuleBg"));
                    GUILayout.BeginHorizontal();
                    EditorGUILayout.PrefixLabel("Culture");
                    bool e = GUI.enabled;
                    GUI.enabled = false;
                    GUILayout.Label(WordGameLanguage.current.culture.NativeName, EditorStyles.textField);
                    GUI.enabled = e;

                    if (GUILayout.Button("...", EditorStyles.miniButton, GUILayout.Width(25)))
                    {
                        CultureIDPopup.OpenPopup();
                    }
                    GUILayout.EndHorizontal();

                    if (WordGameLanguage.current.caseSensitive != m_CaseSensitive)
                    {
                        WordGameLanguage.current.caseSensitive = m_CaseSensitive;
                        SaveLanguage(WordGameLanguage.current);
                    }
                    if (WordGameLanguage.current.allowBlanks != m_AllowBlanks)
                    {
                        WordGameLanguage.current.allowBlanks = m_AllowBlanks;
                        SaveLanguage(WordGameLanguage.current);
                    }
                    if (WordGameLanguage.current.blankLetterWeight != m_BlankLetterWeight)
                    {
                        WordGameLanguage.current.blankLetterWeight = m_BlankLetterWeight;
                        SaveLanguage(WordGameLanguage.current);
                    }

                    if (m_Columns > 1)
                        GUILayout.BeginHorizontal();
                    m_AllowBlanks = EditorGUILayout.Toggle("Allow Blanks", m_AllowBlanks);
                    m_CaseSensitive = EditorGUILayout.Toggle("Case Sensitive", m_CaseSensitive);
                    if (m_Columns > 1)
                        GUILayout.EndHorizontal();

                    m_BlankLetterWeight = m_AllowBlanks ?
                    EditorGUILayout.IntField("Blank Letter Weight", m_BlankLetterWeight) :
                    WordGameLanguage.current.blankLetterWeight;
                    GUILayout.EndVertical();
                }

                GUI.backgroundColor = Color.gray;
                m_LettersFoldout = GUILayout.Toggle(m_LettersFoldout, "Letters", GUI.skin.GetStyle("Toolbarbutton"), GUILayout.ExpandWidth(true));
                GUI.backgroundColor = Color.white;
                if (m_LettersFoldout)
                {
                    GUILayout.BeginVertical(GUI.skin.GetStyle("ShurikenModuleBg"));
                    var third = (position.width / m_Columns / 3) - 24;

                    GUILayout.BeginHorizontal(EditorStyles.toolbar, GUILayout.ExpandWidth(true));
                    GUILayout.FlexibleSpace();
                    for (int i = 0; i < m_Columns; ++i)
                    {
                        GUILayout.Label("Letter", EditorStyles.miniLabel, GUILayout.Width(third));
                        GUILayout.Label("Character", EditorStyles.miniLabel, GUILayout.Width(third));
                        GUILayout.Label("Score", EditorStyles.miniLabel, GUILayout.Width(third));
                        GUILayout.Label("", EditorStyles.miniLabel, GUILayout.Width(16));
                    }
                    GUILayout.FlexibleSpace();
                    GUILayout.EndHorizontal();

                    GUILayout.BeginHorizontal();
                    GUILayout.FlexibleSpace();
                    GUILayout.BeginVertical();

                    string t = string.Empty;
                    char v = char.MinValue;
                    int s = 0;
                    bool changeValue = false;

                    GUILayout.BeginHorizontal();
                    for (int i = 0, l = WordGameLanguage.current.letters.Count; i < l; i++)
                    {
                        var letter = WordGameLanguage.current.letters [i];
                        string text = EditorGUILayout.TextField(letter.text, GUILayout.Width(third));
                        string val = EditorGUILayout.TextField(letter.character.ToString(), GUILayout.Width(third));
                        string score = EditorGUILayout.TextField(letter.score.ToString(), GUILayout.Width(third));
                        if (GUILayout.Button("x", EditorStyles.miniButton, GUILayout.Width(25)))
                        {
                            m_RemoveLetter = true;
                            m_Letter = letter;
                        }
                        if (!changeValue)
                        {
                            try
                            {
                                t = text;
                                v = char.Parse(val);
                                s = int.Parse(score);
                            }
                            catch
                            {
                                t = letter.text;
                                v = letter.character;
                                s = letter.score;
                            }
                            changeValue |= (t != letter.text || v != letter.character || s != letter.score) && !string.IsNullOrEmpty(t) && v > 0;
                        }
                        if ((i + 1) % m_Columns == 0)
                        {
                            GUILayout.EndHorizontal();
                            GUILayout.BeginHorizontal();
                        }
                        if (changeValue)
                        {
                            try
                            {
                                WordGameLanguage.current.letters [i] = new Letter(t, v, s);
                                SaveLanguage(WordGameLanguage.current);
                            }
                            catch
                            {
                                WGBBase.LogError("Unable to change letter - Duplicate characters are not allowed!", "Word Game Builder", "LanguageEditor", this);
                            }
                            changeValue = false;
                        }
                    }
                    GUILayout.BeginHorizontal();
                    m_NewLetter = EditorGUILayout.TextField(m_NewLetter, GUILayout.Width(third));
                    m_NewValue = EditorGUILayout.TextField(m_NewValue, GUILayout.Width(third));
                    m_NewScore = EditorGUILayout.IntField(m_NewScore, GUILayout.Width(third));

                    char nv;
                    if (GUILayout.Button("+", EditorStyles.miniButton, GUILayout.Width(25)) && char.TryParse(m_NewValue, out nv))
                    {
                        if (!string.IsNullOrEmpty(m_NewLetter))
                        {
                            WordGameLanguage.current.letters.Add(new Letter(m_NewLetter, nv, m_NewScore));
                            SaveLanguage(WordGameLanguage.current);
                            m_NewLetter = "";
                            m_NewValue = "";
                            m_NewScore = 0;
                            Repaint();
                        }
                    }
                    GUILayout.EndHorizontal();
                    GUILayout.EndHorizontal();
                    GUILayout.EndVertical();
                    GUILayout.FlexibleSpace();
                    GUILayout.EndHorizontal();

                    if (m_RemoveLetter)
                    {
                        if (WordGameLanguage.current.letters.Remove(m_Letter))
                        {
                            WordGameLanguage.current.wordSet.Optimize();
                            SaveLanguage(WordGameLanguage.current);
                            m_RemoveLetter = false;
                        }
                    }
                    GUILayout.EndVertical();
                }

                GUI.backgroundColor = Color.gray;
                m_WordsFoldout = GUILayout.Toggle(m_WordsFoldout, "Words", GUI.skin.GetStyle("Toolbarbutton"), GUILayout.ExpandWidth(true));
                GUI.backgroundColor = Color.white;
                if (m_WordsFoldout)
                {
                    GUILayout.BeginVertical(GUI.skin.GetStyle("ShurikenModuleBg"));
                    GUILayout.BeginHorizontal();
                    if (Event.current.type == EventType.Layout)
                    {
                        m_WordCheck = WordGameLanguage.current.wordSet.Contains(m_NewWord);
                    }
                    m_NewWord = EditorGUILayout.TextField("Add/Remove Word", m_NewWord);

                    bool emptyNewWord = string.IsNullOrEmpty(m_NewWord);
                    bool guiEnabled = GUI.enabled;

                    GUI.color = emptyNewWord ? Color.white : m_WordCheck ? Color.red : Color.green;
                    GUI.enabled = !emptyNewWord;

                    if (GUILayout.Button(emptyNewWord ? "+" : m_WordCheck ? "-" : "+", EditorStyles.miniButton, GUILayout.Width(25)))
                    {
                        if (m_WordCheck)
                        {
                            if (WordGameLanguage.current.wordSet.Remove(m_NewWord))
                            {
                                WordGameLanguage.current.wordSet.Optimize();
                                SaveLanguage(WordGameLanguage.current);
                                m_NewWord = "";
                                Repaint();
                            }
                            else
                            {
                                WGBBase.LogError(string.Format("Unable to remove word: {0} - word not found.", m_NewWord), "Word Game Builder", "LanguageEditor", this);
                            }
                        }
                        else
                        {
                            if (WordGameLanguage.current.wordSet.Insert(m_NewWord))
                            {
                                WordGameLanguage.current.wordSet.Optimize();
                                SaveLanguage(WordGameLanguage.current);
                                m_NewWord = "";
                                Repaint();
                            }
                            else
                            {
                                WGBBase.LogError(string.Format("Unable to add word: {0} - make sure all letters exist for the word before adding it.", m_NewWord), "Word Game Builder", "LanguageEditor", this);
                            }
                        }
                    }

                    GUI.enabled = guiEnabled;

                    GUI.color = Color.white;

                    GUILayout.EndHorizontal();
                    GUILayout.EndVertical();
                }

                GUI.backgroundColor = Color.gray;
                m_ImportExportFoldout = GUILayout.Toggle(m_ImportExportFoldout, "Import/Export", GUI.skin.GetStyle("Toolbarbutton"), GUILayout.ExpandWidth(true));
                GUI.backgroundColor = Color.white;
                if (m_ImportExportFoldout)
                {
                    GUILayout.BeginVertical(GUI.skin.GetStyle("ShurikenModuleBg"));
                    if (m_Columns > 1)
                        GUILayout.BeginHorizontal();
                    if (GUILayout.Button("Import Letters", GUILayout.ExpandWidth(true)))
                    {
                        string csvPath = EditorUtility.OpenFilePanel("Import CSV file (Letters)...", "", "csv");

                        if (csvPath.Length > 0)
                        {
                            WordGameLanguage.current.ImportLettersFromCsv(csvPath);
                            SaveLanguage(WordGameLanguage.current);
                        }
                    }
                    if (GUILayout.Button("Import Words", GUILayout.ExpandWidth(true)))
                    {
                        string csvPath = EditorUtility.OpenFilePanel("Import CSV file (Words)...", "", "csv");

                        if (csvPath.Length > 0)
                        {
                            WordGameLanguage.current.ImportWordsFromCsv(csvPath, false);
                            SaveLanguage(WordGameLanguage.current);
                        }
                    }
                    if (m_Columns > 1)
                        GUILayout.EndHorizontal();
                    if (m_Columns > 1)
                        GUILayout.BeginHorizontal();
                    if (GUILayout.Button("Export Letters", GUILayout.ExpandWidth(true)))
                    {
                        string csvPath = EditorUtility.SaveFilePanel("Export CSV file (Letters)...", "", WordGameLanguage.current.languageName + " - letters.csv", "csv");

                        if (csvPath.Length > 0)
                            WordGameLanguage.current.ExportLettersToCsv(csvPath);
                    }
                    if (GUILayout.Button("Export Words", GUILayout.ExpandWidth(true)))
                    {
                        string csvPath = EditorUtility.SaveFilePanel("Export CSV file (Words)...", "", WordGameLanguage.current.languageName + " - words.csv", "csv");

                        if (csvPath.Length > 0)
                            WordGameLanguage.current.ExportWordsToCsv(csvPath);
                    }
                    if (m_Columns > 1)
                        GUILayout.EndHorizontal();

                    if (GUILayout.Button("Merge Words Into Language"))
                    {
                        string csvPath = EditorUtility.OpenFilePanel("Merge CSV file (Words)...", "", "csv");

                        if (csvPath.Length > 0)
                        {
                            WordGameLanguage.current.ImportWordsFromCsv(csvPath, true);
                            SaveLanguage(WordGameLanguage.current);
                        }
                    }
                    GUILayout.EndVertical();
                }

                GUI.backgroundColor = Color.gray;
                m_AdditionalOptionsFoldout = GUILayout.Toggle(m_AdditionalOptionsFoldout, "Additional Options", GUI.skin.GetStyle("Toolbarbutton"), GUILayout.ExpandWidth(true));
                GUI.backgroundColor = Color.white;
                if (m_AdditionalOptionsFoldout)
                {
                    GUILayout.BeginVertical(GUI.skin.GetStyle("ShurikenModuleBg"));
                    GUILayout.BeginHorizontal();
                    m_NewLangName = EditorGUILayout.TextField("Rename Language", m_NewLangName);

                    if (GUILayout.Button("Ok", EditorStyles.miniButton, GUILayout.Width(25)))
                    {
                        if (m_NewLangName != WordGameLanguage.current.languageName && !string.IsNullOrEmpty(m_NewLangName))
                        {
                            var lang = WordGameLanguage.current;
                            lang.languageName = m_NewLangName;
                            lang.identifier = LangToIdentifier(m_NewLangName);
                            m_NewLangName = string.Empty;
                            SaveLanguage(lang);
                            _startLanguage = lang;
                        }
                    }
                    GUILayout.EndHorizontal();

                    if (GUILayout.Button("Duplicate Language"))
                    {
                        ChangeLanguage(WordGameLanguage.current.Copy(), false, true);
                    }

                    GUI.color = Color.red;
                    if (GUILayout.Button(string.Format("Remove {0}", WordGameLanguage.current.languageName)))
                    {
                        if (EditorUtility.DisplayDialog("Remove " + WordGameLanguage.current.languageName + "?", "Are you sure you want to remove the selected language?", "OK", "Cancel"))
                        {
                            RemoveLanguage(WordGameLanguage.current, languages);
                        }
                    }
                    GUI.color = Color.white;
                    GUILayout.EndVertical();
                }
            }

            GUILayout.EndVertical();

            GUI.enabled = true;

            GUILayout.FlexibleSpace();
            GUILayout.EndScrollView();

            WordGameLanguage.decompressOnLoad = decompress;
        }

        /// <summary>
        /// Saves a language as an asset.
        /// </summary>
        /// <param name="language">The language to save.</param>
        public static void SaveLanguage(WordGameLanguage language)
        {
            SaveLanguage(language, false);
        }

        internal static void SaveLanguage(WordGameLanguage language, bool overrideFiles)
        {
            EditorUtility.SetDirty(language);
            string identifier = string.IsNullOrEmpty(language.identifier) ? LangToIdentifier(language.languageName) : language.identifier;
            string langFolder = string.Format("{0}/Resources/{1}", languagePath, WordGameLanguage.k_ResourceFolder);
            string baseFolder = string.Format("Assets/{0}/{1}", langFolder, identifier);
            string langPath = string.Format("{0}/language.asset", baseFolder);
            string prefixesPath = string.Format("{0}/prefixes.txt", baseFolder);
            string prefixToSuffixLengthPath = string.Format("{0}/prefixToSuffixLength.txt", baseFolder);
            string suffixesPath = string.Format("{0}/suffixes.txt", baseFolder);
            string prefixToSuffixPath = string.Format("{0}/prefixToSuffix.txt", baseFolder);

            if (AssetDatabase.Contains(language))
            {
                var path = Path.Combine(Application.dataPath.Substring(0, Application.dataPath.Length - 7), AssetDatabase.GetAssetPath(language));

                var oldIdentifier = new FileInfo(path).Directory.Name;

                if (oldIdentifier != identifier)
                {
                    language.identifier = identifier;
                    AssetDatabase.RenameAsset(string.Format("Assets/{0}/{1}", langFolder, oldIdentifier), identifier);
                }

                language.wordSet.SerializeArrays(prefixesPath, prefixToSuffixLengthPath, suffixesPath, prefixToSuffixPath);
                AssetDatabase.Refresh();
            }
            else if (!overrideFiles && File.Exists(langPath))
            {
                // Block any uninentional file overrides
                WGBBase.LogError("A different asset with this name already exists! Please delete the asset at the following path:\n" + langPath, "Word Game Builder", "Language Editor");
            }
            else
            {
                var path = Path.Combine(Application.dataPath, langFolder);
                path = Path.Combine(path, identifier);
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                language.wordSet.SerializeArrays(prefixesPath, prefixToSuffixLengthPath, suffixesPath, prefixToSuffixPath);
                AssetDatabase.Refresh();
                language.identifier = identifier;
                AssetDatabase.CreateAsset(language, langPath);
                AssetDatabase.AddObjectToAsset(language.wordSet, language);
            }
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }

        /// <summary>
        /// Convert a language name into an identifier, by removing all diacritical marks. Also ensures that the name is unique.
        /// </summary>
        /// <returns>A sanitized language name, suitible for a file.</returns>
        /// <param name="languageName">The language name to convert into an identifier.</param>
        public static string LangToIdentifier(string languageName)
        {
            return LangToIdentifierInternal(languageName, true);
        }

        internal static string LangToIdentifierInternal(string languageName, bool unique)
        {
            if (!unique)
                return RemoveDiacritics(Sanitize(languageName));

            WordGameLanguage.LoadAllLanguages();

            string id = RemoveDiacritics(Sanitize(languageName));
            string result = id;
            int append = 1;

            while (WordGameLanguage.FindByIdentifier(result) != null)
            {
                result = string.Format("{0} {1}", id, append);
                ++append;
            }

            return result;
        }

        static string RemoveDiacritics(string text)
        {
            var normalizedString = text.Normalize(NormalizationForm.FormD);
            var stringBuilder = new StringBuilder();

            foreach (var c in normalizedString)
            {
                var unicodeCategory = System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c);
                if (unicodeCategory != System.Globalization.UnicodeCategory.NonSpacingMark)
                {
                    stringBuilder.Append(c);
                }
            }

            return stringBuilder.ToString().Normalize(NormalizationForm.FormC);
        }

        /// <summary>
        /// Sanitize a string for output to a file.
        /// </summary>
        static string Sanitize(string source)
        {
            if (string.IsNullOrEmpty(source))
                return source;

            string invalidChars = System.Text.RegularExpressions.Regex.Escape(new string(Path.GetInvalidFileNameChars()));
            string invalidReStr = string.Format(@"[{0}]+", invalidChars);
            return System.Text.RegularExpressions.Regex.Replace(source, invalidReStr, "_");
        }

        void RemoveLanguage(WordGameLanguage language, WordGameLanguage[] languages)
        {
            WordGameLanguage.RemoveByName(language.languageName);
            var folder = new FileInfo(AssetDatabase.GetAssetPath(language)).Directory;
            var meta = new FileInfo(folder.FullName + ".meta");

            if (folder.Exists) folder.Delete(true);
            if (meta.Exists) meta.Delete();

            AssetDatabase.Refresh();
            m_Index = Mathf.Clamp(m_Index - 1, 0, Mathf.Max(languages.Length - 1, 0));
            ChangeLanguage(languages.Length > 0 ? languages[m_Index] : null, false, false);
            Repaint();
        }
    }
#if !UNITY_3_5
}
#endif
