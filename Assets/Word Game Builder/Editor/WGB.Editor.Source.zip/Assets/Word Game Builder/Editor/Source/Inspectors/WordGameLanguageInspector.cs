﻿//
// WordGameLanguageInspector.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using Thinksquirrel.WordGameBuilder;
using UnityEditor;
using UnityEngine;

#if !UNITY_3_5
namespace Thinksquirrel.WordGameBuilderEditor
{
#else
using Thinksquirrel.WordGameBuilderEditor;
#endif
    //! \cond PRIVATE
    [CustomEditor(typeof(WordGameLanguage))]
    sealed class WordGameLanguageInspector : WGBInspectorBase
    {
        public override void OnInspectorGUI()
        {
            var language = (WordGameLanguage)target;
            GUILayout.Label(language.languageName);
            if (GUILayout.Button("Open Language Editor...", EditorStyles.miniButtonMid))
            {
                LanguageEditor._startLanguage = language;
                WGBMenuItems.OpenLanguageEditor();
            }
        }
    }
    //! \endcond
#if !UNITY_3_5
}
#endif
