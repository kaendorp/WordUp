//
// TilePoolInspector.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using Thinksquirrel.WordGameBuilder;
using UnityEditor;
using UnityEngine;
using Thinksquirrel.WordGameBuilder.Gameplay;

#if !UNITY_3_5
namespace Thinksquirrel.WordGameBuilderEditor
{
#else
using Thinksquirrel.WordGameBuilderEditor;
#endif
    //! \cond PRIVATE
    [CustomEditor(typeof(TilePool))]
    sealed class TilePoolInspector : WGBInspectorBase
    {
        TilePool m_Pool;
        static bool s_Foldout = true;
        int m_TileDistributionCount;
        SerializedProperty m_Keys, m_Values;

        void OnEnable()
        {
            WordGameLanguage.LoadAllLanguages();
            m_Pool = target as TilePool;
            m_TileDistributionCount = m_Pool.tileDistributionCount;
            m_Keys = serializedObject.FindProperty("m_Keys");
            m_Values = serializedObject.FindProperty("m_Values");
        }

        void DoSetDirty()
        {
            EditorUtility.SetDirty(m_Pool);
            foreach (var obj in m_Pool)
            {
                EditorUtility.SetDirty(obj.gameObject);
                EditorUtility.SetDirty(obj as MonoBehaviour);
            }
        }

        void OnLanguageLoad()
        {
            m_Pool.CreateTilePool(m_Pool.transform);
            DoSetDirty();
        }

        void OnLanguageLoadCancel()
        {
            WGBBase.LogError("Language load cancelled by user.", "Word Game Builder", "TilePool", target);
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            SerializedProperty iterator = serializedObject.GetIterator();
            bool enterChildren = true;
            while (iterator.NextVisible (enterChildren))
            {
                if (iterator.name == "m_Script" || iterator.name == "m_Target" || iterator.name == "m_TargetGameObject" || iterator.name == "m_MethodName")
                    continue;

                if (iterator.type == "WGBEvent")
                {
                    continue;
                }

                if (iterator.name == "m_LanguageIdentifier")
                {
                    EditorGUI.BeginChangeCheck();
                    var lang = EditorGUILayout.ObjectField("Language", m_Pool.language, typeof(WordGameLanguage), false) as WordGameLanguage;

                    if (EditorGUI.EndChangeCheck())
                    {
                        m_Pool.language = lang;
                        EditorUtility.SetDirty(m_Pool);
                    }
                }

                EditorGUILayout.PropertyField(iterator, true);
                enterChildren = false;
            }
            serializedObject.ApplyModifiedProperties();

            // Fix issues with width being broken
            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUI.enabled = !EditorUtility.IsPersistent(m_Pool);
            if (GUILayout.Button("Generate Pool"))
            {
                try
                {
                    WGBEditorHelpers.LoadLanguageWithProgressBar(m_Pool.languageIdentifier, OnLanguageLoad, OnLanguageLoadCancel);
                }
                catch (System.Exception e)
                {
                    WGBBase.LogException(e, target);
                }
            }
            if (GUILayout.Button("Clear Pool"))
            {
                m_Pool.DestroyAllTiles();
                DoSetDirty();
            }
            GUI.enabled = true;
            GUILayout.EndHorizontal();

            EditorGUILayout.Separator();
            s_Foldout = EditorGUILayout.Foldout(s_Foldout, " Tile Distribution");

            if (s_Foldout)
            {
                GUILayout.BeginHorizontal();
                GUILayout.BeginVertical();

                m_TileDistributionCount = EditorGUILayout.IntField("Count", m_TileDistributionCount);

                GUILayout.BeginHorizontal();
                GUI.enabled = m_TileDistributionCount != m_Pool.tileDistributionCount;
                if (GUILayout.Button("Apply") && EditorUtility.DisplayDialog("Change Tile Distribution Count?",
                                                                             "This action cannot be undone.", "Ok", "Cancel"))
                {
                    m_Pool.tileDistributionCount = m_TileDistributionCount;
                    DoSetDirty();
                }
                if (GUILayout.Button("Reset"))
                {
                    m_TileDistributionCount = m_Pool.tileDistributionCount;
                }
                GUI.enabled = true;

                GUILayout.EndHorizontal();

                float halfWidth = Screen.width * .45f;

                if (m_Pool.tileDistributionCount > 0)
                {
                    GUILayout.BeginHorizontal();
                    GUILayout.FlexibleSpace();
                    EditorGUILayout.LabelField("Letter", GUILayout.Width(halfWidth));
                    EditorGUILayout.LabelField("Amount", GUILayout.Width(halfWidth));
                    GUILayout.FlexibleSpace();
                    GUILayout.EndHorizontal();
                }

                serializedObject.Update();

                int amount = m_Pool.blankLetterCount;
                for (int i = 0; i < m_Keys.arraySize; i++)
                {
                    GUILayout.BeginHorizontal();
                    GUILayout.FlexibleSpace();

                    EditorGUILayout.PropertyField(m_Keys.GetArrayElementAtIndex(i), GUIContent.none, GUILayout.Width(halfWidth));
                    EditorGUILayout.PropertyField(m_Values.GetArrayElementAtIndex(i), GUIContent.none, GUILayout.Width(halfWidth));

                    amount += m_Values.GetArrayElementAtIndex(i).intValue;

                    GUILayout.FlexibleSpace();
                    GUILayout.EndHorizontal();
                }

                serializedObject.ApplyModifiedProperties();

                EditorGUILayout.LabelField((amount * m_Pool.poolMultiplier) + " tiles total (including blank tiles)");

                GUILayout.EndVertical();
                GUILayout.EndHorizontal();

                WGBEditorHelpers.DrawEvent(serializedObject.FindProperty("m_OnTileDistribution"));
            }
        }
    }
    //! \endcond
#if !UNITY_3_5
}
#endif
