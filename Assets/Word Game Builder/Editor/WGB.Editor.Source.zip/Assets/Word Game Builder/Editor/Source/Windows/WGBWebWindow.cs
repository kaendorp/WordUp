//
// WGBWebWindow.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using System.Reflection;
using UnityEditor;
using UnityEngine;

#if !UNITY_3_5
namespace Thinksquirrel.WordGameBuilderEditor
{
#endif
    //! \cond PRIVATE
    sealed class WGBWebWindow : EditorWindow
    {
        static Rect s_WindowRect = new Rect(100, 100, Mathf.Max(Screen.currentResolution.width - 200, 800), Mathf.Max(Screen.currentResolution.height - 200, 600));
        static BindingFlags s_FullBinding = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
        static System.StringComparison s_IgnoreCase = System.StringComparison.CurrentCultureIgnoreCase;
        object m_WebView;
        System.Type m_WebViewType;
        MethodInfo m_DoGuiMethod;
        MethodInfo m_LoadUrlMethod;
        MethodInfo m_FocusMethod;
        MethodInfo m_UnFocusMethod;
        MethodInfo m_DockedGetterMethod;
        string m_UrlText = "https://www.thinksquirrel.com";
        bool m_Initialized;

        public static void Load(string title, string url)
        {
            // Only load the web window for approved versions, and on OS X only
            // We do this since the internal API is a bit unstable.
            string[] ver = Application.unityVersion.Split('.');

            if (int.Parse(ver [0]) == 3 ||
                (int.Parse(ver [0]) == 4 && int.Parse(ver [1]) < 3) &&
                Application.platform == RuntimePlatform.OSXEditor)
            {
                WGBWebWindow window = EditorWindow.GetWindow<WGBWebWindow>(title);
                window.m_UrlText = url;
            }
            else
            {
                Application.OpenURL(url);
            }
        }

        void Init()
        {
            if (!m_Initialized)
            {
                //Set window rect
                position = s_WindowRect;
                m_Initialized = true;

                //Init web view
                InitWebView();
            }
        }

        void InitWebView()
        {
            //Get WebView type
            m_WebViewType = GetTypeFromAllAssemblies("WebView");


            m_WebView = ScriptableObject.CreateInstance(m_WebViewType);

            // Analysis disable RedundantCast
            m_WebViewType.GetMethod("InitWebView").Invoke(m_WebView, new object[] {
                (int)position.width,
                (int)position.height,
                true
            });
            m_WebViewType.GetMethod("set_hideFlags").Invoke(m_WebView, new object[] {13});
            // Analysis restore RedundantCast

            m_LoadUrlMethod = m_WebViewType.GetMethod("LoadURL");
            m_LoadUrlMethod.Invoke(m_WebView, new object[] {m_UrlText});
            m_WebViewType.GetMethod("SetDelegateObject").Invoke(m_WebView, new object[] {this});

            m_DoGuiMethod = m_WebViewType.GetMethod("DoGUI");
            m_FocusMethod = m_WebViewType.GetMethod("Focus");
            m_UnFocusMethod = m_WebViewType.GetMethod("UnFocus");

            wantsMouseMove = true;

            //Get docked property getter MethodInfo
            m_DockedGetterMethod = typeof(EditorWindow).GetProperty("docked", s_FullBinding).GetGetMethod(true);
        }

        void OnGUI()
        {

            Init();

            if (GUI.GetNameOfFocusedControl().Equals("urlfield"))
                m_UnFocusMethod.Invoke(m_WebView, null);

            if (m_DockedGetterMethod == null)
            {
                InitWebView();
            }

            var webViewRect = new Rect(0, 0, position.width, position.height - (((bool)(m_DockedGetterMethod.Invoke(this, null))) ? 0 : 20));

            //Hidden, disabled, button for taking focus away from urlfield
            GUI.enabled = false;
            GUI.SetNextControlName("hidden");
            GUI.Button(new Rect(-20, -20, 5, 5), string.Empty);
            GUI.enabled = true;

            if (Event.current.isMouse && Event.current.type == EventType.MouseDown && webViewRect.Contains(Event.current.mousePosition))
            {
                GUI.FocusControl("hidden");
                m_FocusMethod.Invoke(m_WebView, null);
            }

            //Web view
            if (m_WebView != null)
            {
                m_DoGuiMethod.Invoke(m_WebView, new object[] {webViewRect});
            }
        }

        void OnWebViewDirty()
        {
            Repaint();
        }

        public static System.Type GetTypeFromAllAssemblies(string typeName)
        {
            Assembly[] assemblies = System.AppDomain.CurrentDomain.GetAssemblies();
            foreach (Assembly assembly in assemblies)
            {
                System.Type[] types = assembly.GetTypes();
                foreach (System.Type type in types)
                {
                    if (type.Name.Equals(typeName, s_IgnoreCase) || type.Name.Contains('+' + typeName)) //+ check for inline classes
                        return type;
                }
            }
            return null;
        }

        void OnDestroy()
        {
            //Destroy web view
            if (m_WebViewType != null && m_WebView != null)
                m_WebViewType.GetMethod("DestroyWebView", s_FullBinding).Invoke(m_WebView, null);
        }
    }
    //! \endcond
#if !UNITY_3_5
}
#endif
