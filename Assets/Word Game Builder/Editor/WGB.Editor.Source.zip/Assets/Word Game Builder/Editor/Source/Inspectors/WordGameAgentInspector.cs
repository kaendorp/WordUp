//
// WordGamePlayerInspector.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using UnityEditor;
using Thinksquirrel.WordGameBuilder.Gameplay;

#if !UNITY_3_5
namespace Thinksquirrel.WordGameBuilderEditor
{
#else
using Thinksquirrel.WordGameBuilderEditor;
#endif
    //! \cond PRIVATE
    [CustomEditor(typeof(WordGameAgent))]
    [CanEditMultipleObjects]
    sealed class WordGameAgentInspector : WGBInspectorBase
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
        }
    }
    //! \endcond
#if !UNITY_3_5
}
#endif
