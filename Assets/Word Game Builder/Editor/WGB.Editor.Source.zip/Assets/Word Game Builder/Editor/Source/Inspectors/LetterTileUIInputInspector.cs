//
// LetterTileUIInputInspector.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
#if !UNITY_3_5 && !UNITY_4_0 && !UNITY_4_1 && !UNITY_4_2 && !UNITY_4_3 && !UNITY_4_4 && !UNITY_4_5
using UnityEditor;
using Thinksquirrel.WordGameBuilder.Tiles.UI;

namespace Thinksquirrel.WordGameBuilderEditor
{
    //! \cond PRIVATE
    [CustomEditor(typeof(LetterTileUIInput))]
    [CanEditMultipleObjects]
    sealed class LetterTileUIInputInspector : WGBInspectorBase
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
        }
    }
    //! \endcond
}
#endif
