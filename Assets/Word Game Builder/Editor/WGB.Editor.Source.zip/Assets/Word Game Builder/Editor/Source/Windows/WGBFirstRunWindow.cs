//
// WGBFirstRunWindow.cs
//
// Author(s):
//       Josh Montoute <josh@thinksquirrel.com>
//
// Copyright (c) 2012-2014 Thinksquirrel Software, LLC
//
using Thinksquirrel.WordGameBuilderInternal;
using UnityEditor;
using UnityEngine;

#if UNITY_3_5
using Thinksquirrel.WordGameBuilderEditor;
#else
namespace Thinksquirrel.WordGameBuilderEditor
{
#endif
    //! \cond PRIVATE
    sealed class WGBFirstRunWindow : EditorWindow
    {
        static GUIContent s_Logo;
        internal Vector2 _dimensions = new Vector2(420, 500);
        
        void OnGUI()
        {
            if (s_Logo == null)
            {
                s_Logo = new GUIContent(Resources.Load("wgb_logo") as Texture);
            }
            
            GUILayout.BeginVertical();
            
            // Logo
            GUILayout.BeginHorizontal(GUILayout.Height(128));
            GUILayout.FlexibleSpace();
            GUILayout.Label(s_Logo);
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            
            // Welcome message
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            GUILayout.Label("Thank you for installing Word Game Builder!", EditorStyles.largeLabel);
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            GUILayout.BeginVertical();
            GUILayout.Label("Please check out the following links for more information.");
            GUILayout.Label("This window can be re-opened from Preferences > WGB.");
            GUILayout.EndVertical();
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            
            EditorGUILayout.Separator();
            EditorGUILayout.Separator();
            EditorGUILayout.Separator();
            
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            GUILayout.BeginVertical();
            
            // Links
            if (DrawButton("Help", "Browse through the Reference Manual."))
                WGBMenuItems.HelpWindow();
            if (DrawButton("Support Forum", "Open the Word Game Builder support forum."))
                WGBMenuItems.SupportForumWindow();
            
            EditorGUILayout.Separator();
            EditorGUILayout.Separator();
            
            if (DrawButton("About WGB", "More information about Word Game Builder."))
            {
                AboutWGB.Open();
            }

            string contentLink = VersionInfo.ContentLink();
            bool e = GUI.enabled;
            GUI.enabled = e && !VersionInfo.isBeta && !string.IsNullOrEmpty(contentLink);
            if (DrawButton("Rate this package", "Rate this package in the Asset Store."))
                Application.OpenURL("com.unity3d.kharma:" + contentLink);
            GUI.enabled = e;
            
            if (DrawButton("Download Help Files", "Automatically download help files from the web."))
                WGBPreferences.DownloadDocumentation(true);
            
            EditorGUILayout.Separator();
            EditorGUILayout.Separator();
            
            
            EditorGUILayout.Separator();
            EditorGUILayout.Separator();
            EditorGUILayout.Separator();
            EditorGUILayout.Separator();
            EditorGUILayout.Separator();
            
            // Close window
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Close this Window", GUILayout.Width(175)))
                Close();
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            
            GUILayout.EndVertical();
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            
            GUILayout.FlexibleSpace();
            
            // Version info
            GUILayout.Label("Word Game Builder Version: " + VersionInfo.version);
            GUILayout.Label("Platform: Unity " + Application.unityVersion);
            GUILayout.Label("License: " + VersionInfo.license);
            GUILayout.EndVertical();
            
            // TODO: T.P.R
        }
        
        bool DrawButton(string label, string description)
        {
            GUILayout.BeginHorizontal();
            bool result = GUILayout.Button(label, GUILayout.Width(125));
            GUILayout.Label(description);
            GUILayout.EndHorizontal();
            
            return result;
        }
    }
    //! \endcond
#if !UNITY_3_5
}
#endif
